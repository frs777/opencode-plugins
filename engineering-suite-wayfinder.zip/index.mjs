import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-wayfinder',
  name: 'Wayfinder',
  version: '2.0.0',
  description: 'Map huge uncertain projects',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-wayfinder', description: 'Map huge uncertain projects' })
    })

    return () => console.log('[engineering-suite-wayfinder] Plugin unloaded')
  }
})
