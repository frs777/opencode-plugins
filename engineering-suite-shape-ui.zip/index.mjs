import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-shape-ui',
  name: 'ShapeUI',
  version: '2.0.0',
  description: 'Plan UX before coding',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-shape-ui', description: 'Plan UX before coding' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'engineering-suite-shape-ui', description: 'Plan UX before coding agents' })
    })

    return () => console.log('[engineering-suite-shape-ui] Plugin unloaded')
  }
})
