import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'tailscale',
  name: 'Tailscale',
  version: '1.0.0-alpha-1',
  description: 'Securely connect your devices',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'tailscale', description: 'Securely connect your devices' })
    })

    return () => console.log('[tailscale] Plugin unloaded')
  }
})
