import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'vibecoder',
  name: 'vibecoder',
  version: '1.2.0',
  description: 'Turn ideas into working apps by describing them. Get build plans, PRDs, full-stack code, UIs, bug fixes, code reviews, prompts for Cursor and Claude Code, and step-by-step deployment, for beginners and pros.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'vibecoder', description: 'Turn ideas into working apps by describing them. Get build plans, PRDs, full-stack code, UIs, bug fixes, code reviews, prompts for Cursor and Claude Code, and step-by-step deployment, for beginners and pros.' })
    })

    return () => console.log('[vibecoder] Plugin unloaded')
  }
})
