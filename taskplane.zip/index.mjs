import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'taskplane',
  name: 'taskplane',
  version: '2.31.5',
  description: 'Plan, build and review code',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'taskplane', description: 'Plan, build and review code' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'taskplane', description: 'Plan, build and review code agents' })
    })

    return () => console.log('[taskplane] Plugin unloaded')
  }
})
