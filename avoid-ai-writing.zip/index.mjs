import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'avoid-ai-writing',
  name: 'Avoid AI Writing',
  version: '3.29.0',
  description: 'Detect and rewrite AI-isms',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'avoid-ai-writing', description: 'Detect and rewrite AI-isms' })
    })

    return () => console.log('[avoid-ai-writing] Plugin unloaded')
  }
})
