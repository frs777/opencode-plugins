import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'intuitive-software-design',
  name: 'Intuitive Software Design',
  version: '1.3.1',
  description: 'Make software intuitive.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'intuitive-software-design', description: 'Make software intuitive.' })
    })

    return () => console.log('[intuitive-software-design] Plugin unloaded')
  }
})
