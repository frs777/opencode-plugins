import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-codebase-design',
  name: 'CodebaseDesign',
  version: '2.0.0',
  description: 'Design deep module seams',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-codebase-design', description: 'Design deep module seams' })
    })

    return () => console.log('[engineering-suite-codebase-design] Plugin unloaded')
  }
})
