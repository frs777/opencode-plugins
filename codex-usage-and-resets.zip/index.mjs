import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'codex-usage-and-resets',
  name: 'CUAR',
  version: '0.1.1',
  description: 'Codex usage pace and resets',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'codex-usage-and-resets', description: 'Codex usage pace and resets' })
    })

    return () => console.log('[codex-usage-and-resets] Plugin unloaded')
  }
})
