# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: schema/report.schema.json (stripped: schema/report.schema.json)
- Skipped unsupported source entry: .codexignore (stripped: .codexignore)
- Skipped unsupported source entry: PRIVACY.md (stripped: PRIVACY.md)
- Skipped unsupported source entry: SUPPORT.md (stripped: SUPPORT.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs