import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'codex-engineering-guardrails',
  name: 'Codex Engineering Guardrails',
  version: '1.1.1',
  description: 'Implement and verify code',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'codex-engineering-guardrails', description: 'Implement and verify code' })
    })

    return () => console.log('[codex-engineering-guardrails] Plugin unloaded')
  }
})
