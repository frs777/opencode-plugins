import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-teach',
  name: 'Teach',
  version: '2.0.0',
  description: 'Teach concepts across sessions',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-teach', description: 'Teach concepts across sessions' })
    })

    return () => console.log('[engineering-suite-teach] Plugin unloaded')
  }
})
