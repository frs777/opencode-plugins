import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'uniformdev',
  name: 'Uniform',
  version: '1.0.0',
  description: 'Build with Uniform',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'uniformdev', description: 'Build with Uniform' })
    })

    return () => console.log('[uniformdev] Plugin unloaded')
  }
})
