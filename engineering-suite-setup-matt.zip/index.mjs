import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-setup-matt',
  name: 'SetupMatt',
  version: '2.0.0',
  description: 'Configure Matt skills in repos',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-setup-matt', description: 'Configure Matt skills in repos' })
    })

    return () => console.log('[engineering-suite-setup-matt] Plugin unloaded')
  }
})
