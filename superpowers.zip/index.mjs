import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'superpowers',
  name: 'Superpowers',
  version: '6.4.2',
  description: 'Make your agents better devs',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'superpowers', description: 'Make your agents better devs' })
    })

    return () => console.log('[superpowers] Plugin unloaded')
  }
})
