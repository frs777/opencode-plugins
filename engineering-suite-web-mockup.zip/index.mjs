import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-web-mockup',
  name: 'WebMockup',
  version: '2.0.0',
  description: 'Generate web design comps',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-web-mockup', description: 'Generate web design comps' })
    })

    return () => console.log('[engineering-suite-web-mockup] Plugin unloaded')
  }
})
