import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'codex-process-jobs',
  name: 'Codex Process Jobs',
  version: '0.5.0',
  description: 'Detached process jobs',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'codex-process-jobs', description: 'Detached process jobs' })
    })

    return () => console.log('[codex-process-jobs] Plugin unloaded')
  }
})
