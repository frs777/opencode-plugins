# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: hooks/hooks.json (stripped: hooks/hooks.json)
- Skipped unsupported source entry: hooks/unread-result-hook.mjs (stripped: hooks/unread-result-hook.mjs)
- Skipped unsupported source entry: .codexignore (stripped: .codexignore)
- Skipped unsupported source entry: PRIVACY.md (stripped: PRIVACY.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs