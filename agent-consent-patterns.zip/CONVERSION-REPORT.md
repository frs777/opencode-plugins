# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: skills/.DS_Store (stripped: skills/.DS_Store)
- Skipped unsupported source entry: .DS_Store (stripped: .DS_Store)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs