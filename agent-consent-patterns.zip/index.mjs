import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'agent-consent-patterns',
  name: 'Agent Consent Patterns',
  version: '0.1.1',
  description: 'Build safer, better, AI agents',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'agent-consent-patterns', description: 'Build safer, better, AI agents' })
    })

    return () => console.log('[agent-consent-patterns] Plugin unloaded')
  }
})
