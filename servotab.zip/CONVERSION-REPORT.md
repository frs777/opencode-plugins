# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: NOTICE.md (stripped: NOTICE.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs