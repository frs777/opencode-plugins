import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'servotab',
  name: 'servotab',
  version: '0.6.4',
  description: 'A quiet, risk-scaled engineering method layer for Codex.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'servotab', description: 'A quiet, risk-scaled engineering method layer for Codex.' })
    })

    return () => console.log('[servotab] Plugin unloaded')
  }
})
