# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: examples/high-risk-task.json (stripped: examples/high-risk-task.json)
- Skipped unsupported source entry: examples/routine-task.json (stripped: examples/routine-task.json)
- Skipped unsupported source entry: outcome.schema.json (stripped: outcome.schema.json)
- Skipped unsupported source entry: receipt.schema.json (stripped: receipt.schema.json)
- Skipped unsupported source entry: registry.schema.json (stripped: registry.schema.json)
- Skipped unsupported source entry: routes.example.json (stripped: routes.example.json)
- Skipped unsupported source entry: task.schema.json (stripped: task.schema.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs