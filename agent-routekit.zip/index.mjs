import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'agent-routekit',
  name: 'Local Model Route Planner',
  version: '0.1.5',
  description: 'Pick the most efficient model',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'agent-routekit', description: 'Pick the most efficient model' })
    })

    return () => console.log('[agent-routekit] Plugin unloaded')
  }
})
