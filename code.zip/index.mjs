import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'code',
  name: 'Code',
  version: '1.0.0',
  description: 'Code that\'s ready to run',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'code', description: 'Code that\'s ready to run' })
    })

    return () => console.log('[code] Plugin unloaded')
  }
})
