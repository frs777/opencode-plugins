import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'amd-skills',
  name: 'AMD Skills',
  version: '0.2.0',
  description: 'Agent Skills for AMD-optimized workflows.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'amd-skills', description: 'Agent Skills for AMD-optimized workflows.' })
    })

    return () => console.log('[amd-skills] Plugin unloaded')
  }
})
