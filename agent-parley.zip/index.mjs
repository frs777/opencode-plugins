import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'agent-parley',
  name: 'Agent Parley',
  version: '0.14.0',
  description: 'Coordinate agents on one repo',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'agent-parley', description: 'Coordinate agents on one repo' })
    })

    return () => console.log('[agent-parley] Plugin unloaded')
  }
})
