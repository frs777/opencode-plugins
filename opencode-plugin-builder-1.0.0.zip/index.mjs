import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'opencode-plugin-builder',
  name: 'OpenCode Plugin Builder',
  version: '1.0.0',
  description: 'Tworzy pluginy, skille i komendy dla OpenCode V2. Wielopoziomowy generator z szablonami, referencjami i walidacją.',
  async setup(ctx) {
    // Rejestracja namespace'u dla skillów
    await ctx.skill.transform(editor => {
      editor.namespace({
        name: 'opencode-plugin-builder',
        description: 'Tworzy pluginy, skille i komendy dla OpenCode V2. Opcje: --plugin, --skill, --command.'
      })
    })

    // Rejestracja komend CLI
    ctx.command.register({
      name: 'plugin-builder',
      description: 'Generuje plugin/skill/komendę dla OpenCode V2',
      usage: 'plugin-builder [--plugin|--skill|--command] <nazwa> [opcje]',
      async handler(args, context) {
        const { default: builder } = await import('./src/builder.js');
        return builder(args, context);
      }
    });

    return () => console.log('[opencode-plugin-builder] Plugin unloaded');
  }
});