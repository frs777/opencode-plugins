import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'opencode-plugin-builder',
  name: 'OpenCode Plugin Builder',
  version: '1.0.0',
  description: 'Tworzy pluginy, skille i komendy dla OpenCode V2 oraz sprawdza zgodnosc istniejacych wtyczek (--check/--fix).',
  async setup(ctx) {
    // Register CLI command
    await ctx.command.transform((editor) => {
      editor.add({
        name: 'plugin-builder',
        description: 'Generates plugin/skill/command for OpenCode V2',
        usage: 'plugin-builder [--plugin|--skill|--command] <name> [options]',
        execute: async ({ sessionID, prompt, delivery }) => {
          const { builder } = await import('./src/builder.js');
          const args = prompt.text.trim().split(/\s+/).slice(1);
          return builder(args, { sessionID, prompt, delivery });
        }
      });
    });

    return () => console.log('[opencode-plugin-builder] Plugin unloaded');
  }
});