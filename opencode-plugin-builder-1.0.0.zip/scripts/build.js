import { existsSync, mkdirSync, writeFileSync, readFileSync, readdirSync, statSync } from 'fs';
import { join, relative, dirname } from 'path';
import { fileURLToPath } from 'url';
import { zipSync, strToU8 } from 'fflate';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');
const DIST = join(ROOT, 'dist');

function getFiles(dir, prefix = '') {
  const files = {};
  const entries = readdirSync(dir);
  
  for (const entry of entries) {
    const full = join(dir, entry);
    const rel = join(prefix, entry);
    const stat = statSync(full);
    
    if (stat.isDirectory()) {
      Object.assign(files, getFiles(full, rel));
    } else {
      // Skip node_modules, .git, dist, tests
      if (!rel.startsWith('node_modules/') && 
          !rel.startsWith('.git/') && 
          !rel.startsWith('dist/') &&
          !rel.startsWith('tests/') &&
          entry !== 'package-lock.json') {
        files[rel] = readFileSync(full);
      }
    }
  }
  return files;
}

function build() {
  console.log('Building opencode-plugin-builder...');
  
  if (!existsSync(DIST)) {
    mkdirSync(DIST, { recursive: true });
  }
  
  const files = getFiles(ROOT);
  console.log(`Packing ${Object.keys(files).length} files...`);
  
  const zipFiles = {};
  for (const [name, content] of Object.entries(files)) {
    zipFiles[name] = typeof content === 'string' ? strToU8(content) : content;
  }
  
  const zip = zipSync(zipFiles);
  const outputPath = join(DIST, 'opencode-plugin-builder.zip');
  writeFileSync(outputPath, Buffer.from(zip));
  
  console.log(`Created: ${outputPath}`);
  console.log(`Size: ${(zip.length / 1024).toFixed(1)} KB`);
}

build();