# OpenCode Plugin Builder

**Tworzy pluginy, skille i komendy dla OpenCode V2 + sprawdza zgodność istniejących wtyczek.**

Generator z szablonami, referencjami i walidacją. Opcje: `--plugin` (domyślne), `--skill`, `--command`, `--check`, `--fix`. Język polski z obsługą innych.

## Instalacja

```bash
# Katalog lokalny
opencode plugin add ./opencode-plugin-builder

# Lub wskaż katalog wtyczki przez config
```

## Użycie

```bash
# Tworzy plugin (domyślne)
opencode plugin-builder --plugin moj-plugin
opencode plugin-builder -p moj-plugin

# Tworzy skill
opencode plugin-builder --skill moj-skill
opencode plugin-builder -s moj-skill

# Tworzy komendę (plugin rejestrujący komendę przez ctx.command.transform)
opencode plugin-builder --command moja-komenda
opencode plugin-builder -c moja-komenda

# Z opcjami
opencode plugin-builder --plugin moj-plugin --output ./plugins --force
opencode plugin-builder --skill moj-skill -o ./skills -f
```

## Sprawdzanie zgodności V1/V2

```bash
# Raport: markery V1, nieprawidłowe wywołania editor.namespace
opencode plugin-builder --check /sciezka/do/wtyczki

# Naprawa: usuwa editor.namespace z ctx.skill/command/agent.transform
# (namespace istnieje tylko w ctx.tool.transform)
opencode plugin-builder --fix /sciezka/do/wtyczki
```

`--check` wykrywa:

| Marker | Znaczenie |
|--------|-----------|
| `ctx.command.register(` | API V1 — w V2: `ctx.command.transform(editor => editor.add(...))` |
| `definePlugin(` | API V1 — w V2: `Plugin.define({ id, setup })` |
| `editor.namespace` w `ctx.skill/command/agent.transform` | Błąd — `namespace` jest tylko na `ToolEditorze` |

## Opcje

| Opcja | Skrót | Opis |
|-------|-------|------|
| `--plugin` | `-p` | Tworzy plugin (domyślne) |
| `--skill` | `-s` | Tworzy skill |
| `--command` | `-c` | Tworzy komendę (jako plugin) |
| `--check <katalog>` | | Raport zgodności z V2 |
| `--fix <katalog>` | | Usuń nieprawidłowe `editor.namespace` |
| `--output <katalog>` | `-o` | Katalog wyjściowy |
| `--force` | `-f` | Nadpisz istniejące |
| `--help` | `-h` | Pokaż pomoc |
| `--lang` | | Język (pl/en/zh) |

## Struktura Generowanego Pluginu

```
moj-plugin/
├── package.json           # Manifest (name + exports) — wymagany przez OpenCode V2
├── index.mjs              # Plugin.define + ctx.command.transform
├── src/
│   └── plugin.js          # Logika komendy
├── README.md
└── LICENSE                # Apache-2.0
```

## Struktura Generowanego Skillu

```
moj-skill/
├── SKILL.md               # Definicja skillu
├── scripts/
│   └── main.js            # Logika
└── references/            # Pusty katalog na dokumentację
```

## Referencje (wbudowane)

- `references/api.md` — API kontekstu, skillów, komend, narzędzi
- `references/patterns.md` — Wzorce projektowe
- `references/examples.md` — Gotowe przykłady

## Wielojęzyczność

Domyślnie polski. Obsługuje:
- Polish (pl) - domyślny
- English (en)
- 中文 (zh)

Użyj `--lang=en` dla angielskiego.

## Rozwój

```bash
cd opencode-plugin-builder
npm install
npm test
```

## Licencja

Apache-2.0 © 2026 frs

## Autor

frs (frs777)
