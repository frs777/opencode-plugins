# OpenCode Plugin Builder

**Tworzy pluginy, skille i komendy dla OpenCode V2.**

Wielopoziomowy generator z szablonami, referencjami i walidacją. Opcje: `--plugin` (domyślne), `--skill`, `--command`. Język polski z obsługą innych.

## Instalacja

```bash
# Lokalnie
opencode plugin install ./opencode-plugin-builder

# Z GitHub
opencode plugin install github.com/frs777/opencode-plugin-builder
```

## Użycie

```bash
# Tworzy plugin (domyślne)
opencode plugin-builder --plugin moj-plugin
opencode plugin-builder -p moj-plugin

# Tworzy skill
opencode plugin-builder --skill moj-skill
opencode plugin-builder -s moj-skill

# Tworzy komendę
opencode plugin-builder --command moja-komenda
opencode plugin-builder -c moja-komenda

# Z opcjami
opencode plugin-builder --plugin moj-plugin --output ./plugins --force
opencode plugin-builder --skill moj-skill -o ./skills -f
```

## Opcje

| Opcja | Skrót | Opis |
|-------|-------|------|
| `--plugin` | `-p` | Tworzy plugin (domyślne) |
| `--skill` | `-s` | Tworzy skill |
| `--command` | `-c` | Tworzy komendę |
| `--output` | `-o` | Katalog wyjściowy |
| `--force` | `-f` | Nadpisz istniejące |
| `--help` | `-h` | Pokaż pomoc |
| `--lang` | | Język (pl/en/zh) |

## Struktura Generowanego Pluginu

```
moj-plugin/
├── opencode.json          # Manifest OpenCode V2
├── package.json           # Manifest npm
├── index.mjs              # Entry point
├── src/
│   ├── index.js           # Eksporty
│   └── plugin.js          # Logika
├── skills/                # Gotowe na skille
├── commands/              # Gotowe na komendy
├── assets/                # Logo, ikony
├── references/            # Dokumentacja
│   ├── api.md
│   ├── patterns.md
│   └── examples.md
├── tests/                 # Testy
├── README.md
└── LICENSE                # Apache-2.0
```

## Struktura Generowanego Skillu

```
moj-skill/
├── SKILL.md               # Definicja skillu
├── scripts/
│   └── main.js            # Logika
└── references/            # Dokumentacja
    ├── api.md
    ├── patterns.md
    └── examples.md
```

## Struktura Generowanej Komendy

```
moja-komenda/
├── command.json           # Manifest komendy
├── src/
│   └── command.js         # Logika
└── README.md
```

## Referencje (wbudowane)

Plugin zawiera kompletne referencje OpenCode V2:

- `references/api.md` - API kontekstu, skillów, komend
- `references/patterns.md` - Wzorce projektowe
- `references/examples.md` - Gotowe przykłady

## Wielojęzyczność

Domyślnie polski. Obsługuje:
- Polish (pl) - domyślny
- English (en)
- 中文 (zh)
- 日本語 (ja)
- Español (es)
- Français (fr)
- Deutsch (de)

Użyj `--lang=en` dla angielskiego.

## Rozwój

```bash
cd opencode-plugin-builder
npm install
npm test
```

## Licencja

Apache-2.0 © 2026 frs

## Autor

frs (frs777)