# OpenCode V2 Plugin Development Reference

## Podstawy

OpenCode V2 plugins are JavaScript/TypeScript modules that extend OpenCode functionality.

### Struktura pluginu

```
my-plugin/
├── opencode.json      # Manifest (wymagany)
├── package.json       # npm manifest
├── index.mjs          # Entry point (ESM)
├── src/
│   ├── index.js       # Exports
│   └── plugin.js      # Main logic
├── skills/            # Opcjonalne skille
│   └── my-skill/
│       ├── SKILL.md
│       └── scripts/
├── commands/          # Opcjonalne komendy
│   └── my-command/
│       ├── command.json
│       └── src/
├── assets/            # Opcjonalne zasoby
│   ├── logo.png
│   └── icon.png
├── references/        # Opcjonalna dokumentacja
├── tests/             # Testy
└── README.md
```

### opencode.json - pola wymagane

```json
{
  "name": "my-plugin",
  "version": "1.0.0",
  "description": "Plugin description",
  "main": "src/index.js",
  "opencode": {
    "id": "my-plugin",
    "setup": "index.mjs",
    "plugins": {
      "plugin": true
    }
  }
}
```

### index.mjs - entry point

```javascript
import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'my-plugin',
  name: 'My Plugin',
  version: '1.0.0',
  description: 'Plugin description',
  async setup(ctx) {
    // ctx.skill, ctx.command, ctx.fs, ctx.shell, ctx.workspace
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'my-plugin', description: '...' });
    });
    
    ctx.command.register({ ... });
    
    return () => console.log('[my-plugin] Unloaded');
  }
});
```

## API Kontekstu (ctx)

| Metoda | Opis |
|--------|------|
| `ctx.skill.transform(editor)` | Rejestracja/modyfikacja skillów |
| `ctx.command.register(cmd)` | Rejestracja komendy CLI |
| `ctx.fs.read(path)` | Odczyt pliku |
| `ctx.fs.write(path, content)` | Zapis pliku |
| `ctx.fs.list(path)` | Lista plików |
| `ctx.shell.exec(cmd)` | Wykonanie komendy shell |
| `ctx.workspace.root` | Katalog projektu |

## Skill Development

### SKILL.md structure

```markdown
---
name: skill-name
description: What this skill does
metadata:
  opencode/autoinvoke: true
---

# Skill Name

Description...

## When to use

- Trigger 1
- Trigger 2

## Instructions

1. Step 1
2. Step 2

## References

- `references/api.md`
- `references/patterns.md`
```

### Auto-invoke

`opencode/autoinvoke: true` makes the skill automatically available when its triggers match.

### Namespace registration

```javascript
await ctx.skill.transform(editor => {
  editor.namespace({
    name: 'my-plugin',
    description: 'Plugin skills'
  });
});
```

## Command Development

### command.json

```json
{
  "name": "my-command",
  "description": "Command description",
  "version": "1.0.0",
  "entryPoint": "src/command.js",
  "commands": [
    {
      "name": "my-command",
      "description": "Description",
      "usage": "my-command [options]",
      "options": [
        { "name": "help", "short": "h", "type": "boolean", "description": "Show help" }
      ]
    }
  ]
}
```

### Handler function

```javascript
export async function handler(args, context) {
  if (args.help) return showHelp();
  
  // Logic here
  return { success: true, message: 'Done' };
}
```

## Best Practices

1. **ESM only** - Use `.mjs` or `"type": "module"`
2. **Async setup** - All setup functions are async
3. **Cleanup** - Return cleanup function from setup
4. **Error handling** - Use try/catch, return structured errors
5. **Multilingual** - Default Polish, support other languages
6. **Testing** - Use `node --test` with test files

## Testing

```javascript
// tests/plugin.test.js
import { test } from 'node:test';
import assert from 'node:assert';

test('plugin loads', async () => {
  const { default: plugin } = await import('../index.mjs');
  assert.ok(plugin);
});
```

Run: `npm test` or `node --test tests/*.test.js`

## Publishing

1. Ensure `opencode.json` has correct `id`, `version`
2. Ensure `package.json` has `name`, `version`, `license`
3. Test with `opencode plugin install ./my-plugin`
4. Publish to GitHub, users install via:
   `opencode plugin install github.com/user/my-plugin`

## Migration from V1

- V1 used `.codex-plugin/` structure
- V2 uses flat structure with `opencode.json`
- Skills: `.codex-plugin/skills/` → `skills/`
- Commands: `.codex-plugin/commands/` → `commands/`
- Use `opencode plugin convert` for automatic migration