# OpenCode V2 Plugin Development Reference

Źródło prawdy: https://opencode.ai/v2/docs/build/plugins oraz typy pakietu
`@opencode/plugin` (`dist/v2/promise/*.d.ts`). Poniżej tylko to, co dotyczy
pisania pluginów.

## Struktura pluginu

```
my-plugin/
├── package.json       # wymagany: name + exports (tutaj OpenCode bierze entry point)
├── index.mjs          # serwer: export default Plugin.define({ id, setup })
├── src/               # opcjonalne moduły
├── skills/            # opcjonalne skille (SKILL.md)
└── README.md
```

Nie ma `opencode.json` ani `.codex-plugin/` — to wzorce V1.

### package.json

```json
{
  "name": "my-plugin",
  "version": "1.0.0",
  "type": "module",
  "exports": { ".": "./index.mjs" },
  "dependencies": { "@opencode/plugin": "latest" }
}
```

### index.mjs

```javascript
import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'my-plugin',
  async setup(ctx) {
    await ctx.command.transform((editor) => {
      editor.add({
        name: 'my-cmd',
        description: 'Opis komendy',
        execute: async ({ sessionID, prompt, delivery }) => {
          await ctx.session.prompt({ sessionID, text: prompt.text, delivery });
        },
      });
    });
    return () => console.log('[my-plugin] unloaded');
  },
});
```

## Kontekst (ctx)

`PluginContext` to klient serwera OpenCode + metody pluginowe.

| Metoda | Opis |
|--------|------|
| `ctx.command.transform(cb)` | dodaj komendę (`editor.add`) |
| `ctx.skill.transform(cb)` | dodaj/zmień skill (`editor.add/update/remove`) |
| `ctx.tool.transform(cb)` | narzędzia; jedyne miejsce z `editor.namespace(...)` |
| `ctx.agent.transform(cb)` | edycja agentów (brak `add`, tylko `list/get/update/remove/default`) |
| `ctx.storage.get/set/remove/scan` | trwałe dane pluginu |
| `ctx.session.*` | sesje, prompt, generate, command |
| `ctx.location.directory` | katalog, z którego wtyczka została załadowana |
| `ctx.options` | opcje z `plugins` w `opencode.json` |

Nie ma `ctx.fs`, `ctx.shell`, `ctx.workspace` — do plików i procesów użyj `node:fs`
i `node:child_process`.

## Komendy

```javascript
interface CommandEditor { add(definition: CommandDefinition): void }
interface CommandDefinition { name: string; description?: string; execute(input): Promise<void> }
interface CommandInvocation {
  sessionID: string
  prompt: PromptInput
  delivery: 'steer' | 'queue'
}
```

## Skille

```javascript
await ctx.skill.transform((editor) => {
  editor.add({ id, name, description, path, content });
  editor.update(id, (skill) => { skill.autoinvoke = true; });
  editor.remove('legacy');
});
await ctx.skill.reload();   // gdy zmienią się dane złapane przez transform
```

## Narzędzia

```javascript
await ctx.tool.transform((editor) => {
  editor.namespace({ name: 'acme', description: 'Customer account tools' });
  editor.add({ name: 'greeting', description: 'Create a greeting', input, options, execute });
});
```

## Agent

```javascript
await ctx.agent.transform((editor) => {
  editor.update('build', (agent) => { agent.description = '...' });
  editor.default('build');
});
```

## Ładowanie wtyczki

- `.opencode/plugins/<nazwa>/` w projekcie ładuje się automatycznie.
- Poza projektem: wpis w `opencode.json` (`plugins: ["./plugins/local"]` lub nazwa pakietu npm).
- Sprawdzenie statusu: `opencode plugin list` (`active` / `failed`).

## Migracja V1 → V2

| V1 | V2 |
|----|----|
| `export default definePlugin({...})` | `export default Plugin.define({ id, setup })` |
| `ctx.command.register({ name, handler })` | `ctx.command.transform(e => e.add({ name, execute }))` |
| `ctx.skill.transform(e => e.namespace(...))` | usunąć (`namespace` nie istnieje w `SkillEditor`) |
| `ctx.fs.read/write/list` | `node:fs` |
| `ctx.shell.exec` | `node:child_process` |
| `.codex-plugin/` + manifest | `package.json` + `exports` |

Użyj `opencode plugin-builder --check <katalog>` i `--fix <katalog>`.

## Publikacja

1. `package.json` z `name`, `version`, `exports`, `license`.
2. `opencode plugin list` — status `active` po załadowaniu.
3. `npm publish` (pakiet npm) albo `opencode plugin add ./katalog`.
