# Wzorce Projektowe OpenCode V2

## 1. Plugin z Skillami (Multi-skill)

```javascript
// index.mjs
export default Plugin.define({
  id: 'my-plugin',
  async setup(ctx) {
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'my-plugin' });
      
      // Rejestracja wielu skillów
      editor.skill('skill-one', { 
        description: 'First skill',
        autoinvoke: true
      });
      editor.skill('skill-two', { 
        description: 'Second skill',
        autoinvoke: false
      });
    });
  }
});
```

## 2. Plugin z Komendami

```javascript
ctx.command.register({
  name: 'my-cmd',
  description: 'Does something',
  async handler(args, context) {
    const { verbose } = args;
    // ...
  }
});
```

## 3. Skill z Referencjami

```
skills/
└── my-skill/
    ├── SKILL.md
    ├── scripts/
    │   └── main.js
    └── references/
        ├── api.md
        ├── patterns.md
        └── examples.md
```

## 4. Async/Await Pattern

```javascript
async setup(ctx) {
  try {
    await ctx.fs.write('file.txt', 'content');
    const data = await ctx.fs.read('file.txt');
  } catch (err) {
    console.error('[plugin] Error:', err);
  }
  
  return () => {
    // cleanup
  };
}
```

## 5. Multilingual Support

```javascript
const messages = {
  pl: { greeting: 'Cześć {name}!' },
  en: { greeting: 'Hello {name}!' },
  zh: { greeting: '你好 {name}!' }
};

function t(lang, key, params) {
  const msg = messages[lang]?.[key] || messages.pl[key];
  return msg.replace(/\{(\w+)\}/g, (_, k) => params[k] || '');
}
```

## 6. Template Rendering

```javascript
function render(template, vars) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] || '');
}

const template = 'Hello {{name}}!';
const result = render(template, { name: 'World' }); // "Hello World!"
```

## 7. File Operations

```javascript
// Read
const content = await ctx.fs.read('path/file.txt');

// Write
await ctx.fs.write('path/file.txt', 'content');

// List
const files = await ctx.fs.list('path/');

// Glob
const jsFiles = await ctx.fs.glob('**/*.js');
```

## 8. Shell Commands

```javascript
const result = await ctx.shell.exec('npm test', { 
  cwd: ctx.workspace.root,
  timeout: 60000 
});

if (result.exitCode !== 0) {
  throw new Error(`Command failed: ${result.stderr}`);
}
```

## 9. Skill Auto-invoke

```markdown
---
name: my-skill
description: Auto-invoked skill
metadata:
  opencode/autoinvoke: true
  opencode/triggers:
    - "create plugin"
    - "build skill"
---
```

## 10. Command Registration in Plugin

```javascript
async setup(ctx) {
  ctx.command.register({
    name: 'build',
    description: 'Build project',
    usage: 'build [target]',
    async handler(args, context) {
      // ...
    }
  });
}
```