# Wzorce Projektowe OpenCode V2

API poniżej pochodzi z typów `@opencode/plugin` (pakiet `@opencode-ai/plugin`).

## 1. Plugin z komendą

```javascript
// index.mjs
import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'my-plugin',
  async setup(ctx) {
    await ctx.command.transform((editor) => {
      editor.add({
        name: 'my-cmd',
        description: 'Does something',
        execute: async ({ sessionID, prompt, delivery }) => {
          await ctx.session.prompt({ sessionID, text: prompt.text, delivery });
        },
      });
    });
  },
});
```

## 2. Plugin ze skillem

Skille rejestruje się przez `editor.add` z pełnymi danymi (plik `SKILL.md` musi
istnieć na dysku; `content` to jego treść).

```javascript
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const DIR = fileURLToPath(new URL('.', import.meta.url));

await ctx.skill.transform((editor) => {
  editor.add({
    id: 'my-skill',
    name: 'my-skill',
    description: 'What the skill does',
    path: join(DIR, 'skills/my-skill/SKILL.md'),
    content: readFileSync(join(DIR, 'skills/my-skill/SKILL.md'), 'utf-8'),
  });
});
```

## 3. Plugin z narzędziem (tool)

`editor.namespace` istnieje **tylko** tutaj.

```javascript
await ctx.tool.transform((editor) => {
  editor.namespace({ name: 'acme', description: 'Customer account tools' });
  editor.add({
    name: 'greeting',
    description: 'Create a greeting',
    input: {
      type: 'object',
      properties: { name: { type: 'string' } },
      required: ['name'],
      additionalProperties: false,
    },
    options: { namespace: 'acme', codemode: true },
    execute: async ({ name }) => ({ content: `Hello ${name}!` }),
  });
});
```

## 4. Manifest (package.json)

OpenCode V2 ładuje katalog przez `package.json` (`name` + `exports`). `opencode.json`
wewnątrz wtyczki nie jest wymagany.

```json
{
  "name": "my-plugin",
  "version": "1.0.0",
  "type": "module",
  "exports": { ".": "./index.mjs" },
  "dependencies": { "@opencode/plugin": "latest" }
}
```

## 5. Pliki i procesy

W kontekście pluginu **nie ma** `ctx.fs` ani `ctx.shell` — użyj Node.js:

```javascript
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { spawn } from 'node:child_process';

const file = join(ctx.location.directory, 'file.txt');
writeFileSync(file, 'content', 'utf-8');
const content = readFileSync(file, 'utf-8');
```

## 6. Trwałe dane pluginu

```javascript
await ctx.storage.set('settings', { strict: true });
const settings = await ctx.storage.get('settings');
await ctx.storage.remove('settings');
const page = await ctx.storage.scan({ prefix: 'cache/', limit: 100 });
```

## 7. Wiele języków

```javascript
const messages = {
  pl: { greeting: 'Cześć {name}!' },
  en: { greeting: 'Hello {name}!' },
  zh: { greeting: '你好 {name}!' },
};

function t(lang, key, params) {
  const msg = messages[lang]?.[key] || messages.pl[key];
  return msg.replace(/\{(\w+)\}/g, (_, k) => params[k] || '');
}
```

## 8. Szablony

```javascript
function render(template, vars) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] || '');
}

render('Hello {{name}}!', { name: 'World' }); // "Hello World!"
```

## 9. Auto-invoke skilla

```markdown
---
name: my-skill
description: Auto-invoked skill
metadata:
  opencode/autoinvoke: true
---
```

## 10. Czyszczenie zasobów

```javascript
async setup(ctx) {
  const timer = setInterval(() => {}, 60_000);
  return () => clearInterval(timer);
}
```

## 11. Migracja V1 → V2

| V1 | V2 |
|----|----|
| `ctx.command.register({ name, handler })` | `ctx.command.transform(e => e.add({ name, execute }))` |
| `ctx.skill.transform(e => e.namespace(...))` | usunąć — `namespace` nie istnieje w `SkillEditor` |
| `export default definePlugin({...})` | `export default Plugin.define({ id, setup })` |
| `ctx.fs` / `ctx.shell` | `node:fs`, `node:child_process` |
| manifest `.codex-plugin/` | `package.json` + `exports` |
