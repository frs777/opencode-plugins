# Przykłady OpenCode V2

## 1. Prosty Plugin

```javascript
// index.mjs
import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'hello-plugin',
  name: 'Hello Plugin',
  version: '1.0.0',
  description: 'Witaj świecie plugin',
  async setup(ctx) {
    ctx.command.register({
      name: 'hello',
      description: 'Powiedz cześć',
      async handler(args) {
        const name = args.name || 'Świecie';
        return { success: true, message: `Cześć ${name}!` };
      }
    });
    return () => console.log('[hello-plugin] Unloaded');
  }
});
```

## 2. Plugin z Skillami

```javascript
// index.mjs
import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'multi-skill-plugin',
  name: 'Multi Skill Plugin',
  version: '1.0.0',
  description: 'Plugin z wieloma skillami',
  async setup(ctx) {
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'multi-skill' });
      
      editor.skill('create', {
        description: 'Tworzy nowe elementy',
        autoinvoke: true
      });
      
      editor.skill('analyze', {
        description: 'Analizuje kod',
        autoinvoke: false
      });
    });
    
    return () => console.log('[multi-skill] Unloaded');
  }
});
```

## 3. Skill z Logiką (SKILL.md)

```markdown
---
name: create
description: Tworzy nowe pluginy, skille, komendy
metadata:
  opencode/autoinvoke: true
---

# Create

Tworzy nowe elementy OpenCode V2.

## Kiedy używać
- "stwórz plugin"
- "utwórz skill"
- "dodaj komendę"

## Instrukcje
1. Zapytaj o nazwę i typ
2. Wygeneruj strukturę z szablonów
3. Zapisz pliki
4. Zweryfikuj poprawność
```

```javascript
// skills/create/scripts/main.js
export async function main(args, context) {
  const { name, type = 'plugin' } = args;
  
  // Generate from templates
  const templates = await loadTemplates(type);
  await writeFiles(name, templates);
  
  return { success: true, path: `./${name}` };
}
```

## 4. Komenda z Opcjami

```javascript
// commands/build/src/command.js
export async function handler(args, context) {
  const { target = 'all', verbose, clean } = args;
  
  if (clean) {
    await cleanBuild();
  }
  
  const result = await build(target, { verbose });
  
  return { success: true, output: result };
}
```

```json
// commands/build/command.json
{
  "name": "build",
  "description": "Buduje projekt",
  "version": "1.0.0",
  "entryPoint": "src/command.js",
  "commands": [{
    "name": "build",
    "description": "Buduje projekt",
    "usage": "build [target] [--clean] [--verbose]",
    "options": [
      { "name": "target", "description": "Cel budowania", "type": "string", "default": "all" },
      { "name": "clean", "short": "c", "description": "Wyczyść przed budowaniem", "type": "boolean" },
      { "name": "verbose", "short": "v", "description": "Szczegółowy output", "type": "boolean" }
    ]
  }]
}
```

## 5. Testy

```javascript
// tests/plugin.test.js
import { test } from 'node:test';
import assert from 'node:assert';
import { Plugin } from '@opencode/plugin';

test('plugin registers command', async () => {
  const { default: plugin } = await import('../index.mjs');
  const ctx = { command: { register: () => {} } };
  
  const cleanup = await plugin.setup(ctx);
  assert(typeof cleanup === 'function');
  cleanup();
});
```

## 6. Użycie fflate (ZIP)

```javascript
import { zipSync, unzipSync, strToU8, strFromU8 } from 'fflate';

// Create ZIP
const files = {
  'file.txt': strToU8('Hello'),
  'data.json': strToU8(JSON.stringify({ key: 'value' }))
};
const zip = zipSync(files);
await ctx.fs.write('archive.zip', Buffer.from(zip));

// Extract ZIP
const zipData = await ctx.fs.read('archive.zip');
const extracted = unzipSync(new Uint8Array(zipData));
const content = strFromU8(extracted['file.txt']);
```

## 7. Multilingual Handler

```javascript
const i18n = {
  pl: { created: 'Utworzono: {path}', error: 'Błąd: {msg}' },
  en: { created: 'Created: {path}', error: 'Error: {msg}' },
  zh: { created: '已创建: {path}', error: '错误: {msg}' }
};

function t(lang, key, params) {
  const msg = i18n[lang]?.[key] || i18n.pl[key];
  return msg.replace(/\{(\w+)\}/g, (_, k) => params[k] || '');
}

// Usage
const lang = detectLanguage(args); // from --lang or context
console.log(t(lang, 'created', { path: '/tmp/plugin' }));
```

## 8. Walidacja Nazwy

```javascript
function validateName(name) {
  // Tylko litery, cyfry, myślniki
  return /^[a-zA-Z0-9-]+$/.test(name) && name.length > 0 && name.length <= 50;
}

function toPascalCase(name) {
  return name.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('');
}

function toCamelCase(name) {
  const parts = name.split('-');
  return parts[0] + parts.slice(1).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('');
}
```

## 9. Plugin z Assets

```
my-plugin/
├── assets/
│   ├── logo.png        # 128x128, PNG
│   └── icon.png        # 32x32, PNG
├── opencode.json
└── index.mjs
```

```json
// opencode.json
{
  "opencode": {
    "id": "my-plugin",
    "setup": "index.mjs",
    "plugins": { "plugin": true },
    "assets": {
      "logo": "assets/logo.png",
      "icon": "assets/icon.png"
    }
  }
}
```

## 10. Pełny Plugin Builder (ten plugin)

```bash
# Użycie
opencode plugin-builder --plugin my-plugin
opencode plugin-builder --skill my-skill
opencode plugin-builder --command my-command

# Z opcjami
opencode plugin-builder --plugin my-plugin --output ./plugins --force
```