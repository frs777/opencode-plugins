# Przykłady OpenCode V2

## 1. Prosty plugin z komendą

```javascript
// index.mjs
import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'hello-plugin',
  async setup(ctx) {
    await ctx.command.transform((editor) => {
      editor.add({
        name: 'hello',
        description: 'Powiedz cześć',
        execute: async ({ sessionID, prompt, delivery }) => {
          await ctx.session.prompt({
            sessionID,
            text: 'Cześć! O co dokładnie chodziło w: ' + prompt.text,
            delivery,
          });
        },
      });
    });
    return () => console.log('[hello-plugin] Unloaded');
  },
});
```

## 2. Plugin ze skillem

```javascript
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Plugin } from '@opencode/plugin';

const DIR = fileURLToPath(new URL('.', import.meta.url));

export default Plugin.define({
  id: 'multi-skill-plugin',
  async setup(ctx) {
    await ctx.skill.transform((editor) => {
      editor.add({
        id: 'create',
        name: 'create',
        description: 'Tworzy nowe pluginy, skille i komendy',
        path: join(DIR, 'skills/create/SKILL.md'),
        content: readFileSync(join(DIR, 'skills/create/SKILL.md'), 'utf-8'),
      });
    });
  },
});
```

## 3. Skill (SKILL.md)

```markdown
---
name: create
description: Tworzy nowe pluginy, skille, komendy
metadata:
  opencode/autoinvoke: true
---

# Create

Tworzy nowe elementy OpenCode V2.

## Kiedy używać
- "stwórz plugin"
- "utwórz skill"
- "dodaj komendę"

## Instrukcje
1. Zapytaj o nazwę i typ
2. Wygeneruj strukturę z szablonów
3. Zapisz pliki
4. Zweryfikuj poprawność
```

## 4. Komenda (przez plugin)

```javascript
// index.mjs — samodzielny plik command.json NIE jest formatem OpenCode V2
await ctx.command.transform((editor) => {
  editor.add({
    name: 'build',
    description: 'Buduje projekt',
    execute: async ({ sessionID, prompt, delivery }) => {
      // prompt.text zawiera argumenty po nazwie komendy
      await ctx.session.prompt({ sessionID, text: `Zbuduj: ${prompt.text}`, delivery });
    },
  });
});
```

## 5. Testy

```javascript
// tests/plugin.test.js
import { test } from 'node:test';
import assert from 'node:assert';

test('plugin defines setup', async () => {
  const { default: plugin } = await import('../index.mjs');
  assert.equal(typeof plugin.setup, 'function');
});
```

Uruchomienie: `node --test tests/*.test.js`

## 6. ZIP bez zewnętrznych zależności

```javascript
import { writeFileSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';

// Spakuj katalog (wymaga `zip` w systemie)
execFileSync('zip', ['-r', '../plugin.zip', '.'], { cwd: 'plugin' });

// Lub po prostu skopiuj plik
writeFileSync('out.zip', readFileSync('in.zip'));
```

## 7. Wielojęzyczność

```javascript
const i18n = {
  pl: { created: 'Utworzono: {path}', error: 'Błąd: {msg}' },
  en: { created: 'Created: {path}', error: 'Error: {msg}' },
  zh: { created: '已创建: {path}', error: '错误: {msg}' },
};

function t(lang, key, params) {
  const msg = i18n[lang]?.[key] || i18n.pl[key];
  return msg.replace(/\{(\w+)\}/g, (_, k) => params[k] || '');
}

console.log(t('pl', 'created', { path: '/tmp/plugin' }));
```

## 8. Walidacja nazwy

```javascript
function validateName(name) {
  return /^[a-zA-Z0-9-]+$/.test(name) && name.length > 0 && name.length <= 50;
}

const toPascal = (name) => name.split('-').map((w) => w[0].toUpperCase() + w.slice(1)).join('');
const toCamel = (name) => {
  const parts = name.split('-');
  return parts[0] + parts.slice(1).map((w) => w[0].toUpperCase() + w.slice(1)).join('');
};
```

## 9. Sprawdzanie zgodności V1/V2

```bash
opencode plugin-builder --check /sciezka/do/wtyczki   # raport
opencode plugin-builder --fix /sciezka/do/wtyczki     # usuń błędny editor.namespace
```

## 10. Użycie tego buildera

```bash
opencode plugin-builder --plugin my-plugin
opencode plugin-builder --skill my-skill
opencode plugin-builder --command my-command

opencode plugin-builder --plugin my-plugin --output ./plugins --force
```
