import { existsSync, mkdirSync, writeFileSync, readFileSync, readdirSync, statSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
const __dirname = dirname(fileURLToPath(import.meta.url));
const TEMPLATES_DIR = join(__dirname, '..', 'assets', 'templates');
const REFERENCES_DIR = join(__dirname, '..', 'references');

const messages = {
  pl: {
    creatingPlugin: 'Tworzę plugin: {name}',
    creatingSkill: 'Tworzę skill: {name}',
    creatingCommand: 'Tworzę komendę: {name}',
    created: 'Utworzono: {path}',
    exists: 'Już istnieje: {path}',
    invalidName: 'Nieprawidłowa nazwa: {name}. Użyj tylko liter, cyfr, myślników.',
    missingName: 'Podaj nazwę. Użycie: --plugin|--skill|--command <nazwa>',
    unknownType: 'Nieznany typ. Użyj: --plugin, --skill, --command',
    help: `OpenCode Plugin Builder v1.0.0

Użycie:
  plugin-builder --plugin <nazwa>    Tworzy plugin (domyślne)
  plugin-builder --skill <nazwa>     Tworzy skill
  plugin-builder --command <nazwa>   Tworzy komendę

Opcje:
  --plugin, -p    Tworzy strukturę pluginu (domyślne)
  --skill, -s     Tworzy strukturę skillu
  --command, -c   Tworzy strukturę komendy
  --output, -o    Katalog wyjściowy (domyślnie: cwd/<nazwa>)
  --force, -f     Nadpisz istniejące pliki
  --check <kat>   Sprawdź zgodność katalogu wtyczki z V2 (markery V1)
  --fix <kat>     Usuń nieprawidłowe editor.namespace (tylko skill/command/agent)
  --help, -h      Pokaż tę pomoc

Przykłady:
  plugin-builder --plugin moj-plugin
  plugin-builder --skill moj-skill --output ./skills
  plugin-builder --command moja-komenda --force

Wielojęzyczność: Polish (domyślny), English, 中文, 日本語, Español, Français, Deutsch`
  },
  en: {
    creatingPlugin: 'Creating plugin: {name}',
    creatingSkill: 'Creating skill: {name}',
    creatingCommand: 'Creating command: {name}',
    created: 'Created: {path}',
    exists: 'Already exists: {path}',
    invalidName: 'Invalid name: {name}. Use only letters, numbers, hyphens.',
    missingName: 'Provide a name. Usage: --plugin|--skill|--command <name>',
    unknownType: 'Unknown type. Use: --plugin, --skill, --command',
    help: `OpenCode Plugin Builder v1.0.0

Usage:
  plugin-builder --plugin <name>    Creates plugin (default)
  plugin-builder --skill <name>     Creates skill
  plugin-builder --command <name>   Creates command

Options:
  --plugin, -p    Creates plugin structure (default)
  --skill, -s     Creates skill structure
  --command, -c   Creates command structure
  --output, -o    Output directory (default: cwd/<name>)
  --force, -f     Overwrite existing files
  --check <dir>   Check a plugin directory for V2 compatibility (V1 markers)
  --fix <dir>     Remove invalid editor.namespace (skill/command/agent only)
  --help, -h      Show this help

Examples:
  plugin-builder --plugin my-plugin
  plugin-builder --skill my-skill --output ./skills
  plugin-builder --command my-command --force

Multilingual: Polish (default), English, 中文, 日本語, Español, Français, Deutsch`
  },
  zh: {
    creatingPlugin: '正在创建插件: {name}',
    creatingSkill: '正在创建技能: {name}',
    creatingCommand: '正在创建命令: {name}',
    created: '已创建: {path}',
    exists: '已存在: {path}',
    invalidName: '无效名称: {name}. 仅使用字母、数字、连字符。',
    missingName: '请提供名称. 用法: --plugin|--skill|--command <name>',
    unknownType: '未知类型. 使用: --plugin, --skill, --command',
    help: `OpenCode Plugin Builder v1.0.0

用法:
  plugin-builder --plugin <name>    创建插件 (默认)
  plugin-builder --skill <name>     创建技能
  plugin-builder --command <name>   创建命令

选项:
  --plugin, -p    创建插件结构 (默认)
  --skill, -s     创建技能结构
  --command, -c   创建命令结构
  --output, -o    输出目录 (默认: cwd/<name>)
  --force, -f     覆盖现有文件
  --check <目录>   检查插件目录的 V2 兼容性 (V1 标记)
  --fix <目录>     删除无效的 editor.namespace (仅 skill/command/agent)
  --help, -h      显示帮助

示例:
  plugin-builder --plugin my-plugin
  plugin-builder --skill my-skill --output ./skills
  plugin-builder --command my-command --force

多语言: Polish (默认), English, 中文, 日本語, Español, Français, Deutsch`
  }
};

function detectLanguage(args) {
  const langArg = args.find(a => a.startsWith('--lang='));
  if (langArg) return langArg.split('=')[1].slice(0, 2);
  return 'pl';
}

function t(lang, key, params = {}) {
  const msg = messages[lang]?.[key] || messages.pl[key] || key;
  return msg.replace(/\{(\w+)\}/g, (_, k) => params[k] || '');
}

function validateName(name) {
  return /^[a-zA-Z0-9-]+$/.test(name) && name.length > 0;
}

function ensureDir(path) {
  if (!existsSync(path)) {
    mkdirSync(path, { recursive: true });
  }
}

function writeIfNotExists(filePath, content, force) {
  if (existsSync(filePath) && !force) {
    return false;
  }
  ensureDir(dirname(filePath));
  writeFileSync(filePath, content, 'utf-8');
  return true;
}

function renderTemplate(template, vars) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] || '');
}

async function loadTemplate(relative) {
  const path = join(TEMPLATES_DIR, `${relative}.template`);
  if (existsSync(path)) {
    return readFileSync(path, 'utf-8');
  }
  return null;
}

// --- Sprawdzanie i naprawa zgodności z OpenCode V2 -------------------------

const SOURCE_EXT = /\.(mjs|js|ts|tsx)$/;

const V1_MARKERS = [
  { re: /ctx\.command\.register\s*\(/, label: 'V1: ctx.command.register (V2: ctx.command.transform + editor.add)' },
  { re: /\bdefinePlugin\s*\(/, label: 'V1: definePlugin (V2: Plugin.define)' },
];

// namespace istnieje tylko na ToolEditorze; na skill/command/agent to blad V1
const NAMESPACE_RE = /(\w+)\.namespace\s*\(\s*\{[\s\S]*?\}\s*\)\s*;?/;

function splitTransforms(content) {
  const re = /ctx\.(\w+)\.transform\s*\(/g;
  const out = [];
  let m;
  while ((m = re.exec(content))) {
    if (out.length) out[out.length - 1].text = content.slice(out[out.length - 1].index, m.index);
    out.push({ domain: m[1], index: m.index });
  }
  if (out.length) out[out.length - 1].text = content.slice(out[out.length - 1].index);
  return out;
}

function listSourceFiles(dir, base = dir, acc = []) {
  for (const entry of readdirSync(dir).sort()) {
    if (entry === 'node_modules' || entry === '.git' || entry === 'dist') continue;
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) {
      listSourceFiles(full, base, acc);
    } else if (SOURCE_EXT.test(entry)) {
      acc.push(full);
    }
  }
  return acc;
}

function scanContent(content) {
  const problems = [];
  for (const m of V1_MARKERS) {
    if (m.re.test(content)) problems.push(m.label);
  }
  for (const seg of splitTransforms(content)) {
    if (seg.domain !== 'tool' && NAMESPACE_RE.test(seg.text)) {
      problems.push(`editor.namespace w ctx.${seg.domain}.transform (namespace jest tylko w ctx.tool.transform)`);
    }
  }
  return problems;
}

function stripInvalidNamespaces(content) {
  const segs = splitTransforms(content);
  if (!segs.some((s) => s.domain !== 'tool' && NAMESPACE_RE.test(s.text))) {
    return { content, removed: 0 };
  }
  // ponytail: regex nie radzi sobie z zagniezdzonymi {}, wystarcza dla konwersji
  let out = content.slice(0, segs[0].index);
  let removed = 0;
  for (let i = 0; i < segs.length; i++) {
    const end = i + 1 < segs.length ? segs[i + 1].index : content.length;
    let chunk = content.slice(segs[i].index, end);
    if (segs[i].domain !== 'tool') {
      chunk = chunk.replace(NAMESPACE_RE, () => { removed++; return ''; });
    }
    out += chunk;
  }
  return { content: out, removed };
}

function checkPluginDir(target) {
  if (!existsSync(target)) {
    console.error(`Nie znaleziono: ${target}`);
    return 1;
  }
  const files = listSourceFiles(target);
  if (!files.length) {
    console.error(`Brak plików .mjs/.js/.ts/.tsx w: ${target}`);
    return 1;
  }
  let bad = 0;
  for (const file of files) {
    const problems = scanContent(readFileSync(file, 'utf-8'));
    if (!problems.length) continue;
    bad++;
    console.log(`\n${file}`);
    for (const p of problems) console.log(`  - ${p}`);
  }
  console.log(`\nPodsumowanie: ${bad}/${files.length} plików z problemami.`);
  if (bad === 0) console.log('Brak błędów V1/V2.');
  else console.log('Napraw automatycznie: --fix <katalog>');
  return bad === 0 ? 0 : 1;
}

function fixPluginDir(target) {
  if (!existsSync(target)) {
    console.error(`Nie znaleziono: ${target}`);
    return 1;
  }
  let total = 0;
  for (const file of listSourceFiles(target)) {
    const source = readFileSync(file, 'utf-8');
    const { content, removed } = stripInvalidNamespaces(source);
    if (removed) {
      writeFileSync(file, content, 'utf-8');
      console.log(`Naprawiono ${file} (usunięto ${removed})`);
      total += removed;
    }
  }
  console.log(`\nUsunięto ${total} nieprawidłowych wywołań editor.namespace.`);
  if (total) console.log('Sprawdź ponownie: --check <katalog>');
  const left = checkPluginDir(target);
  return left;
}

async function createPlugin(name, outputDir, force, lang) {
  const pluginDir = join(outputDir, name);
  ensureDir(pluginDir);

  const files = [
    { name: 'package.json', template: 'plugin/package.json' },
    { name: 'index.mjs', template: 'plugin/index.mjs' },
    { name: 'README.md', template: 'plugin/README.md' },
    { name: 'LICENSE', template: 'plugin/LICENSE' },
    { name: 'src/plugin.js', template: 'plugin/src/plugin.js' },
  ];

  const vars = {
    name,
    namePascal: name.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(''),
    nameCamel: name.split('-').map((w, i) => i === 0 ? w : w.charAt(0).toUpperCase() + w.slice(1)).join(''),
    author: 'frs',
    year: new Date().getFullYear(),
    description: `OpenCode V2 plugin: ${name}`,
  };

  let created = 0;
  for (const file of files) {
    const template = await loadTemplate(file.template);
    if (!template) continue;
    const content = renderTemplate(template, vars);
    const filePath = join(pluginDir, file.name);
    if (writeIfNotExists(filePath, content, force)) {
      created++;
      console.log(t(lang, 'created', { path: filePath }));
    } else {
      console.log(t(lang, 'exists', { path: filePath }));
    }
  }

  console.log(t(lang, 'created', { path: pluginDir }));
  return pluginDir;
}

async function createSkill(name, outputDir, force, lang) {
  const skillDir = join(outputDir, name);
  ensureDir(skillDir);

  const files = [
    { name: 'SKILL.md', template: 'skill/SKILL.md' },
    { name: 'scripts/main.js', template: 'skill/scripts/main.js' },
  ];

  const vars = {
    name,
    namePascal: name.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(''),
    author: 'frs',
    year: new Date().getFullYear(),
    description: `OpenCode V2 skill: ${name}`,
  };

  let created = 0;
  for (const file of files) {
    const template = await loadTemplate(file.template);
    if (!template) continue;
    const content = renderTemplate(template, vars);
    const filePath = join(skillDir, file.name);
    if (writeIfNotExists(filePath, content, force)) {
      created++;
      console.log(t(lang, 'created', { path: filePath }));
    } else {
      console.log(t(lang, 'exists', { path: filePath }));
    }
  }

  // Create references directory structure
  const refsDir = join(skillDir, 'references');
  ensureDir(refsDir);

  console.log(t(lang, 'created', { path: skillDir }));
  return skillDir;
}

async function createCommand(name, outputDir, force, lang) {
  // Komenda w OpenCode V2 to plugin rejestrujacy ja przez ctx.command.transform.
  return createPlugin(name, outputDir, force, lang);
}

export async function builder(args, context) {
  const lang = detectLanguage(args);

  if (args.includes('--help') || args.includes('-h')) {
    console.log(t(lang, 'help'));
    return;
  }

  const checkIdx = args.indexOf('--check');
  const fixIdx = args.indexOf('--fix');
  if (checkIdx !== -1 || fixIdx !== -1) {
    const target = args[(checkIdx !== -1 ? checkIdx : fixIdx) + 1];
    if (!target || target.startsWith('-')) {
      console.error('Podaj katalog wtyczki. Użycie: --check <katalog> | --fix <katalog>');
      return;
    }
    if (checkIdx !== -1) {
      return checkPluginDir(target);
    }
    return fixPluginDir(target);
  }

  let type = 'plugin';
  if (args.includes('--skill') || args.includes('-s')) type = 'skill';
  else if (args.includes('--command') || args.includes('-c')) type = 'command';
  else if (args.includes('--plugin') || args.includes('-p')) type = 'plugin';

  const nameArg = args.find(a => !a.startsWith('-'));
  if (!nameArg) {
    console.error(t(lang, 'missingName'));
    return;
  }

  if (!validateName(nameArg)) {
    console.error(t(lang, 'invalidName', { name: nameArg }));
    return;
  }

  const force = args.includes('--force') || args.includes('-f');
  let outputDir = process.cwd();
  const outIdx = args.findIndex(a => a === '--output' || a === '-o');
  if (outIdx !== -1 && args[outIdx + 1]) outputDir = args[outIdx + 1];
  const eqIdx = args.findIndex(a => a.startsWith('--output=') || a.startsWith('-o='));
  if (eqIdx !== -1) outputDir = args[eqIdx].split('=')[1];

  console.log(t(lang, `creating${type.charAt(0).toUpperCase() + type.slice(1)}`, { name: nameArg }));

  switch (type) {
    case 'plugin':
      await createPlugin(nameArg, outputDir, force, lang);
      break;
    case 'skill':
      await createSkill(nameArg, outputDir, force, lang);
      break;
    case 'command':
      await createCommand(nameArg, outputDir, force, lang);
      break;
  }
}