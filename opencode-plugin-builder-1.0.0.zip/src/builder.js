import { existsSync, mkdirSync, writeFileSync, readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { zipSync, unzipSync, strToU8, strFromU8 } from 'fflate';

const __dirname = dirname(fileURLToPath(import.meta.url));
const TEMPLATES_DIR = join(__dirname, '..', 'assets', 'templates');
const REFERENCES_DIR = join(__dirname, '..', 'references');

const messages = {
  pl: {
    creatingPlugin: 'Tworzę plugin: {name}',
    creatingSkill: 'Tworzę skill: {name}',
    creatingCommand: 'Tworzę komendę: {name}',
    created: 'Utworzono: {path}',
    exists: 'Już istnieje: {path}',
    invalidName: 'Nieprawidłowa nazwa: {name}. Użyj tylko liter, cyfr, myślników.',
    missingName: 'Podaj nazwę. Użycie: --plugin|--skill|--command <nazwa>',
    unknownType: 'Nieznany typ. Użyj: --plugin, --skill, --command',
    help: `OpenCode Plugin Builder v1.0.0

Użycie:
  plugin-builder --plugin <nazwa>    Tworzy plugin (domyślne)
  plugin-builder --skill <nazwa>     Tworzy skill
  plugin-builder --command <nazwa>   Tworzy komendę

Opcje:
  --plugin, -p    Tworzy strukturę pluginu (domyślne)
  --skill, -s     Tworzy strukturę skillu
  --command, -c   Tworzy strukturę komendy
  --output, -o    Katalog wyjściowy (domyślnie: cwd/<nazwa>)
  --force, -f     Nadpisz istniejące pliki
  --help, -h      Pokaż tę pomoc

Przykłady:
  plugin-builder --plugin moj-plugin
  plugin-builder --skill moj-skill --output ./skills
  plugin-builder --command moja-komenda --force

Wielojęzyczność: Polish (domyślny), English, 中文, 日本語, Español, Français, Deutsch`
  },
  en: {
    creatingPlugin: 'Creating plugin: {name}',
    creatingSkill: 'Creating skill: {name}',
    creatingCommand: 'Creating command: {name}',
    created: 'Created: {path}',
    exists: 'Already exists: {path}',
    invalidName: 'Invalid name: {name}. Use only letters, numbers, hyphens.',
    missingName: 'Provide a name. Usage: --plugin|--skill|--command <name>',
    unknownType: 'Unknown type. Use: --plugin, --skill, --command',
    help: `OpenCode Plugin Builder v1.0.0

Usage:
  plugin-builder --plugin <name>    Creates plugin (default)
  plugin-builder --skill <name>     Creates skill
  plugin-builder --command <name>   Creates command

Options:
  --plugin, -p    Creates plugin structure (default)
  --skill, -s     Creates skill structure
  --command, -c   Creates command structure
  --output, -o    Output directory (default: cwd/<name>)
  --force, -f     Overwrite existing files
  --help, -h      Show this help

Examples:
  plugin-builder --plugin my-plugin
  plugin-builder --skill my-skill --output ./skills
  plugin-builder --command my-command --force

Multilingual: Polish (default), English, 中文, 日本語, Español, Français, Deutsch`
  },
  zh: {
    creatingPlugin: '正在创建插件: {name}',
    creatingSkill: '正在创建技能: {name}',
    creatingCommand: '正在创建命令: {name}',
    created: '已创建: {path}',
    exists: '已存在: {path}',
    invalidName: '无效名称: {name}. 仅使用字母、数字、连字符。',
    missingName: '请提供名称. 用法: --plugin|--skill|--command <name>',
    unknownType: '未知类型. 使用: --plugin, --skill, --command',
    help: `OpenCode Plugin Builder v1.0.0

用法:
  plugin-builder --plugin <name>    创建插件 (默认)
  plugin-builder --skill <name>     创建技能
  plugin-builder --command <name>   创建命令

选项:
  --plugin, -p    创建插件结构 (默认)
  --skill, -s     创建技能结构
  --command, -c   创建命令结构
  --output, -o    输出目录 (默认: cwd/<name>)
  --force, -f     覆盖现有文件
  --help, -h      显示帮助

示例:
  plugin-builder --plugin my-plugin
  plugin-builder --skill my-skill --output ./skills
  plugin-builder --command my-command --force

多语言: Polish (默认), English, 中文, 日本語, Español, Français, Deutsch`
  }
};

function detectLanguage(args) {
  const langArg = args.find(a => a.startsWith('--lang='));
  if (langArg) return langArg.split('=')[1].slice(0, 2);
  return 'pl';
}

function t(lang, key, params = {}) {
  const msg = messages[lang]?.[key] || messages.pl[key] || key;
  return msg.replace(/\{(\w+)\}/g, (_, k) => params[k] || '');
}

function validateName(name) {
  return /^[a-zA-Z0-9-]+$/.test(name) && name.length > 0;
}

function ensureDir(path) {
  if (!existsSync(path)) {
    mkdirSync(path, { recursive: true });
  }
}

function writeIfNotExists(filePath, content, force) {
  if (existsSync(filePath) && !force) {
    return false;
  }
  ensureDir(dirname(filePath));
  writeFileSync(filePath, content, 'utf-8');
  return true;
}

function renderTemplate(template, vars) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] || '');
}

async function loadTemplate(type, name) {
  const path = join(TEMPLATES_DIR, type, `${name}.template`);
  if (existsSync(path)) {
    return readFileSync(path, 'utf-8');
  }
  return null;
}

async function createPlugin(name, outputDir, force, lang) {
  const pluginDir = join(outputDir, name);
  ensureDir(pluginDir);

  const files = [
    { name: 'opencode.json', template: 'plugin/opencode.json' },
    { name: 'package.json', template: 'plugin/package.json' },
    { name: 'index.mjs', template: 'plugin/index.mjs' },
    { name: 'README.md', template: 'plugin/README.md' },
    { name: 'LICENSE', template: 'plugin/LICENSE' },
    { name: 'src/plugin.js', template: 'plugin/src/plugin.js' },
    { name: 'src/index.js', template: 'plugin/src/index.js' },
  ];

  const vars = {
    name,
    namePascal: name.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(''),
    nameCamel: name.split('-').map((w, i) => i === 0 ? w : w.charAt(0).toUpperCase() + w.slice(1)).join(''),
    author: 'frs',
    year: new Date().getFullYear(),
    description: `OpenCode V2 plugin: ${name}`,
  };

  let created = 0;
  for (const file of files) {
    const template = await loadTemplate(file.template.split('/')[0], file.template.split('/')[1]);
    if (!template) continue;
    const content = renderTemplate(template, vars);
    const filePath = join(pluginDir, file.name);
    if (writeIfNotExists(filePath, content, force)) {
      created++;
      console.log(t(lang, 'created', { path: filePath }));
    } else {
      console.log(t(lang, 'exists', { path: filePath }));
    }
  }

  console.log(t(lang, 'created', { path: pluginDir }));
  return pluginDir;
}

async function createSkill(name, outputDir, force, lang) {
  const skillDir = join(outputDir, name);
  ensureDir(skillDir);

  const files = [
    { name: 'SKILL.md', template: 'skill/SKILL.md' },
    { name: 'scripts/main.js', template: 'skill/scripts/main.js' },
  ];

  const vars = {
    name,
    namePascal: name.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(''),
    author: 'frs',
    year: new Date().getFullYear(),
    description: `OpenCode V2 skill: ${name}`,
  };

  let created = 0;
  for (const file of files) {
    const template = await loadTemplate(file.template.split('/')[0], file.template.split('/')[1]);
    if (!template) continue;
    const content = renderTemplate(template, vars);
    const filePath = join(skillDir, file.name);
    if (writeIfNotExists(filePath, content, force)) {
      created++;
      console.log(t(lang, 'created', { path: filePath }));
    } else {
      console.log(t(lang, 'exists', { path: filePath }));
    }
  }

  // Create references directory structure
  const refsDir = join(skillDir, 'references');
  ensureDir(refsDir);

  console.log(t(lang, 'created', { path: skillDir }));
  return skillDir;
}

async function createCommand(name, outputDir, force, lang) {
  const cmdDir = join(outputDir, name);
  ensureDir(cmdDir);

  const files = [
    { name: 'command.json', template: 'command/command.json' },
    { name: 'src/command.js', template: 'command/src/command.js' },
    { name: 'README.md', template: 'command/README.md' },
  ];

  const vars = {
    name,
    namePascal: name.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(''),
    nameCamel: name.split('-').map((w, i) => i === 0 ? w : w.charAt(0).toUpperCase() + w.slice(1)).join(''),
    author: 'frs',
    year: new Date().getFullYear(),
    description: `OpenCode V2 command: ${name}`,
  };

  let created = 0;
  for (const file of files) {
    const template = await loadTemplate(file.template.split('/')[0], file.template.split('/')[1]);
    if (!template) continue;
    const content = renderTemplate(template, vars);
    const filePath = join(cmdDir, file.name);
    if (writeIfNotExists(filePath, content, force)) {
      created++;
      console.log(t(lang, 'created', { path: filePath }));
    } else {
      console.log(t(lang, 'exists', { path: filePath }));
    }
  }

  console.log(t(lang, 'created', { path: cmdDir }));
  return cmdDir;
}

export async function builder(args, context) {
  const lang = detectLanguage(args);

  if (args.includes('--help') || args.includes('-h')) {
    console.log(t(lang, 'help'));
    return;
  }

  let type = 'plugin';
  if (args.includes('--skill') || args.includes('-s')) type = 'skill';
  else if (args.includes('--command') || args.includes('-c')) type = 'command';
  else if (args.includes('--plugin') || args.includes('-p')) type = 'plugin';

  const nameArg = args.find(a => !a.startsWith('-'));
  if (!nameArg) {
    console.error(t(lang, 'missingName'));
    return;
  }

  if (!validateName(nameArg)) {
    console.error(t(lang, 'invalidName', { name: nameArg }));
    return;
  }

  const force = args.includes('--force') || args.includes('-f');
  const outputArg = args.find(a => a.startsWith('--output=') || a.startsWith('-o='));
  const outputDir = outputArg ? outputArg.split('=')[1] : process.cwd();

  console.log(t(lang, `creating${type.charAt(0).toUpperCase() + type.slice(1)}`, { name: nameArg }));

  switch (type) {
    case 'plugin':
      await createPlugin(nameArg, outputDir, force, lang);
      break;
    case 'skill':
      await createSkill(nameArg, outputDir, force, lang);
      break;
    case 'command':
      await createCommand(nameArg, outputDir, force, lang);
      break;
  }
}