import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'browser',
  name: 'Browser',
  version: '26.917.71314',
  description: 'Control the in-app browser',
  async setup(ctx) {
    return () => console.log('[browser] Plugin unloaded')
  }
})
