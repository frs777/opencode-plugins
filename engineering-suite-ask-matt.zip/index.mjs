import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-ask-matt',
  name: 'AskMatt',
  version: '2.0.0',
  description: 'Choose the right Matt flow',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-ask-matt', description: 'Choose the right Matt flow' })
    })

    return () => console.log('[engineering-suite-ask-matt] Plugin unloaded')
  }
})
