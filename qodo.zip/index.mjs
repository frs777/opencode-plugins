import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'qodo',
  name: 'Qodo',
  version: '2.0.13',
  description: 'Code intelligence and review',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'qodo', description: 'Code intelligence and review' })
    })

    return () => console.log('[qodo] Plugin unloaded')
  }
})
