# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: .well-known/ai-plugin.json (stripped: .well-known/ai-plugin.json)
- Skipped unsupported source entry: plugins/no-ai-slop/PRIVACY.md (stripped: plugins/no-ai-slop/PRIVACY.md)
- Skipped unsupported source entry: plugins/no-ai-slop/SUPPORT.md (stripped: plugins/no-ai-slop/SUPPORT.md)
- Skipped unsupported source entry: plugins/no-ai-slop/TERMS.md (stripped: plugins/no-ai-slop/TERMS.md)
- Skipped unsupported source entry: submission/listing.json (stripped: submission/listing.json)
- Skipped unsupported source entry: submission/reviewer-packet.json (stripped: submission/reviewer-packet.json)
- Skipped unsupported source entry: tests/test_distribution_pack.py (stripped: tests/test_distribution_pack.py)
- Skipped unsupported source entry: tests/test_github_action.py (stripped: tests/test_github_action.py)
- Skipped unsupported source entry: tests/test_host_workspace_skill.py (stripped: tests/test_host_workspace_skill.py)
- Skipped unsupported source entry: tests/test_plugin_contract.py (stripped: tests/test_plugin_contract.py)
- Skipped unsupported source entry: tests/test_repo_analyzer.py (stripped: tests/test_repo_analyzer.py)
- Skipped unsupported source entry: tests/test_sandbox_python_skill.py (stripped: tests/test_sandbox_python_skill.py)
- Skipped unsupported source entry: tests/test_self_hosting.py (stripped: tests/test_self_hosting.py)
- Skipped unsupported source entry: tests/test_skill_frontmatter_yaml.py (stripped: tests/test_skill_frontmatter_yaml.py)
- Skipped unsupported source entry: tests/test_skill_surface.py (stripped: tests/test_skill_surface.py)
- Skipped unsupported source entry: tests/test_validator_regressions.py (stripped: tests/test_validator_regressions.py)
- Skipped unsupported source entry: tests/test_workflows.py (stripped: tests/test_workflows.py)
- Skipped unsupported source entry: .skills.json (stripped: .skills.json)
- Skipped unsupported source entry: PRIVACY.md (stripped: PRIVACY.md)
- Skipped unsupported source entry: SUPPORT.md (stripped: SUPPORT.md)
- Skipped unsupported source entry: TERMS.md (stripped: TERMS.md)
- Skipped unsupported source entry: action.yml (stripped: action.yml)
- Skipped unsupported source entry: init.sh (stripped: init.sh)
- Skipped unsupported source entry: install.sh (stripped: install.sh)
- Skipped unsupported source entry: llms.txt (stripped: llms.txt)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs