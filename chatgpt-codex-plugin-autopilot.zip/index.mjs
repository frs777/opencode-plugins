import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'chatgpt-codex-plugin-autopilot',
  name: 'Plugin Autopilot',
  version: '0.7.0',
  description: 'Turn repos into plugins',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'chatgpt-codex-plugin-autopilot', description: 'Turn repos into plugins' })
    })

    return () => console.log('[chatgpt-codex-plugin-autopilot] Plugin unloaded')
  }
})
