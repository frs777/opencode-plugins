---
name: counterfactual-risk-engine
description: Compares do-nothing, dry-run-change, rollback, and defer scenarios for an operating objective.
metadata:
  opencode/autoinvoke: true
---

# Counterfactual Risk Engine

## Use when
- A team needs to know the likely result of acting, waiting, rolling back, or deferring.

## Governance
- Produces scenario analysis only.
- Recommends dry-run validation before any apply path.

## Output
- `scenarios`, `recommendedScenario`, `decision`, `safeNextAction`
