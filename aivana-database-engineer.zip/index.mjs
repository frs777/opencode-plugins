import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'aivana-database-engineer',
  name: 'Aivana Database Engineer',
  version: '1.1.0',
  description: 'Analyze database performance',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'aivana-database-engineer', description: 'Analyze database performance' })
    })

    return () => console.log('[aivana-database-engineer] Plugin unloaded')
  }
})
