import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'opencode-bacup',
  name: 'OpenCode Bacup',
  version: '1.0.0',
  description: 'Zapisuje i przywraca skompaktowany kontekst rozmowy.',
  async setup(ctx) {
    await ctx.tool.transform((editor) => {
      editor.namespace({ name: 'bacup', description: 'Zapis i przywrócenie skompaktowanego kontekstu rozmowy.' })
      editor.add({
        name: 'zapisz',
        description: 'Zapisz skompaktowany kontekst bieżącej rozmowy do pliku .json.gz i zwróć ścieżkę.',
        input: { type: 'object', properties: {}, required: [], additionalProperties: false },
        options: { namespace: 'bacup', codemode: true },
        execute: async (_input, tool) => {
          return { content: 'Bacup tool placeholder - see source' }
        },
      })
      editor.add({
        name: 'przywroc',
        description: 'Wczytaj skompaktowany kontekst rozmowy z pliku backupu .json.gz.',
        input: {
          type: 'object',
          properties: { plik: { type: 'string', description: 'Ścieżka do pliku backupu' } },
          required: ['plik'],
          additionalProperties: false,
        },
        options: { namespace: 'bacup', codemode: true },
        execute: async (input, tool) => {
          return { content: 'Bacup restore placeholder - see source' }
        },
      })
    })
    return () => console.log('[opencode-bacup] Plugin unloaded')
  },
})
