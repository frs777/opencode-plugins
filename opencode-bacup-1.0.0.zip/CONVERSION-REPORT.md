# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: src/index.ts (stripped: src/index.ts)
- Skipped unsupported source entry: tests/__pycache__/test_static.cpython-314-pytest-9.1.1.pyc (stripped: tests/__pycache__/test_static.cpython-314-pytest-9.1.1.pyc)
- Skipped unsupported source entry: tests/__pycache__/test_fixes.cpython-314-pytest-9.1.1.pyc (stripped: tests/__pycache__/test_fixes.cpython-314-pytest-9.1.1.pyc)
- Skipped unsupported source entry: tests/test_static.py (stripped: tests/test_static.py)
- Skipped unsupported source entry: tests/test_fixes.py (stripped: tests/test_fixes.py)
- Skipped unsupported source entry: .pytest_cache/v/cache/nodeids (stripped: .pytest_cache/v/cache/nodeids)
- Skipped unsupported source entry: .pytest_cache/v/cache/lastfailed (stripped: .pytest_cache/v/cache/lastfailed)
- Skipped unsupported source entry: .pytest_cache/CACHEDIR.TAG (stripped: .pytest_cache/CACHEDIR.TAG)
- Skipped unsupported source entry: index.ts (stripped: index.ts)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs