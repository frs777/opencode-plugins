import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-ux-critique',
  name: 'UXCritique',
  version: '2.0.0',
  description: 'Critique UX and hierarchy',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-ux-critique', description: 'Critique UX and hierarchy' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'engineering-suite-ux-critique', description: 'Critique UX and hierarchy agents' })
    })

    return () => console.log('[engineering-suite-ux-critique] Plugin unloaded')
  }
})
