import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'work-pets',
  name: 'Pets',
  version: '0.1.6',
  description: 'Create and manage animated ChatGPT pets, not real-world or other-app pets.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'work-pets', description: 'Create and manage animated ChatGPT pets, not real-world or other-app pets.' })
    })

    return () => console.log('[work-pets] Plugin unloaded')
  }
})
