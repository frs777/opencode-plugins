# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: rules/zuora-coding-agent.mdc (stripped: rules/zuora-coding-agent.mdc)
- Skipped unsupported source entry: templates/apex/CPQCustomization.cls (stripped: templates/apex/CPQCustomization.cls)
- Skipped unsupported source entry: templates/lwc-headless/component.js (stripped: templates/lwc-headless/component.js)
- Skipped unsupported source entry: templates/lwc-headless/component.js-meta.xml (stripped: templates/lwc-headless/component.js-meta.xml)
- Skipped unsupported source entry: templates/lwc-sidebar/component.html (stripped: templates/lwc-sidebar/component.html)
- Skipped unsupported source entry: templates/lwc-sidebar/component.js (stripped: templates/lwc-sidebar/component.js)
- Skipped unsupported source entry: templates/uat-test-starter/uat/design/testmatrix/.gitkeep (stripped: templates/uat-test-starter/uat/design/testmatrix/.gitkeep)
- Skipped unsupported source entry: templates/uat-test-starter/uat/execution/config/test_config.yaml (stripped: templates/uat-test-starter/uat/execution/config/test_config.yaml)
- Skipped unsupported source entry: templates/uat-test-starter/uat/execution/tests/test_scenarios/.gitkeep (stripped: templates/uat-test-starter/uat/execution/tests/test_scenarios/.gitkeep)
- Skipped unsupported source entry: templates/uat-test-starter/uat/execution/tests/test_utils/api_client.py (stripped: templates/uat-test-starter/uat/execution/tests/test_utils/api_client.py)
- Skipped unsupported source entry: templates/uat-test-starter/uat/execution/tests/test_utils/debug_utils.py (stripped: templates/uat-test-starter/uat/execution/tests/test_utils/debug_utils.py)
- Skipped unsupported source entry: templates/uat-test-starter/uat/execution/tests/test_utils/repo_paths.py (stripped: templates/uat-test-starter/uat/execution/tests/test_utils/repo_paths.py)
- Skipped unsupported source entry: templates/uat-test-starter/uat/execution/tests/test_utils/uat_root.py (stripped: templates/uat-test-starter/uat/execution/tests/test_utils/uat_root.py)
- Skipped unsupported source entry: templates/uat-test-starter/uat/pytest.ini (stripped: templates/uat-test-starter/uat/pytest.ini)
- Skipped unsupported source entry: templates/uat-test-starter/uat/requirements.txt (stripped: templates/uat-test-starter/uat/requirements.txt)
- Skipped unsupported source entry: templates/uat-test-starter/.zuora-uat.yaml (stripped: templates/uat-test-starter/.zuora-uat.yaml)
- Skipped unsupported source entry: templates/visualforce/Page.page (stripped: templates/visualforce/Page.page)
- Skipped unsupported source entry: CHANGELOG.md (stripped: CHANGELOG.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs