---
name: "source-command-zuora-uat-design"
description: "Extract test requirements from SDDs into design/testmatrix/"
---

# source-command-zuora-uat-design

Use this skill when the user asks to run the migrated source command `zuora-uat-design`.

## Command Template

Invoke the `zuora-uat-design` skill with the user's arguments.
