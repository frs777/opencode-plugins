---
name: "source-command-zuora-uat-build"
description: "Build test plan, API scripts, and UI docs for scoped features"
---

# source-command-zuora-uat-build

Use this skill when the user asks to run the migrated source command `zuora-uat-build`.

## Command Template

Invoke the `zuora-uat-build` skill with the user's arguments.
