---
name: "source-command-zuora-uat-run"
description: "Execute API and UI tests for scoped features"
---

# source-command-zuora-uat-run

Use this skill when the user asks to run the migrated source command `zuora-uat-run`.

## Command Template

Invoke the `zuora-uat-run` skill with the user's arguments.
