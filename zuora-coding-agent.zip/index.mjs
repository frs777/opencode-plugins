import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'zuora-coding-agent',
  name: 'Zuora Coding Agent',
  version: '1.5.4',
  description: 'Zuora development assistant for API integrations, Workflow, Meter, migrations, CPQ customizations, Quote Studio hooks/events, and best-practice validation. Powered by zuora-mcp.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'zuora-coding-agent', description: 'Zuora development assistant for API integrations, Workflow, Meter, migrations, CPQ customizations, Quote Studio hooks/events, and best-practice validation. Powered by zuora-mcp.' })
    })

    // Register commands
    await ctx.command.transform(editor => {
      editor.namespace({ name: 'zuora-coding-agent', description: 'Zuora development assistant for API integrations, Workflow, Meter, migrations, CPQ customizations, Quote Studio hooks/events, and best-practice validation. Powered by zuora-mcp. commands' })
    })

    return () => console.log('[zuora-coding-agent] Plugin unloaded')
  }
})
