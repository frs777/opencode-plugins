import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'opstruth',
  name: 'OpsTruth',
  version: '0.4.1',
  description: 'Verify coding work with proof',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'opstruth', description: 'Verify coding work with proof' })
    })

    return () => console.log('[opstruth] Plugin unloaded')
  }
})
