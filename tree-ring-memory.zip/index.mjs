import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'tree-ring-memory',
  name: 'Tree Ring Memory',
  version: '0.3.10',
  description: 'Durable memory for agents',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'tree-ring-memory', description: 'Durable memory for agents' })
    })

    return () => console.log('[tree-ring-memory] Plugin unloaded')
  }
})
