import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-project-os',
  name: 'engineering-project-os',
  version: '2.2.1',
  description: 'Keep long-running Codex work resumable and reuse verified failure knowledge safely between your own projects. ChatGPT is a companion for supplied files and portable bundles.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-project-os', description: 'Keep long-running Codex work resumable and reuse verified failure knowledge safely between your own projects. ChatGPT is a companion for supplied files and portable bundles.' })
    })

    return () => console.log('[engineering-project-os] Plugin unloaded')
  }
})
