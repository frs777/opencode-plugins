import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'convex',
  name: 'Convex',
  version: '2.0.1',
  description: 'Build and scale apps',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'convex', description: 'Build and scale apps' })
    })

    return () => console.log('[convex] Plugin unloaded')
  }
})
