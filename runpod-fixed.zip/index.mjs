import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'runpod',
  name: 'Runpod (Official)',
  version: '1.1.2',
  description: 'Official Runpod skills + MCP server — pods, serverless, runpodctl, flash.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'runpod', description: 'Official Runpod skills + MCP server — pods, serverless, runpodctl, flash.' })
    })

    return () => console.log('[runpod] Plugin unloaded')
  }
})
