import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-grill-me',
  name: 'GrillMe',
  version: '2.0.0',
  description: 'Interrogate plans and ideas',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-grill-me', description: 'Interrogate plans and ideas' })
    })

    return () => console.log('[engineering-suite-grill-me] Plugin unloaded')
  }
})
