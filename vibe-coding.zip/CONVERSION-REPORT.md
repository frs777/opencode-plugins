# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: CATALOG.html (stripped: CATALOG.html)
- Skipped unsupported source entry: catalog.json (stripped: catalog.json)
- Skipped unsupported source entry: package-files.json (stripped: package-files.json)
- Skipped unsupported source entry: requirements.txt (stripped: requirements.txt)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs