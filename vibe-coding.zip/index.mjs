import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'vibe-coding',
  name: 'vibe-coding',
  version: '1.3.0',
  description: 'Evidence-based coding workflows: 46 skills, 241 domain recipes, scoped implementation and verification.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'vibe-coding', description: 'Evidence-based coding workflows: 46 skills, 241 domain recipes, scoped implementation and verification.' })
    })

    return () => console.log('[vibe-coding] Plugin unloaded')
  }
})
