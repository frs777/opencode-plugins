import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'compound-engineering',
  name: 'Compound Engineering',
  version: '3.24.0',
  description: 'Plan, build, review, improve',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'compound-engineering', description: 'Plan, build, review, improve' })
    })

    return () => console.log('[compound-engineering] Plugin unloaded')
  }
})
