import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-research',
  name: 'Research',
  version: '2.0.0',
  description: 'Research trusted sources',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-research', description: 'Research trusted sources' })
    })

    return () => console.log('[engineering-suite-research] Plugin unloaded')
  }
})
