# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: examples/clean-skill/SKILL.md (stripped: examples/clean-skill/SKILL.md)
- Skipped unsupported source entry: examples/unsafe-skill/SKILL.md (stripped: examples/unsafe-skill/SKILL.md)
- Skipped unsupported source entry: examples/unsafe-skill/plugin.json (stripped: examples/unsafe-skill/plugin.json)
- Skipped unsupported source entry: fixtures/negative/hierarchy.md (stripped: fixtures/negative/hierarchy.md)
- Skipped unsupported source entry: fixtures/negative/least-privilege.json (stripped: fixtures/negative/least-privilege.json)
- Skipped unsupported source entry: fixtures/negative/narrow-delete.ps1 (stripped: fixtures/negative/narrow-delete.ps1)
- Skipped unsupported source entry: fixtures/negative/reviewed-download.md (stripped: fixtures/negative/reviewed-download.md)
- Skipped unsupported source entry: fixtures/positive/sg001.md (stripped: fixtures/positive/sg001.md)
- Skipped unsupported source entry: fixtures/positive/sg002.sh (stripped: fixtures/positive/sg002.sh)
- Skipped unsupported source entry: fixtures/positive/sg003.json (stripped: fixtures/positive/sg003.json)
- Skipped unsupported source entry: fixtures/positive/sg004.md (stripped: fixtures/positive/sg004.md)
- Skipped unsupported source entry: fixtures/positive/sg005.ps1 (stripped: fixtures/positive/sg005.ps1)
- Skipped unsupported source entry: fixtures/positive/sg006.ps1 (stripped: fixtures/positive/sg006.ps1)
- Skipped unsupported source entry: fixtures/positive/sg007.sh (stripped: fixtures/positive/sg007.sh)
- Skipped unsupported source entry: fixtures/positive/sg008.md (stripped: fixtures/positive/sg008.md)
- Skipped unsupported source entry: fixtures/fixture-manifest.json (stripped: fixtures/fixture-manifest.json)
- Skipped unsupported source entry: rules/default-rules.json (stripped: rules/default-rules.json)
- Skipped unsupported source entry: rules/non-coverage.json (stripped: rules/non-coverage.json)
- Skipped unsupported source entry: report.schema.json (stripped: report.schema.json)
- Skipped unsupported source entry: suppressions.schema.json (stripped: suppressions.schema.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs