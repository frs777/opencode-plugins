import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'agent-skillguard',
  name: 'Skill Risk Check',
  version: '0.1.5',
  description: 'Scan before you install.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'agent-skillguard', description: 'Scan before you install.' })
    })

    return () => console.log('[agent-skillguard] Plugin unloaded')
  }
})
