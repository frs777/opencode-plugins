import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'ai-review-skills',
  name: 'ai-review-skills',
  version: '0.3.2+codex.20260909134907',
  description: 'Evidence-preserving research, paper explanation, quotation, and HTML review workflows for ChatGPT and Codex.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'ai-review-skills', description: 'Evidence-preserving research, paper explanation, quotation, and HTML review workflows for ChatGPT and Codex.' })
    })

    return () => console.log('[ai-review-skills] Plugin unloaded')
  }
})
