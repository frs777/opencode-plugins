import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'ai-software-architect',
  name: 'AI Software Architect',
  version: '0.2.3',
  description: 'Choose best design patterns',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'ai-software-architect', description: 'Choose best design patterns' })
    })

    return () => console.log('[ai-software-architect] Plugin unloaded')
  }
})
