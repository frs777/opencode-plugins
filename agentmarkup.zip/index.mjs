import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'agentmarkup',
  name: 'AgentMarkup',
  version: '0.1.0',
  description: 'Make sites readable by AI',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'agentmarkup', description: 'Make sites readable by AI' })
    })

    return () => console.log('[agentmarkup] Plugin unloaded')
  }
})
