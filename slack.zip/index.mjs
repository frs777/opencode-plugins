import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'slack',
  name: 'Slack',
  version: '0.1.7',
  description: 'Read and manage Slack',
  async setup(ctx) {
    return () => console.log('[slack] Plugin unloaded')
  }
})
