import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'web-research-assistant',
  name: 'Web Research Assistant',
  version: '0.1.0',
  description: 'Research topics with sources',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'web-research-assistant', description: 'Research topics with sources' })
    })

    return () => console.log('[web-research-assistant] Plugin unloaded')
  }
})
