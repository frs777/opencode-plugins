import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-to-tickets',
  name: 'ToTickets',
  version: '2.0.0',
  description: 'Split specs into tickets',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-to-tickets', description: 'Split specs into tickets' })
    })

    return () => console.log('[engineering-suite-to-tickets] Plugin unloaded')
  }
})
