import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'temporal',
  name: 'Temporal',
  version: '0.4.2',
  description: 'Develop with Temporal',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'temporal', description: 'Develop with Temporal' })
    })

    return () => console.log('[temporal] Plugin unloaded')
  }
})
