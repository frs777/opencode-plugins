import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'codex-coordinator',
  name: 'Codex Coordinator',
  version: '0.4.0',
  description: 'Coordinate parallel Codex work',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'codex-coordinator', description: 'Coordinate parallel Codex work' })
    })

    return () => console.log('[codex-coordinator] Plugin unloaded')
  }
})
