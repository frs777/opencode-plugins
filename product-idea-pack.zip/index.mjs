import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'product-idea-pack',
  name: 'Product Idea Pack',
  version: '0.1.2',
  description: 'Make product ideas visible',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'product-idea-pack', description: 'Make product ideas visible' })
    })

    return () => console.log('[product-idea-pack] Plugin unloaded')
  }
})
