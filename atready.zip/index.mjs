import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'atready',
  name: 'AtReady',
  version: '0.1.14',
  description: 'Bring resource fit to the plan',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'atready', description: 'Bring resource fit to the plan' })
    })

    return () => console.log('[atready] Plugin unloaded')
  }
})
