import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-plan',
  name: 'Plan',
  version: '2.0.0',
  description: 'Turn requirements into plans',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-plan', description: 'Turn requirements into plans' })
    })

    return () => console.log('[engineering-suite-plan] Plugin unloaded')
  }
})
