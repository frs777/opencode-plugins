import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'vercel',
  name: 'Vercel',
  version: '0.54.1',
  description: 'Build and deploy apps',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'vercel', description: 'Build and deploy apps' })
    })

    // Register commands
    await ctx.command.transform(editor => {
      editor.namespace({ name: 'vercel', description: 'Build and deploy apps commands' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'vercel', description: 'Build and deploy apps agents' })
    })

    return () => console.log('[vercel] Plugin unloaded')
  }
})
