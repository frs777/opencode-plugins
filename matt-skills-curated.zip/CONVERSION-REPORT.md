# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: PRIVACY.md (stripped: PRIVACY.md)
- Skipped unsupported source entry: SUPPORT.md (stripped: SUPPORT.md)
- Skipped unsupported source entry: TERMS.md (stripped: TERMS.md)
- Skipped unsupported source entry: THIRD_PARTY_NOTICES.md (stripped: THIRD_PARTY_NOTICES.md)
- Skipped unsupported source entry: source-provenance.json (stripped: source-provenance.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs