import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'matt-skills-curated',
  name: 'Matt Skills Curated',
  version: '1.1.0',
  description: 'Curated AI & Dev Workflows',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'matt-skills-curated', description: 'Curated AI & Dev Workflows' })
    })

    return () => console.log('[matt-skills-curated] Plugin unloaded')
  }
})
