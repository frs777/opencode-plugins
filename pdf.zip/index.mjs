import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'pdf',
  name: 'PDF',
  version: '26.904.11930',
  description: 'Read, create, and verify PDFs',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'pdf', description: 'Read, create, and verify PDFs' })
    })

    return () => console.log('[pdf] Plugin unloaded')
  }
})
