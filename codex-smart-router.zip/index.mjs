import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'codex-smart-router',
  name: 'Smart Model Router',
  version: '0.2.1',
  description: 'Choose models for Codex tasks',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'codex-smart-router', description: 'Choose models for Codex tasks' })
    })

    return () => console.log('[codex-smart-router] Plugin unloaded')
  }
})
