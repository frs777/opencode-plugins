# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: THIRD_PARTY_LICENSES/agent-device-LICENSE (stripped: THIRD_PARTY_LICENSES/agent-device-LICENSE)
- Skipped unsupported source entry: THIRD_PARTY_LICENSES/react-native-testing-library-LICENSE (stripped: THIRD_PARTY_LICENSES/react-native-testing-library-LICENSE)
- Skipped unsupported source entry: THIRD_PARTY_NOTICES.md (stripped: THIRD_PARTY_NOTICES.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs