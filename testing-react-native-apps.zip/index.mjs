import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'testing-react-native-apps',
  name: 'Testing React Native Apps',
  version: '0.1.0',
  description: 'React Native testing and QA',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'testing-react-native-apps', description: 'React Native testing and QA' })
    })

    return () => console.log('[testing-react-native-apps] Plugin unloaded')
  }
})
