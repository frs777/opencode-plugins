# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: LICENSES/Apache-2.0.txt (stripped: LICENSES/Apache-2.0.txt)
- Skipped unsupported source entry: provenance/SOURCES.json (stripped: provenance/SOURCES.json)
- Skipped unsupported source entry: LICENSE-DOCUMENTATION.md (stripped: LICENSE-DOCUMENTATION.md)
- Skipped unsupported source entry: LICENSING.md (stripped: LICENSING.md)
- Skipped unsupported source entry: THIRD_PARTY_NOTICES.md (stripped: THIRD_PARTY_NOTICES.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs