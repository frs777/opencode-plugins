import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'mcp-boundary',
  name: 'MCP Boundary',
  version: '0.2.0',
  description: 'MCP engineering at the seam',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'mcp-boundary', description: 'MCP engineering at the seam' })
    })

    return () => console.log('[mcp-boundary] Plugin unloaded')
  }
})
