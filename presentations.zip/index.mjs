import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'presentations',
  name: 'Presentations',
  version: '26.904.11930',
  description: 'Create and edit presentations',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'presentations', description: 'Create and edit presentations' })
    })

    return () => console.log('[presentations] Plugin unloaded')
  }
})
