# OpenCode Plugin Bridge

Bidirectional converter for skill/plugin archives:

- ChatGPT/Codex -> OpenCode V2
- OpenCode V2 -> ChatGPT/Codex
- command namespace mapping: `gpt-*` <-> `oc-*`
- OpenCode skills are emitted as `.opencode/skills/<id>/SKILL.md`
- OpenCode commands are emitted as `.opencode/commands/<name>.md`
- lossy/unsupported entries are reported in `CONVERSION-REPORT.md`
- no source archive is modified in place

The implementation follows the current OpenCode V2 plugin, command, tool, instruction, and skill contracts.
