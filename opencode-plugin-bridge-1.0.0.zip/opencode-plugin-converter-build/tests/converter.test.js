import test from 'node:test';
import assert from 'node:assert/strict';
import { mapCommandName, normalizeSkillId, convertFrontmatter } from '../src/converter.js';

test('maps commands to oc/gpt namespaces', () => {
  assert.equal(mapCommandName('review'), 'oc-review');
  assert.equal(mapCommandName('gpt-review'), 'oc-review');
  assert.equal(mapCommandName('oc-review', 'reverse'), 'gpt-review');
  assert.equal(mapCommandName('review', 'reverse'), 'gpt-review');
});

test('normalizes skill ids to portable kebab-case', () => {
  assert.equal(normalizeSkillId('My Great Skill'), 'my-great-skill');
  assert.equal(normalizeSkillId('Foo__Bar'), 'foo-bar');
});

test('preserves skill frontmatter and adds an OpenCode marker', () => {
  const source = `---\nname: My Skill\ndescription: Do things\n---\nBody`;
  const out = convertFrontmatter(source, 'opencode');
  assert.match(out, /name: My Skill/);
  assert.match(out, /description: Do things/);
  assert.match(out, /metadata:/);
  assert.match(out, /opencode\/autoinvoke: true/);
});
