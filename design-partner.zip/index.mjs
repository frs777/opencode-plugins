import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'design-partner',
  name: 'Design Partner',
  version: '0.1.5',
  description: 'Build, critique, and polish UI',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'design-partner', description: 'Build, critique, and polish UI' })
    })

    return () => console.log('[design-partner] Plugin unloaded')
  }
})
