import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-ship',
  name: 'Ship',
  version: '2.0.0',
  description: 'Prepare software to ship',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-ship', description: 'Prepare software to ship' })
    })

    return () => console.log('[engineering-suite-ship] Plugin unloaded')
  }
})
