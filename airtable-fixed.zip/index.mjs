import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'airtable',
  name: 'Airtable',
  version: '7.0.0',
  description: 'Add structured data to ChatGPT',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'airtable', description: 'Add structured data to ChatGPT' })
    })

    return () => console.log('[airtable] Plugin unloaded')
  }
})
