import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'get-fable',
  name: 'get-fable',
  version: '1.5.1',
  description: 'AI coding lifecycle',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'get-fable', description: 'AI coding lifecycle' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'get-fable', description: 'AI coding lifecycle agents' })
    })

    return () => console.log('[get-fable] Plugin unloaded')
  }
})
