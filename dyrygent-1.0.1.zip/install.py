#!/usr/bin/env python3
"""Uniwersalny instalator Dyrygenta dla OpenCode V2.

Działa na Linuxie, macOS i Windows. Wykrywa system i katalog konfiguracji OpenCode,
kopiuje agentów, skill i komendę, a nadpisywane pliki odkłada do backupu.

Użycie:
    python3 install.py                 # instalacja do wykrytej konfiguracji
    python3 install.py --dest /ścieżka # wskazany katalog docelowy
    python3 install.py --dry-run       # pokaż plan, nie kopiuj
"""
from __future__ import annotations

import argparse
import filecmp
import os
import platform
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

FILES = [
    "agents/dyrygent.md",
    "agents/dyr-code.md",
    "agents/dyr-index.md",
    "agents/dyr-mech.md",
    "agents/dyr-review.md",
    "skills/dyrygent/SKILL.md",
    "commands/dyrygent.md",
]
AGENTS = ["dyrygent", "dyr-code", "dyr-index", "dyr-mech", "dyr-review"]
MIN_PYTHON = (3, 7)


def detect_dest() -> Path:
    """Kolejność: OPENCODE_CONFIG > istniejący katalog konfiguracji > domyślny ~/.config/opencode."""
    env = os.environ.get("OPENCODE_CONFIG")
    if env:
        return Path(env).expanduser()

    home = Path.home()
    candidates = [home / ".config" / "opencode"]
    if os.environ.get("XDG_CONFIG_HOME"):
        candidates.append(Path(os.environ["XDG_CONFIG_HOME"]) / "opencode")
    if os.environ.get("APPDATA"):
        candidates.append(Path(os.environ["APPDATA"]) / "opencode")
    for c in candidates:
        if c.is_dir():
            return c
    return home / ".config" / "opencode"


def main() -> int:
    ap = argparse.ArgumentParser(description="Instalator Dyrygenta dla OpenCode V2")
    ap.add_argument("--dest", help="katalog konfiguracji OpenCode (domyślnie wykryty)")
    ap.add_argument("--dry-run", action="store_true", help="pokaż plan, nie kopiuj")
    args = ap.parse_args()

    if sys.version_info < MIN_PYTHON:
        print("BŁĄD: wymagany Python %d.%d+" % MIN_PYTHON, file=sys.stderr)
        return 1

    src = Path(__file__).resolve().parent
    dest = Path(args.dest).expanduser().resolve() if args.dest else detect_dest().resolve()

    print("System:   %s (%s)" % (platform.system(), platform.machine()))
    print("Paczka:   %s" % src)
    print("Cel:      %s" % dest)

    missing = [f for f in FILES if not (src / f).is_file()]
    if missing:
        print("BŁĄD: w paczce brakuje plików: %s" % ", ".join(missing), file=sys.stderr)
        return 1

    if dest.exists() and not dest.is_dir():
        print("BŁĄD: %s istnieje i nie jest katalogiem" % dest, file=sys.stderr)
        return 1

    if args.dry_run:
        for f in FILES:
            target = dest / f
            if not target.is_file():
                state = "nowy"
            elif filecmp.cmp(src / f, target, shallow=False):
                state = "bez zmian"
            else:
                state = "nadpisze"
            print("  [%s] %s" % (state, f))
        return 0

    backup = dest / (".backup-dyrygent-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
    dest.mkdir(parents=True, exist_ok=True)
    changed = 0

    for f in FILES:
        source, target = src / f, dest / f
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.is_file():
            if filecmp.cmp(source, target, shallow=False):
                print("  =   %s (bez zmian)" % f)
                continue
            saved = backup / f
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
        shutil.copy2(source, target)
        changed += 1
        print("  OK  %s" % f)

    if backup.is_dir():
        print("Backup nadpisanych plików: %s" % backup)
    elif changed:
        print("Nowych plików: %d, nadpisanych: 0." % changed)
    else:
        print("Wszystko już aktualne.")

    exe = shutil.which("opencode")
    if not exe:
        print("opencode nie znaleziony w PATH — pliki zainstalowane, weryfikacja pominięta.")
        return 0

    print("Weryfikacja agentów:")
    try:
        proc = subprocess.run([exe, "api", "get", "/api/agent"], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError) as exc:
        print("  (nie udało się odczytać listy agentów: %s)" % exc)
        return 0

    out = proc.stdout or ""
    found = [n for n in AGENTS if '"name":"%s"' % n in out]
    for name in found:
        print("  OK  %s" % name)
    if len(found) < len(AGENTS):
        print("  UWAGA: wykryto %d/%d agentów — sprawdź, czy %s to właściwa konfiguracja."
              % (len(found), len(AGENTS), dest))
        return 1
    print("Gotowe. Uruchom: /dyrygent <cel>")
    return 0


if __name__ == "__main__":
    sys.exit(main())
