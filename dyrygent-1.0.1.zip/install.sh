#!/usr/bin/env bash
# Instalator Dyrygenta dla OpenCode V2 — Linux i macOS.
# Na Windows użyj install.bat. Uniwersalny wariant: python3 install.py
set -euo pipefail

DEST="${OPENCODE_CONFIG:-$HOME/.config/opencode}"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP="$DEST/.backup-dyrygent-$(date +%Y%m%d-%H%M%S)"

FILES=(
  agents/dyrygent.md
  agents/dyr-code.md
  agents/dyr-index.md
  agents/dyr-mech.md
  agents/dyr-review.md
  skills/dyrygent/SKILL.md
  commands/dyrygent.md
)

[ -d "$DEST" ] || { echo "BŁĄD: brak katalogu $DEST" >&2; exit 1; }

echo "Cel instalacji: $DEST"
skipped=0
installed=0
for f in "${FILES[@]}"; do
  [ -f "$SRC/$f" ] || { echo "BŁĄD: brak pliku w paczce: $f" >&2; exit 1; }
  mkdir -p "$DEST/$(dirname "$f")"
  # cmp jest w POSIX i na macOS; readlink -f nie istnieje na macOS
  if [ -f "$DEST/$f" ]; then
    if cmp -s "$SRC/$f" "$DEST/$f"; then
      echo "  =   $f (bez zmian)"
      skipped=$((skipped + 1))
      continue
    fi
    mkdir -p "$BACKUP/$(dirname "$f")"
    cp "$DEST/$f" "$BACKUP/$f"
  fi
  cp "$SRC/$f" "$DEST/$f"
  installed=$((installed + 1))
  echo "  ✔   $f"
done

if [ -d "$BACKUP" ]; then
  echo "Zainstalowanych plików: $installed, backup nadpisanych: $BACKUP"
elif [ "$installed" -gt 0 ]; then
  echo "Zainstalowanych plików: $installed, nadpisanych: 0."
else
  echo "Wszystko już aktualne (plików identycznych: $skipped)."
fi

if command -v opencode >/dev/null 2>&1; then
  echo "Weryfikacja agentów:"
  opencode api get /api/agent 2>/dev/null | grep -o '"name":"dyr[a-z-]*"' | sort -u || echo "  (nie udało się odczytać listy agentów)"
else
  echo "opencode nie znaleziony w PATH — pliki zainstalowane, weryfikacja pominięta."
fi
