import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'bettercontext',
  name: 'bettercontext',
  version: '0.2.2',
  description: 'Persistent AI memory, saved context, tasks, and local relay tools.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'bettercontext', description: 'Persistent AI memory, saved context, tasks, and local relay tools.' })
    })

    return () => console.log('[bettercontext] Plugin unloaded')
  }
})
