import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'nightshift',
  name: 'Nightshift',
  version: '0.25.3',
  description: 'Accountable, time-bounded coding shifts with a persistent punch list, mechanical guards, and reviewable receipts.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'nightshift', description: 'Accountable, time-bounded coding shifts with a persistent punch list, mechanical guards, and reviewable receipts.' })
    })

    return () => console.log('[nightshift] Plugin unloaded')
  }
})
