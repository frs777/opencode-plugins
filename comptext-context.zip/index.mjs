import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'comptext-context',
  name: 'CompText Context',
  version: '0.1.0',
  description: 'Compile minimal context.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'comptext-context', description: 'Compile minimal context.' })
    })

    return () => console.log('[comptext-context] Plugin unloaded')
  }
})
