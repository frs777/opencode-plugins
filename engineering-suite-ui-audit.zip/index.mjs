import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-ui-audit',
  name: 'UIAudit',
  version: '2.0.0',
  description: 'Audit UI quality and a11y',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-ui-audit', description: 'Audit UI quality and a11y' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'engineering-suite-ui-audit', description: 'Audit UI quality and a11y agents' })
    })

    return () => console.log('[engineering-suite-ui-audit] Plugin unloaded')
  }
})
