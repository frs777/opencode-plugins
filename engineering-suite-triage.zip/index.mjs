import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-triage',
  name: 'Triage',
  version: '2.0.0',
  description: 'Triage issues and PRs',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-triage', description: 'Triage issues and PRs' })
    })

    return () => console.log('[engineering-suite-triage] Plugin unloaded')
  }
})
