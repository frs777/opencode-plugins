import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'life-science-research',
  name: 'Life Science Research',
  version: '1.0.3',
  description: 'General life-sciences research with routing, evidence synthesis, and optional parallel subagent analysis',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'life-science-research', description: 'General life-sciences research with routing, evidence synthesis, and optional parallel subagent analysis' })
    })

    return () => console.log('[life-science-research] Plugin unloaded')
  }
})
