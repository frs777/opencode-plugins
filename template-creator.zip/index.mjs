import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'template-creator',
  name: 'Template Creator',
  version: '26.904.11930',
  description: 'Create or update reusable templates from reference content',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'template-creator', description: 'Create or update reusable templates from reference content' })
    })

    return () => console.log('[template-creator] Plugin unloaded')
  }
})
