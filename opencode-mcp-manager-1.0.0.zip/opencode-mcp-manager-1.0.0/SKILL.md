---
name: opencode-mcp-manager
description: Use when creating, installing, configuring, authenticating, validating, troubleshooting, or removing MCP servers for OpenCode V2. Supports local stdio and remote Streamable HTTP servers, project/global scope, OAuth/API-key configuration, protocol selection, permissions, timeouts, and evidence-based verification.
---

# OpenCode MCP Manager

Manage MCP servers for OpenCode V2 with a staged, evidence-first workflow.

## Safety
Never install, remove, authenticate, overwrite, or mutate an MCP server/configuration unless the user explicitly authorized that mutation. Read-only inspection is the default. Never put literal credentials into configuration; use `{env:NAME}`.

## Six levels

### Level 0 — Discover
Check `opencode --version`, current project, project/global OpenCode config locations, and `opencode mcp list`. Determine local vs remote, project vs global scope, authentication, and protocol. Never invent a missing endpoint, command, package, credential, or scope.

### Level 1 — Design
Create a server specification:
- `name`
- `type: local|remote`
- `scope: project|global`
- local: `command`, optional `cwd`, `environment`
- remote: absolute `url`, optional `headers`, `oauth`
- optional `protocol: legacy|auto|2026-07-28`, `codemode`, `disabled`, `timeout`

Exactly one transport is required.

### Level 2 — Generate
OpenCode V2 stores servers under `mcp.servers`:

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "servers": {
      "my-server": {
        "type": "local",
        "command": ["npx", "-y", "example-mcp-server"]
      }
    }
  }
}
```

Remote:
```jsonc
{
  "mcp": {
    "servers": {
      "my-server": {
        "type": "remote",
        "url": "https://example.com/mcp",
        "oauth": false,
        "headers": {
          "Authorization": "Bearer {env:MCP_API_KEY}"
        }
      }
    }
  }
}
```

Do not use the old V1 shape with server names directly under `mcp`.

### Level 3 — Install / Configure
Use:
- `opencode mcp add NAME --url URL`
- `opencode mcp add NAME --global --url URL`
- `opencode mcp add NAME -- COMMAND ARG...`
- `opencode mcp list`

For custom headers, OAuth client fields, timeouts, protocol, cwd, environment, or permissions, edit the appropriate `opencode.jsonc`. Before mutation, back up existing config unless the user explicitly says not to.

### Level 4 — Authenticate
Remote servers use OAuth by default. Use `opencode mcp auth NAME` or OpenCode `/mcps`. For API keys use `oauth: false` plus `{env:NAME}` headers. Verify only presence of credentials, never print their values.

### Level 5 — Verify / Troubleshoot
Run `opencode mcp list` and classify each server as connected, needs authentication, failed, disabled, unavailable, or unknown. Check config precedence, endpoint/command, auth, protocol, timeouts, local process/package availability, codemode, and permissions.

Protocol:
- `legacy`: default
- `auto`: probe 2026-07-28 and fall back to legacy
- `2026-07-28`: require that revision

A syntactically valid config is not proof of a connected server.

## Config precedence
Global: `~/.config/opencode/opencode.json(c)`.
Project: `opencode.json(c)` or `.opencode/opencode.json(c)`.
Project settings override matching global settings. A same-name project override replaces the whole server object at that precedence level, so repeat required fields.

## Security
Stop on unexplained secrets, unauthorized package installation, unclear high-risk endpoints, destructive removal, or overwriting unrelated servers. Use least privilege. Consider OpenCode permissions for dangerous normalized tool names such as `<server>_<tool>`.

## Bundled scripts
- `scripts/validate_opencode_config.py` — structural JSON/JSONC validator.
- `scripts/mcp_cli.py` — guarded `opencode mcp add/list/auth/logout`; mutations require `--apply`.
- `scripts/generate_server_config.py` — deterministic config fragment generator.
- `scripts/install-local.sh` and `scripts/install-remote.sh` — guarded CLI wrappers.
- `scripts/verify.sh` — read-only version/list verification.
- `tests/test_validate_opencode_config.py` — regression tests.

Inspect scripts before execution and report actual execution evidence.

## Completion
Report server name, transport, scope, effective config location, auth mode, protocol, `opencode mcp list` status, validation result, backup path if changed, and warnings.
