# Contract references
Primary documentation:
- https://opencode.ai/v2/docs/mcp-servers/
- https://opencode.ai/v2/docs/config
- https://modelcontextprotocol.io/docs/2026-07-28/getting-started/intro

OpenCode V2: MCP servers live under `mcp.servers`; local uses `type: local` + `command`; remote uses `type: remote` + absolute Streamable HTTP `url`. Remote OAuth defaults to enabled; disable with `oauth: false` for header/API-key auth. Environment substitution uses `{env:NAME}`. Protocol supports `legacy`, `auto`, and `2026-07-28`. Project/global configuration has precedence rules; `opencode mcp list` is the connection-state check.
