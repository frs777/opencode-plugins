import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/"scripts"))
from validate_opencode_config import validate,strip_jsonc
def test_local(): assert not validate({"mcp":{"servers":{"x":{"type":"local","command":["node","x"],"environment":{"KEY":"{env:KEY}"}}}}})
def test_remote(): assert not validate({"mcp":{"servers":{"x":{"type":"remote","url":"https://example.com/mcp","oauth":False,"headers":{"Authorization":"Bearer {env:TOKEN}"},"protocol":"2026-07-28"}}}})
def test_remote_command_rejected(): assert any("must not define command" in x for x in validate({"mcp":{"servers":{"x":{"type":"remote","url":"https://example.com/mcp","command":["bad"]}}}}))
def test_secret_rejected(): assert any("sensitive header" in x for x in validate({"mcp":{"servers":{"x":{"type":"remote","url":"https://example.com/mcp","oauth":False,"headers":{"Authorization":"Bearer SECRET"}}}}}))
def test_jsonc(): assert json.loads(strip_jsonc('{"mcp":{"servers":{"x":{"type":"local","command":["node","x"],},},},}'))["mcp"]["servers"]["x"]["type"]=="local"
