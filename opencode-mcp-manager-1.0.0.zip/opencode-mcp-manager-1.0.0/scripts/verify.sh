#!/usr/bin/env bash
set -euo pipefail
opencode --version
opencode mcp list
