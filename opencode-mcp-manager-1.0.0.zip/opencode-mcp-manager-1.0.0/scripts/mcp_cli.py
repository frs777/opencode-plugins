#!/usr/bin/env python3
import argparse,shutil,subprocess,sys
p=argparse.ArgumentParser(); s=p.add_subparsers(dest="a",required=True)
q=s.add_parser("list")
q=s.add_parser("add"); q.add_argument("name"); q.add_argument("--global",dest="glob",action="store_true"); g=q.add_mutually_exclusive_group(required=True); g.add_argument("--url"); g.add_argument("--command",nargs="+")
q=s.add_parser("auth"); q.add_argument("name")
q=s.add_parser("logout"); q.add_argument("name")
p.add_argument("--apply",action="store_true"); a=p.parse_args()
if shutil.which("opencode") is None: print("ERROR: opencode not found",file=sys.stderr); raise SystemExit(127)
if a.a=="list": raise SystemExit(subprocess.call(["opencode","mcp","list"]))
if not a.apply:
    cmd=["opencode","mcp",a.a]
    if a.a=="add":
        cmd.append(a.name)
        if a.glob: cmd.append("--global")
        cmd += ["--url",a.url] if a.url else ["--"]+a.command
    else: cmd.append(a.name)
    print("DRY-RUN:"," ".join(cmd)); print("Use --apply to execute."); raise SystemExit(0)
cmd=["opencode","mcp",a.a]
if a.a=="add":
    cmd.append(a.name)
    if a.glob: cmd.append("--global")
    cmd += ["--url",a.url] if a.url else ["--"]+a.command
else: cmd.append(a.name)
raise SystemExit(subprocess.call(cmd))
