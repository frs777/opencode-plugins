#!/usr/bin/env bash
set -euo pipefail
if [[ ${1:-} != --apply ]]; then echo 'DRY-RUN: opencode mcp add' "$@"; exit 0; fi
shift
exec opencode mcp add "$@"
