#!/usr/bin/env python3
import argparse,json,re,sys
from pathlib import Path
ENV=re.compile(r"^\{env:[A-Za-z_][A-Za-z0-9_]*\}$")
PROTOCOLS={"legacy","auto","2026-07-28"}
def strip_jsonc(s):
    out=[]; i=0; q=False; esc=False
    while i<len(s):
        c=s[i]
        if q:
            out.append(c)
            if esc: esc=False
            elif c=="\\": esc=True
            elif c=='"': q=False
            i+=1; continue
        if c=='"': q=True; out.append(c); i+=1; continue
        if c=="/" and i+1<len(s) and s[i+1]=="/":
            i+=2
            while i<len(s) and s[i] not in "\r\n": i+=1
            continue
        if c=="/" and i+1<len(s) and s[i+1]=="*":
            i+=2
            while i+1<len(s) and not(s[i]=="*" and s[i+1]=="/"): i+=1
            i+=2; continue
        out.append(c); i+=1
    return re.sub(r",(\s*[}\]])",r"\1","".join(out))
def validate(doc):
    e=[]
    if not isinstance(doc,dict): return ["root must be an object"]
    m=doc.get("mcp")
    if m is None: return []
    if not isinstance(m,dict): return ["mcp must be an object"]
    s=m.get("servers")
    if s is None: return []
    if not isinstance(s,dict): return ["mcp.servers must be an object"]
    for n,v in s.items():
        if not isinstance(v,dict): e.append(f"{n}: server entry must be an object"); continue
        t=v.get("type")
        if t not in ("local","remote"): e.append(f"{n}: type must be local or remote"); continue
        if t=="local":
            if not isinstance(v.get("command"),list) or not v["command"] or not all(isinstance(x,str) and x for x in v["command"]): e.append(f"{n}: local command must be a non-empty string array")
            if "url" in v: e.append(f"{n}: local server must not define url")
            env=v.get("environment",{})
            if not isinstance(env,dict): e.append(f"{n}: environment must be an object")
            else:
                for k,x in env.items():
                    if not isinstance(k,str) or not isinstance(x,str): e.append(f"{n}: environment keys/values must be strings")
                    elif any(z in k.upper() for z in ("KEY","TOKEN","SECRET")) and x and not ENV.match(x): e.append(f"{n}: credential-like environment value should use {{env:NAME}}")
        else:
            u=v.get("url")
            if not isinstance(u,str) or not re.match(r"^https?://\S+$",u): e.append(f"{n}: remote url must be absolute http(s) URL")
            if "command" in v: e.append(f"{n}: remote server must not define command")
            h=v.get("headers",{})
            if not isinstance(h,dict): e.append(f"{n}: headers must be an object")
            else:
                for k,x in h.items():
                    if not isinstance(k,str) or not isinstance(x,str): e.append(f"{n}: header keys/values must be strings")
                    elif any(z in k.lower() for z in ("authorization","api-key","token","secret")) and not re.search(r"\{env:[A-Za-z_][A-Za-z0-9_]*\}", x): e.append(f"{n}: sensitive header {k} should reference an environment variable")
            o=v.get("oauth",True)
            if not (o is True or o is False or isinstance(o,dict)): e.append(f"{n}: oauth must be boolean or object")
            if isinstance(o,dict) and "client_secret" in o and not ENV.match(str(o["client_secret"])): e.append(f"{n}: oauth.client_secret should use {{env:NAME}}")
        if "protocol" in v and v["protocol"] not in PROTOCOLS: e.append(f"{n}: unsupported protocol")
        for k in ("disabled","codemode"):
            if k in v and not isinstance(v[k],bool): e.append(f"{n}: {k} must be boolean")
        if "timeout" in v:
            if not isinstance(v["timeout"],dict): e.append(f"{n}: timeout must be an object")
            else:
                for k,x in v["timeout"].items():
                    if k not in ("startup","catalog","execution") or not isinstance(x,int) or x<=0: e.append(f"{n}: invalid timeout.{k}")
    return e
def main():
    p=argparse.ArgumentParser(); p.add_argument("file"); a=p.parse_args()
    try: d=json.loads(strip_jsonc(Path(a.file).read_text()))
    except Exception as ex: print("INVALID JSON/JSONC:",ex); return 2
    e=validate(d)
    print("VALID" if not e else "INVALID")
    for x in e: print("-",x)
    return 0 if not e else 1
if __name__=="__main__": raise SystemExit(main())
