#!/usr/bin/env python3
import argparse,json
p=argparse.ArgumentParser(); p.add_argument("--name",required=True); p.add_argument("--type",choices=["local","remote"],required=True); p.add_argument("--command",nargs="+"); p.add_argument("--url"); p.add_argument("--protocol",choices=["legacy","auto","2026-07-28"]); p.add_argument("--oauth",choices=["true","false"]); p.add_argument("--codemode",choices=["true","false"]); p.add_argument("--disabled",choices=["true","false"]); p.add_argument("--cwd"); p.add_argument("--env",action="append",default=[]); p.add_argument("--header",action="append",default=[]); a=p.parse_args()
s={"type":a.type}
if a.type=="local":
    if not a.command: p.error("--command required"); s["command"]=a.command
    if a.cwd: s["cwd"]=a.cwd
    if a.env: s["environment"]=dict(x.split("=",1) for x in a.env)
else:
    if not a.url: p.error("--url required")
    s["url"]=a.url
    if a.header: s["headers"]=dict(x.split("=",1) for x in a.header)
    if a.oauth is not None: s["oauth"]=a.oauth=="true"
if a.protocol: s["protocol"]=a.protocol
if a.codemode is not None: s["codemode"]=a.codemode=="true"
if a.disabled is not None: s["disabled"]=a.disabled=="true"
print(json.dumps({"mcp":{"servers":{a.name:s}}},indent=2))
