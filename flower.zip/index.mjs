import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'flower',
  name: 'Flower',
  version: '0.3.3',
  description: 'Java flows & governed actions',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'flower', description: 'Java flows & governed actions' })
    })

    return () => console.log('[flower] Plugin unloaded')
  }
})
