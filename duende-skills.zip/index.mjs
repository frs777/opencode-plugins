import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'duende-skills',
  name: 'Duende Skills',
  version: '0.3.0',
  description: 'IdentityServer & OAuth skills',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'duende-skills', description: 'IdentityServer & OAuth skills' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'duende-skills', description: 'IdentityServer & OAuth skills agents' })
    })

    return () => console.log('[duende-skills] Plugin unloaded')
  }
})
