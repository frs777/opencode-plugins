import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'coderabbit',
  name: 'CodeRabbit',
  version: '1.1.4',
  description: 'Run AI-powered code review for your current changes',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'coderabbit', description: 'Run AI-powered code review for your current changes' })
    })

    return () => console.log('[coderabbit] Plugin unloaded')
  }
})
