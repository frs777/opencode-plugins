import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'fallow',
  name: 'Fallow Code Analysis',
  version: '1.2.23',
  description: 'Local JS/TS code analysis',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'fallow', description: 'Local JS/TS code analysis' })
    })

    return () => console.log('[fallow] Plugin unloaded')
  }
})
