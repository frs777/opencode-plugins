# Isolation Gate

## Purpose
Confirm mutation can happen safely before the first file change.

This file owns mutation-safety pass/fail. A mutation skill supplies its intended blast radius; it does not redefine workspace isolation.

This gate protects user work, local experiments, and unrelated files. It is binary: either the workspace is isolated for the requested blast radius, or mutation stops.

## Required checks
1. Identify the workspace:
   - Run `git rev-parse --show-toplevel`.
   - Run `git branch --show-current`.
   - Run `git worktree list` or compare `git rev-parse --git-dir` with `git rev-parse --git-common-dir`.
2. Capture dirty state:
   - Run `git status --porcelain` before editing.
   - Treat every listed path as user-owned until proven otherwise.
3. State the planned blast radius:
   - List the exact files or directories expected to change.
   - List protected files, generated files, scripts, tests, and modules that must not change.
4. Compare dirty files to planned changes:
   - Planned + clean: safe to edit.
   - Planned + already dirty: ask whether to build on, inspect, or avoid those changes.
   - Unplanned + dirty: do not touch.
5. Build a collision matrix before mutation.

## Collision matrix

Ownership is known only when it comes from an explicit user statement, a file created by the current task, or prior recorded handoff evidence. Everything else is user-owned or unknown.

| Dirty path | Planned to edit? | Owner known? | Action |
| --- | --- | --- | --- |
| No dirty paths | N/A | N/A | Pass |
| Dirty path inside blast radius | Yes | User/unknown | Ask before editing that file |
| Dirty path outside blast radius | No | User/unknown | Leave untouched |
| Dirty path is generated artifact | Maybe | Tool/unknown | Do not delete unless user approved |
| Dirty path conflicts with requested scope | Yes | Unknown | Fail until clarified |

## Requested cleanup mode

Use this mode only for an explicit user request to remove an exact named target. It is a stricter isolation branch, not an exemption.

1. Resolve the exact named target as a literal path, worktree, branch, or artifact. Prove it is not the current workspace or worktree, a repository root, a protected path, or a broader target produced by a glob or unresolved variable.
2. Inspect dirty and untracked state for a worktree or path, and unmerged or unpushed state for a branch or commit. Record dependencies from other worktrees, refs, releases, or active processes.
3. Establish recoverability and a concrete restore path: remote ref, retained commit, tag, backup, trash location, or recreation command. Prefer a recoverable operation.
4. Hard exclusions fail unconditionally: an ambiguous, broad, glob-derived, or unresolved target; the current workspace; the current worktree; a repository root; a protected path; or an irrecoverable target. User approval cannot override these hard exclusions.
5. Risk-acceptable states—dirty, untracked, unmerged, unpushed, active, or depended-upon—fail and stop until they are disclosed, recovery remains viable, and the user makes a fresh explicit decision accepting the current risk.

Cleanup mode passes only when the target is proven outside the hard exclusions and the exact target, explicit request, state inspection, dependencies, recoverability, restore path, and any required fresh decision are recorded.

## Pass condition
Pass only when all are true:
- Workspace root, branch, and worktree state are known.
- `git status --porcelain` has been captured.
- Planned blast radius is explicit.
- Dirty files are either absent, guaranteed untouched, or planned dirty files with explicit user approval and recorded ownership/decision.
- No auto-stash, auto-commit, reset, checkout, unrequested cleanup, or unapproved generated-file deletion is needed. An explicitly requested cleanup must pass Requested cleanup mode.

## Fail action
Stop before changing files. Do not auto-stash, auto-commit, reset, or clean up anything outside Requested cleanup mode.

Report:

```text
Isolation Gate: FAIL
Workspace: <root>
Branch/worktree: <branch and worktree state>
Planned blast radius: <files/dirs>
Dirty files: <git status --porcelain output>
Collision: <which dirty paths overlap or create risk>
Needed decision: <ask user to approve, narrow scope, or provide a clean workspace>
```
