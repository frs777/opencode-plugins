import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'keystone',
  name: 'Keystone',
  version: '2.0.4',
  description: 'Plan, build, review, and ship',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'keystone', description: 'Plan, build, review, and ship' })
    })

    return () => console.log('[keystone] Plugin unloaded')
  }
})
