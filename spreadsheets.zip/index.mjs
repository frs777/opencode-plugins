import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'spreadsheets',
  name: 'Spreadsheets',
  version: '26.904.11930',
  description: 'Create and edit spreadsheets',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'spreadsheets', description: 'Create and edit spreadsheets' })
    })

    return () => console.log('[spreadsheets] Plugin unloaded')
  }
})
