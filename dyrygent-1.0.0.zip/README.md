# Dyrygent — orkiestrator pracy wielu agentów dla OpenCode V2

Zamienia jedno duże zlecenie w zestaw małych, rozłącznych elementów, dobiera wykonawcę
według kompetencji (model + uprawnienia), układa fale równoległe, weryfikuje wynik
i raportuje. Tani model nigdy nie dostaje pracy wymagającej rozumienia kodu — dostaje
indeksowanie. Mocny model nie marnuje się na skanowanie plików.

## Co zawiera paczka

| Ścieżka | Rola |
|---|---|
| `agents/dyrygent.md` | agent primary — dekompozycja, routing, fale, raport |
| `agents/dyr-code.md` | subagent — pisze i zmienia kod (edit + shell) |
| `agents/dyr-review.md` | subagent — ocenia wynik wg kryterium (read-only) |
| `agents/dyr-index.md` | subagent — czyta, skanuje, streszcza (read-only, bez shell) |
| `agents/dyr-mech.md` | subagent — masowe edycje wg jednej reguły (edit w zakresie) |
| `skills/dyrygent/SKILL.md` | procedura: element, fale, zlecenie, weryfikacja, raport |
| `commands/dyrygent.md` | wejście: `/dyrygent <cel>` |
| `install.sh` | instalator z backupem istniejących plików |

## Instalacja

### Wariant A — instalator (zalecany, robi backup)

```bash
unzip dyrygent-1.0.0.zip -d dyrygent
cd dyrygent
./install.sh
```

Zmienna `OPENCODE_CONFIG` pozwala wskazać inny katalog docelowy (domyślnie
`~/.config/opencode`). Nadpisywane pliki trafiają do `.backup-dyrygent-<data>`.

### Wariant B — rozpakowanie wprost do konfiguracji

```bash
cd ~/.config/opencode
unzip -o /ścieżka/dyrygent-1.0.0.zip
```

Struktura archiwum odpowiada strukturze katalogu konfiguracji, więc pliki lądują
we właściwych miejscach: `agents/`, `skills/dyrygent/`, `commands/`.

Po instalacji OpenCode przeładowuje konfigurację automatycznie — restart nie jest potrzebny.

## Wymagania

- OpenCode V2.
- Modele z providera `opencode/*-free` (domyślne w profilach). Podmiana modelu profilu
  to jedna linia `model:` w pliku `agents/dyr-*.md`.
- Agent `dyrygent` musi być uruchamiany jako primary — zagnieżdżanie subagentów w V2 ma
  głębokość 1, więc `dyr-*` nie odpali kolejnych subagentów.

## Profile i uprawnienia

| Profil | Model domyślny | Kontekst / output | Uprawnienia |
|---|---|---|---|
| `dyrygent` | `opencode/nemotron-3.5-super-vl-free` | 1M / 131k | tylko `subagent: dyr-*`; `edit` i `shell` zabronione |
| `dyr-code` | `opencode/minimax-m3.1-flash-free` | 1M / 512k | `edit` + `shell` |
| `dyr-review` | `opencode/nemotron-3.5-super-vl-free` | 1M / 131k | read-only |
| `dyr-index` | `opencode/nemotron-3.5-lightning-free` | 262k | read-only, bez `shell`/`execute` |
| `dyr-mech` | `opencode/nemotron-3.5-lightning-free` | 262k | `edit` w zadanym zakresie |

Bariery są twarde: profil bez `edit` fizycznie nie dostanie narzędzia edycji, więc nie da
się ich obejść poleceniem w prompcie.

## Użycie

```
/dyrygent Dodaj obsługę paginacji do listy zamówień i pokryj to testami
```

Dyrygent:

1. rozbija cel na elementy z zakresem i kryterium akceptacji,
2. przypisuje profil każdemu elementowi,
3. układa fale — niezależne elementy idą równolegle (`background: true`, maks. 4 na falę),
4. zleca, zbiera wyniki, poprawia po FAIL,
5. zwraca raport: element, profil, status, wynik.

## Weryfikacja instalacji

```bash
opencode api get /api/agent | grep -o '"name":"dyr[a-z-]*"' | sort -u
```

Powinno wypisać pięć nazw: `dyr-code`, `dyr-index`, `dyr-mech`, `dyr-review`, `dyrygent`.

## Znane ograniczenia

- Brak twardej kontroli kosztów i retry na innym profilu — to zadanie wtyczki (faza 5 planu).
- Modele `:free` mają limity po stronie providera; przy `429` element trzeba powtórzyć.
- Nakładające się zakresy plików w jednej fali pilnowane są procedurą, nie kodem.

## Licencja

MIT — patrz [LICENSE](LICENSE).
