#!/usr/bin/env bash
# Instalator Dyrygenta dla OpenCode V2.
# Kopiuje agentów, skill i komendę do katalogu konfiguracji, robi backup nadpisywanych plików.
set -euo pipefail

DEST="${OPENCODE_CONFIG:-$HOME/.config/opencode}"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP="$DEST/.backup-dyrygent-$(date +%Y%m%d-%H%M%S)"

FILES=(
  agents/dyrygent.md
  agents/dyr-code.md
  agents/dyr-index.md
  agents/dyr-mech.md
  agents/dyr-review.md
  skills/dyrygent/SKILL.md
  commands/dyrygent.md
)

[ -d "$DEST" ] || { echo "BŁĄD: brak katalogu $DEST" >&2; exit 1; }

echo "Cel instalacji: $DEST"
for f in "${FILES[@]}"; do
  [ -f "$SRC/$f" ] || { echo "BŁĄD: brak pliku w paczce: $f" >&2; exit 1; }
  mkdir -p "$DEST/$(dirname "$f")"
  if [ -f "$DEST/$f" ] && [ "$(readlink -f "$DEST/$f")" != "$(readlink -f "$SRC/$f")" ]; then
    mkdir -p "$BACKUP/$(dirname "$f")"
    cp "$DEST/$f" "$BACKUP/$f"
  fi
  if [ "$(readlink -f "$DEST/$f" 2>/dev/null)" != "$(readlink -f "$SRC/$f" 2>/dev/null)" ]; then
    cp "$SRC/$f" "$DEST/$f"
  fi
  echo "  ✔ $f"
done

if [ -d "$BACKUP" ]; then
  echo "Backup nadpisanych plików: $BACKUP"
fi

if command -v opencode >/dev/null 2>&1; then
  echo "Weryfikacja agentów:"
  opencode api get /api/agent 2>/dev/null | grep -o '"name":"dyr[a-z-]*"' | sort -u || echo "  (nie udało się odczytać listy agentów)"
else
  echo "opencode nie znaleziony w PATH — pliki zainstalowane, weryfikacja pominięta."
fi
