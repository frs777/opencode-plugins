import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-debug',
  name: 'Debug',
  version: '2.0.0',
  description: 'Diagnose and fix bugs',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-debug', description: 'Diagnose and fix bugs' })
    })

    return () => console.log('[engineering-suite-debug] Plugin unloaded')
  }
})
