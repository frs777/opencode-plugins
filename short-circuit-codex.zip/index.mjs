import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'short-circuit-codex',
  name: 'Short Circuit',
  version: '0.2.0',
  description: 'Senior Python Engineer',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'short-circuit-codex', description: 'Senior Python Engineer' })
    })

    return () => console.log('[short-circuit-codex] Plugin unloaded')
  }
})
