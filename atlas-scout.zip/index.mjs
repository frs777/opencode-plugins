import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'atlas-scout',
  name: 'Atlas Scout',
  version: '1.0.0-preview.29',
  description: 'Local structural code maps',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'atlas-scout', description: 'Local structural code maps' })
    })

    return () => console.log('[atlas-scout] Plugin unloaded')
  }
})
