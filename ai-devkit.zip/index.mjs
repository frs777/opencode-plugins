import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'ai-devkit',
  name: 'AI DevKit',
  version: '0.62.1',
  description: 'Structured dev workflows',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'ai-devkit', description: 'Structured dev workflows' })
    })

    return () => console.log('[ai-devkit] Plugin unloaded')
  }
})
