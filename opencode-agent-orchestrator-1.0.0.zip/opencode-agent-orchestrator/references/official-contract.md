# OpenCode V2 native contract

Primary sources:
- https://opencode.ai/v2/docs/agents/
- https://opencode.ai/v2/docs/instructions/#configuration
- https://opencode.ai/v2/docs/config/

Current contract used by this Skill:
- `AGENTS.md` is the active persistent project-instruction mechanism.
- V2 `instructions` accepts an array, but the current docs state that files/globs/URLs are not currently resolved into model instructions.
- Markdown agents use frontmatter and a Markdown body; the body becomes the agent `system` prompt.
- Project agents: `.opencode/agents/`; global agents: `~/.config/opencode/agents/`.
- JSONC agents are under `agents`.
- `mode`: `primary`, `subagent`, `all`.
- Parent agents control child-agent launch through ordered `subagent` permission rules.
- `hidden` affects visibility, not security.
- `permissions` are ordered `action`/`resource`/`effect` rules.
- `default_agent` selects a primary-capable default.
- Avoid legacy V1 fields such as `agent`, `permission`, `task`, `tools`, `disable`, `maxSteps`, and `prompt` in new V2 definitions.
