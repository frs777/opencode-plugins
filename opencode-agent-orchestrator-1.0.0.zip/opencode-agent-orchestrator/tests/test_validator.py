import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parents[1]/'scripts'))
from validate_opencode_agents import validate_config, validate_markdown
def test_native_orchestrator():
    d={'default_agent':'orchestrator','agents':{'orchestrator':{'mode':'primary','permissions':[{'action':'subagent','resource':'*','effect':'deny'},{'action':'subagent','resource':'reviewer','effect':'allow'}]},'reviewer':{'mode':'subagent'}}}
    assert validate_config(d)==[]
def test_legacy_agent_rejected(): assert any('legacy V1' in x for x in validate_config({'agent':{}}))
def test_default_subagent_rejected(): assert any('subagent-only' in x for x in validate_config({'default_agent':'x','agents':{'x':{'mode':'subagent'}}}))
def test_markdown_native(): assert validate_markdown(Path(__file__).parents[1]/'examples/agents/reviewer.md')==[]
