# Project Instructions

## Build
- Run the repository's documented typecheck and test commands after code changes.

## Architecture
- Keep changes within existing module boundaries unless architecture changes are explicitly requested.

## Verification
- Report tests actually executed.
- Do not claim runtime verification without evidence.

## Restrictions
- Do not edit generated files directly.
