---
description: Reviews changes for correctness and regressions without editing files
mode: subagent
permissions:
  - action: edit
    resource: "*"
    effect: deny
  - action: shell
    resource: "*"
    effect: deny
---

Review the current changes.

Check:
1. correctness
2. regressions
3. missing tests
4. security-sensitive changes

Return findings with severity, file, and line references.
Do not modify files.
