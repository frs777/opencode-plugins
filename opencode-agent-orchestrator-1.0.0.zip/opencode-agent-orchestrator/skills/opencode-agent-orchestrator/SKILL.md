---
name: opencode-agent-orchestrator
description: Use when creating, updating, validating, or organizing OpenCode V2 AGENTS.md instructions, Markdown subagents, JSONC agent definitions, and native orchestrators while preserving OpenCode's native file formats, hierarchy, modes, permissions, and discovery behavior.
---

# OpenCode Agent & Orchestrator Builder

Create and maintain OpenCode V2 project instructions, reusable agents/subagents, and orchestrators. Preserve OpenCode-native formats instead of introducing a custom abstraction layer.

## Native-format principle

Use the format OpenCode itself consumes:

- `AGENTS.md` for active persistent project instructions.
- `.opencode/agents/<name>.md` for reusable Markdown agents.
- `~/.config/opencode/agents/<name>.md` for global Markdown agents.
- `opencode.jsonc` / `opencode.json` for JSONC agent definitions, permissions, defaults, and configuration.
- `agents` in V2 config, not legacy `agent`.
- `permissions`, not legacy `permission`.
- `subagent`, not legacy `task`.
- `mode`, not legacy `disable`/`maxSteps`/`prompt` fields.
- Markdown agent body is the agent's `system` prompt.

Do not convert native OpenCode artifacts into a proprietary YAML/JSON schema.

## Five-level workflow

### Level 0 — Discover

Inspect before mutation:

1. `opencode --version`
2. repository root and current working directory
3. existing `AGENTS.md` files from workspace toward project root
4. `~/.config/opencode/AGENTS.md` when global guidance is relevant
5. `.opencode/agents/`
6. `~/.config/opencode/agents/`
7. `opencode.jsonc` / `opencode.json`
8. `.opencode/opencode.jsonc` / `.opencode/opencode.json`
9. existing agent names, modes, permissions, and `default_agent`

Do not claim a complete inventory if only a partial directory was inspected.

### Level 1 — Design

Classify the requested artifact:

| User asks for | Native artifact |
|---|---|
| project rules / coding instructions | `AGENTS.md` |
| reusable named subagent | `.opencode/agents/name.md` |
| global reusable agent | `~/.config/opencode/agents/name.md` |
| agent configuration inside config | `opencode.jsonc` → `agents` |
| orchestrator | primary/all agent + `permissions` allowing selected `subagent` targets |
| hidden internal worker | `mode: subagent` + `hidden: true` |
| default primary | `default_agent` + `agents.<name>.mode: primary` |

For each agent define purpose/description, `mode`, optional `model`, system instructions, permissions, and optional `steps`, `hidden`, `color`.

### Level 2 — Generate

#### AGENTS.md

Write ordinary Markdown. Do not add YAML frontmatter unless explicitly requested.

```markdown
# Project Instructions

## Build
- ...

## Architecture
- ...

## Conventions
- ...

## Verification
- ...

## Restrictions
- ...
```

Place it at the directory where the guidance should apply. OpenCode combines applicable `AGENTS.md` files from global/upward locations toward the current workspace.

V2 `instructions` config exists, but the current V2 docs state that its files, globs, and URLs are not yet resolved into model instructions. Prefer actual `AGENTS.md` for active instructions.

#### Markdown subagent

Use native frontmatter:

```markdown
---
description: Reviews code without modifying files
mode: subagent
model: provider/model
permissions:
  - action: edit
    resource: "*"
    effect: deny
  - action: shell
    resource: "*"
    effect: deny
---

Review the current changes for correctness, regressions, and missing tests.
Return findings with file and line references.
```

The Markdown body is the agent's system prompt.

Native locations:

- project: `.opencode/agents/<name>.md`
- global: `~/.config/opencode/agents/<name>.md`

Nested project paths become agent IDs, e.g. `.opencode/agents/team/reviewer.md` → `team/reviewer`.

#### JSONC agent

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "agents": {
    "reviewer": {
      "description": "Reviews changes without editing",
      "mode": "subagent",
      "system": "Review for correctness and regressions.",
      "permissions": [
        { "action": "edit", "resource": "*", "effect": "deny" }
      ]
    }
  }
}
```

Never emit legacy V1 `agent`, `permission`, `task`, `tools`, `disable`, `maxSteps`, or `prompt` fields for new V2 configuration.

### Level 3 — Build orchestrators

An OpenCode-native orchestrator is an agent, not a custom external runtime.

```jsonc
{
  "agents": {
    "orchestrator": {
      "description": "Coordinates bounded specialist subagents",
      "mode": "primary",
      "permissions": [
        { "action": "subagent", "resource": "*", "effect": "deny" },
        { "action": "subagent", "resource": "researcher", "effect": "allow" },
        { "action": "subagent", "resource": "reviewer", "effect": "ask" }
      ]
    }
  }
}
```

Markdown orchestrator:

```markdown
---
description: Coordinates specialist agents
mode: primary
---

# Orchestration

1. Decompose the task.
2. Delegate only to explicitly permitted specialist agents.
3. Keep independent research separate from implementation.
4. Consolidate evidence.
5. Verify the result.
```

Permissions determine which subagents an orchestrator may launch. `hidden` affects visibility, not security. Use permissions for access control.

### Level 4 — Permissions and safety

Permissions are ordered rules; the last matching rule wins.

```jsonc
"permissions": [
  { "action": "subagent", "resource": "*", "effect": "deny" },
  { "action": "subagent", "resource": "planner", "effect": "allow" },
  { "action": "subagent", "resource": "reviewer", "effect": "ask" }
]
```

Do not grant broad subagent access when the orchestrator needs only bounded workers. Read-only agents should explicitly deny `edit` and, where appropriate, `shell`.

### Level 5 — Validate

Check:

- native paths and requested scope
- Markdown frontmatter
- valid `mode`
- unique agent IDs at the relevant scope
- absence of legacy V1 fields
- orchestrators have explicit `subagent` permission rules
- read-only agents do not receive edit permission
- `default_agent` points to an existing primary-capable agent
- `AGENTS.md` remains ordinary Markdown
- generated artifacts preserve OpenCode-native formatting

When OpenCode is available, use read-only verification such as `opencode --version` and inspect configuration. Do not claim an agent was loaded or callable without evidence.

## Update strategy

When an artifact already exists: read it, preserve unrelated content, patch the smallest necessary section, revalidate, and report exact files changed. Never overwrite a customized `AGENTS.md` or agent merely to impose a template.

## Output contract

Report artifact type, exact native path, scope, agent ID, mode, model, subagent permissions, hidden status, validation status, and unresolved assumptions.
