#!/usr/bin/env python3
import argparse, json, re, sys
from pathlib import Path
VALID_MODES={"primary","subagent","all"}
LEGACY={"agent","permission","task","tools","disable","maxSteps","prompt"}
def strip_jsonc(s):
    out=[]; i=0; quote=False; esc=False
    while i<len(s):
        c=s[i]
        if quote:
            out.append(c)
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=='"': quote=False
            i+=1; continue
        if c=='"': quote=True; out.append(c); i+=1; continue
        if c=='/' and i+1<len(s) and s[i+1]=='/':
            i+=2
            while i<len(s) and s[i] not in '\r\n': i+=1
            continue
        if c=='/' and i+1<len(s) and s[i+1]=='*':
            i+=2
            while i+1<len(s) and not(s[i]=='*' and s[i+1]=='/'): i+=1
            i+=2; continue
        out.append(c); i+=1
    return re.sub(r',\s*([}\]])',r'\1',''.join(out))
def validate_config(doc):
    e=[]
    if not isinstance(doc,dict): return ['root must be object']
    if 'agent' in doc: e.append("legacy V1 field 'agent' found; use 'agents'")
    if 'agents' not in doc: return e
    if not isinstance(doc['agents'],dict): return e+['agents must be object']
    for name,a in doc['agents'].items():
        if not isinstance(a,dict): e.append(f'{name}: definition must be object'); continue
        if a.get('mode') not in (None,*VALID_MODES): e.append(f'{name}: invalid mode')
        if 'permission' in a: e.append(f"{name}: legacy 'permission'; use 'permissions'")
        if 'tools' in a: e.append(f"{name}: legacy 'tools'; use permissions")
        if 'prompt' in a: e.append(f"{name}: legacy 'prompt'; use system or Markdown body")
        if a.get('mode')=='primary' and a.get('hidden') is True: e.append(f'{name}: primary agent cannot be hidden')
        perms=a.get('permissions',[])
        if not isinstance(perms,list): e.append(f'{name}: permissions must be list')
        for p in perms if isinstance(perms,list) else []:
            if not isinstance(p,dict) or {'action','resource','effect'}-set(p): e.append(f'{name}: malformed permission rule')
            elif p['effect'] not in {'allow','ask','deny'}: e.append(f'{name}: invalid permission effect')
    if 'default_agent' in doc:
        d=doc['default_agent']
        if d not in doc['agents']: e.append(f"default_agent '{d}' not defined")
        elif doc['agents'][d].get('mode','all')=='subagent': e.append(f"default_agent '{d}' is subagent-only")
    return e
def validate_markdown(path):
    t=Path(path).read_text(); e=[]
    if not t.startswith('---\n'): return ['missing YAML frontmatter']
    end=t.find('\n---',4)
    if end<0: return ['unterminated frontmatter']
    fm=t[4:end]
    m=re.search(r'(?m)^mode:\s*(.+)$',fm)
    if m and m.group(1).strip() not in VALID_MODES: e.append('invalid mode')
    if re.search(r'(?m)^permission:',fm): e.append('legacy permission field; use permissions')
    if re.search(r'(?m)^prompt:',fm): e.append('legacy prompt field; Markdown body is system')
    return e
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('path'); a=ap.parse_args(); p=Path(a.path)
    try:
        if p.suffix in {'.json','.jsonc'}: e=validate_config(json.loads(strip_jsonc(p.read_text())))
        elif p.suffix=='.md': e=validate_markdown(p)
        else: e=['unsupported file']
    except Exception as ex: e=[f'parse error: {ex}']
    print('VALID' if not e else 'INVALID'); [print('- '+x) for x in e]; return 0 if not e else 1
if __name__=='__main__': raise SystemExit(main())
