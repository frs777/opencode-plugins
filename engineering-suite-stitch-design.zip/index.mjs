import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-stitch-design',
  name: 'StitchDesign',
  version: '2.0.0',
  description: 'Create DESIGN.md for Stitch',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-stitch-design', description: 'Create DESIGN.md for Stitch' })
    })

    return () => console.log('[engineering-suite-stitch-design] Plugin unloaded')
  }
})
