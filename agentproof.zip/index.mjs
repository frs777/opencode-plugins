import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'agentproof',
  name: 'AgentProof',
  version: '0.1.0',
  description: 'Local Codex session receipts',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'agentproof', description: 'Local Codex session receipts' })
    })

    return () => console.log('[agentproof] Plugin unloaded')
  }
})
