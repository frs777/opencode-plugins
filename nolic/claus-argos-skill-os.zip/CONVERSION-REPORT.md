# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: shared/backlog/post-portata-production-learning.md (stripped: shared/backlog/post-portata-production-learning.md)
- Skipped unsupported source entry: shared/expert-system/coding-agent-execution-model.md (stripped: shared/expert-system/coding-agent-execution-model.md)
- Skipped unsupported source entry: shared/expert-system/coding-agent-harness-model.md (stripped: shared/expert-system/coding-agent-harness-model.md)
- Skipped unsupported source entry: shared/expert-system/context-package.md (stripped: shared/expert-system/context-package.md)
- Skipped unsupported source entry: shared/expert-system/decision-authority-model.md (stripped: shared/expert-system/decision-authority-model.md)
- Skipped unsupported source entry: shared/expert-system/expert-role-registry.md (stripped: shared/expert-system/expert-role-registry.md)
- Skipped unsupported source entry: shared/expert-system/expert-routing-model.md (stripped: shared/expert-system/expert-routing-model.md)
- Skipped unsupported source entry: shared/expert-system/expert-standard.md (stripped: shared/expert-system/expert-standard.md)
- Skipped unsupported source entry: shared/expert-system/false-precision-policy.md (stripped: shared/expert-system/false-precision-policy.md)
- Skipped unsupported source entry: shared/expert-system/harness-complexity-policy.md (stripped: shared/expert-system/harness-complexity-policy.md)
- Skipped unsupported source entry: shared/expert-system/implementation-checkpoint-verification.md (stripped: shared/expert-system/implementation-checkpoint-verification.md)
- Skipped unsupported source entry: shared/expert-system/observable-ownership.md (stripped: shared/expert-system/observable-ownership.md)
- Skipped unsupported source entry: shared/expert-system/perceptual-quality-gates.md (stripped: shared/expert-system/perceptual-quality-gates.md)
- Skipped unsupported source entry: shared/expert-system/professional-discretion-policy.md (stripped: shared/expert-system/professional-discretion-policy.md)
- Skipped unsupported source entry: shared/expert-system/provider-capability-routing.md (stripped: shared/expert-system/provider-capability-routing.md)
- Skipped unsupported source entry: shared/expert-system/representation-strategy-contract.md (stripped: shared/expert-system/representation-strategy-contract.md)
- Skipped unsupported source entry: shared/expert-system/risk-adaptive-assurance-model.md (stripped: shared/expert-system/risk-adaptive-assurance-model.md)
- Skipped unsupported source entry: shared/expert-system/session-lifecycle.md (stripped: shared/expert-system/session-lifecycle.md)
- Skipped unsupported source entry: shared/expert-system/situation-response-matrix.md (stripped: shared/expert-system/situation-response-matrix.md)
- Skipped unsupported source entry: shared/expert-system/specialist-review-model.md (stripped: shared/expert-system/specialist-review-model.md)
- Skipped unsupported source entry: shared/expert-system/task-execution-contract.md (stripped: shared/expert-system/task-execution-contract.md)
- Skipped unsupported source entry: shared/expert-system/visual-checkpoint-policy.md (stripped: shared/expert-system/visual-checkpoint-policy.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs