import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'claus-argos-skill-os',
  name: 'Claus Argos Skill OS',
  version: '1.16.0',
  description: '110 expert workflows for life',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'claus-argos-skill-os', description: '110 expert workflows for life' })
    })

    return () => console.log('[claus-argos-skill-os] Plugin unloaded')
  }
})
