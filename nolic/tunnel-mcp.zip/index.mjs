import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'tunnel-mcp',
  name: 'Tunnel MCP',
  version: '0.1.4',
  description: 'Manage tunnel-client MCP tunnels from a source checkout or installed bundle.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'tunnel-mcp', description: 'Manage tunnel-client MCP tunnels from a source checkout or installed bundle.' })
    })

    // Register MCP servers
    await ctx.mcp.transform(editor => {
      editor.namespace({ name: 'tunnel-mcp', description: 'Manage tunnel-client MCP tunnels from a source checkout or installed bundle. MCP' })
    })

    return () => console.log('[tunnel-mcp] Plugin unloaded')
  }
})
