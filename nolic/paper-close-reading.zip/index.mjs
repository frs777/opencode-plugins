import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'paper-close-reading',
  name: 'Paper Close Reading',
  version: '1.5.0',
  description: 'AI-guided close paper reading',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'paper-close-reading', description: 'AI-guided close paper reading' })
    })

    return () => console.log('[paper-close-reading] Plugin unloaded')
  }
})
