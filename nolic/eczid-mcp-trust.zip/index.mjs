import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'eczid-mcp-trust',
  name: 'ECZ-ID MCP Trust',
  version: '0.1.1',
  description: 'Review MCP servers in a repo',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'eczid-mcp-trust', description: 'Review MCP servers in a repo' })
    })

    return () => console.log('[eczid-mcp-trust] Plugin unloaded')
  }
})
