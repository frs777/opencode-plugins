# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: 0.1.27/shared-references/ads-structure-and-context-playbook.md (stripped: 0.1.27/shared-references/ads-structure-and-context-playbook.md)
- Skipped unsupported source entry: 0.1.27/shared-references/auction-readiness-playbook.md (stripped: 0.1.27/shared-references/auction-readiness-playbook.md)
- Skipped unsupported source entry: 0.1.27/shared-references/campaign-create-preflight.md (stripped: 0.1.27/shared-references/campaign-create-preflight.md)
- Skipped unsupported source entry: 0.1.27/shared-references/consumers.json (stripped: 0.1.27/shared-references/consumers.json)
- Skipped unsupported source entry: 0.1.27/shared-references/event-quality.md (stripped: 0.1.27/shared-references/event-quality.md)
- Skipped unsupported source entry: 0.1.27/shared-references/handoff-state.md (stripped: 0.1.27/shared-references/handoff-state.md)
- Skipped unsupported source entry: 0.1.27/shared-references/help-center-guide.md (stripped: 0.1.27/shared-references/help-center-guide.md)
- Skipped unsupported source entry: 0.1.27/shared-references/image-asset-contract.md (stripped: 0.1.27/shared-references/image-asset-contract.md)
- Skipped unsupported source entry: 0.1.27/shared-references/insights-contract.md (stripped: 0.1.27/shared-references/insights-contract.md)
- Skipped unsupported source entry: 0.1.27/shared-references/measurement-readiness-playbook.md (stripped: 0.1.27/shared-references/measurement-readiness-playbook.md)
- Skipped unsupported source entry: 0.1.27/shared-references/product-feed-contract.md (stripped: 0.1.27/shared-references/product-feed-contract.md)
- Skipped unsupported source entry: 0.1.27/shared-references/write-safety.md (stripped: 0.1.27/shared-references/write-safety.md)
- Skipped unsupported source entry: 0.1.27/tests/test_action_ownership_contract.py (stripped: 0.1.27/tests/test_action_ownership_contract.py)
- Skipped unsupported source entry: 0.1.27/tests/test_creative_generation_contract.py (stripped: 0.1.27/tests/test_creative_generation_contract.py)
- Skipped unsupported source entry: 0.1.27/tests/test_reference_loading_contract.py (stripped: 0.1.27/tests/test_reference_loading_contract.py)
- Skipped unsupported source entry: 0.1.27/.app.json (stripped: 0.1.27/.app.json)
- Skipped unsupported source entry: 0.1.27/OWNERS (stripped: 0.1.27/OWNERS)
- Skipped unsupported source entry: 0.1.27/action_ownership.json (stripped: 0.1.27/action_ownership.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs