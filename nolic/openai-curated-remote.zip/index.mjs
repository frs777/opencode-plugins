import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'ads-manager',
  name: 'ChatGPT Ads Manager',
  version: '0.1.27',
  description: 'Manage ads and performance',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'ads-manager', description: 'Manage ads and performance' })
    })

    return () => console.log('[ads-manager] Plugin unloaded')
  }
})
