import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'gpts-to-plugin',
  name: 'GPTs to Plugin',
  version: '0.1.2+codex.20260921090000',
  description: 'Convert GPTs into plugins.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'gpts-to-plugin', description: 'Convert GPTs into plugins.' })
    })

    return () => console.log('[gpts-to-plugin] Plugin unloaded')
  }
})
