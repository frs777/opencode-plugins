import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'build-macos-apps',
  name: 'Build macOS Apps',
  version: '0.1.4',
  description: 'Build, debug, instrument, and implement macOS apps with SwiftUI and AppKit guidance',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'build-macos-apps', description: 'Build, debug, instrument, and implement macOS apps with SwiftUI and AppKit guidance' })
    })

    // Register commands
    await ctx.command.transform(editor => {
      editor.namespace({ name: 'build-macos-apps', description: 'Build, debug, instrument, and implement macOS apps with SwiftUI and AppKit guidance commands' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'build-macos-apps', description: 'Build, debug, instrument, and implement macOS apps with SwiftUI and AppKit guidance agents' })
    })

    return () => console.log('[build-macos-apps] Plugin unloaded')
  }
})
