# Noodle Seed official-directory skills plugin

This portable directory ships the shared adaptive `noodle-seed` skill for OpenAI and Claude plugin
directories without bundling an MCP server. In coding workspaces, the skill privately invokes the
release-pinned packaged launcher and continues to report only public `noodle ...` commands. In hosts
without command execution, it provides guidance without claiming that local or hosted work ran.
