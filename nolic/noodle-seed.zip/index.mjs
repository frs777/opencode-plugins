import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'noodle-seed',
  name: 'Noodle Seed',
  version: '0.33.58',
  description: 'Build and deploy MCP',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'noodle-seed', description: 'Build and deploy MCP' })
    })

    return () => console.log('[noodle-seed] Plugin unloaded')
  }
})
