# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: bin/noodle-plugin.mjs (stripped: bin/noodle-plugin.mjs)
- Skipped unsupported source entry: noodle-plugin-compatibility.json (stripped: noodle-plugin-compatibility.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs