import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'eczid-mcp-verifier',
  name: 'ECZ-ID MCP Verifier',
  version: '0.1.1',
  description: 'ECZ-ID public proof checks',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'eczid-mcp-verifier', description: 'ECZ-ID public proof checks' })
    })

    return () => console.log('[eczid-mcp-verifier] Plugin unloaded')
  }
})
