import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'dyslex-ai',
  name: 'Dyslex.ai',
  version: '0.3.7',
  description: 'Clearer agent interactions.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'dyslex-ai', description: 'Clearer agent interactions.' })
    })

    return () => console.log('[dyslex-ai] Plugin unloaded')
  }
})
