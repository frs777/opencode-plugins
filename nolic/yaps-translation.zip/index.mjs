import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'yaps-translation',
  name: 'Accurate Translation',
  version: '0.1.12',
  description: 'Translate locally, no tokens',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'yaps-translation', description: 'Translate locally, no tokens' })
    })

    return () => console.log('[yaps-translation] Plugin unloaded')
  }
})
