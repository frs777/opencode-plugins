import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'power-bi-report-builder-copilot',
  name: 'power-bi-report-builder-copilot',
  version: '0.1.0',
  description: 'Build, debug, and optimize Power BI paginated reports, semantic models, DAX, Power Query, and Fabric reporting architecture.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'power-bi-report-builder-copilot', description: 'Build, debug, and optimize Power BI paginated reports, semantic models, DAX, Power Query, and Fabric reporting architecture.' })
    })

    return () => console.log('[power-bi-report-builder-copilot] Plugin unloaded')
  }
})
