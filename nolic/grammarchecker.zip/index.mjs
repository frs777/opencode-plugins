import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'grammarchecker',
  name: 'grammarchecker',
  version: '1.0.2',
  description: 'Check and fix grammar, spelling and punctuation in any text, with clear explanations. Proofread essays, emails, resumes and posts, improve clarity and tone, learn the rules and get error-free writing.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'grammarchecker', description: 'Check and fix grammar, spelling and punctuation in any text, with clear explanations. Proofread essays, emails, resumes and posts, improve clarity and tone, learn the rules and get error-free writing.' })
    })

    return () => console.log('[grammarchecker] Plugin unloaded')
  }
})
