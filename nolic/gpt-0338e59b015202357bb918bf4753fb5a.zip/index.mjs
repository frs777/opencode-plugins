import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'gpt-0338e59b015202357bb918bf4753fb5a',
  name: 'CaseWrite',
  version: '0.1.1+bundle.2a533ecfe2092aa1ea395df7a4ec845c',
  description: 'Case Reviewer ',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'gpt-0338e59b015202357bb918bf4753fb5a', description: 'Case Reviewer ' })
    })

    return () => console.log('[gpt-0338e59b015202357bb918bf4753fb5a] Plugin unloaded')
  }
})
