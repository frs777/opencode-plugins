# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: dist/codex-connect.js (stripped: dist/codex-connect.js)
- Skipped unsupported source entry: dist/codex-hook.js (stripped: dist/codex-hook.js)
- Skipped unsupported source entry: dist/config.js (stripped: dist/config.js)
- Skipped unsupported source entry: dist/connect.js (stripped: dist/connect.js)
- Skipped unsupported source entry: dist/gate.js (stripped: dist/gate.js)
- Skipped unsupported source entry: dist/hook-core.js (stripped: dist/hook-core.js)
- Skipped unsupported source entry: dist/observe.js (stripped: dist/observe.js)
- Skipped unsupported source entry: dist/outbox.js (stripped: dist/outbox.js)
- Skipped unsupported source entry: dist/send.js (stripped: dist/send.js)
- Skipped unsupported source entry: hooks/hooks.json (stripped: hooks/hooks.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs