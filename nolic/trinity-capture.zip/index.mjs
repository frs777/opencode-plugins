import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'trinity-capture',
  name: 'Trinity',
  version: '0.3.4',
  description: 'Sync Codex sessions',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'trinity-capture', description: 'Sync Codex sessions' })
    })

    return () => console.log('[trinity-capture] Plugin unloaded')
  }
})
