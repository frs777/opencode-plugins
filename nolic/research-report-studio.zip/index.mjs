import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'research-report-studio',
  name: 'report writing tool',
  version: '1.1.3',
  description: '독자를 고려한 자연스러운 한국어 보고서 작성',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'research-report-studio', description: '독자를 고려한 자연스러운 한국어 보고서 작성' })
    })

    return () => console.log('[research-report-studio] Plugin unloaded')
  }
})
