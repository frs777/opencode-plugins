# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: licenses/avoid-ai-writing-MIT.txt (stripped: licenses/avoid-ai-writing-MIT.txt)
- Skipped unsupported source entry: licenses/avoid-ai-writing-NOTICE.md (stripped: licenses/avoid-ai-writing-NOTICE.md)
- Skipped unsupported source entry: licenses/natural-writing-CC-BY-4.0.md (stripped: licenses/natural-writing-CC-BY-4.0.md)
- Skipped unsupported source entry: licenses/natural-writing-NOTICE.md (stripped: licenses/natural-writing-NOTICE.md)
- Skipped unsupported source entry: licenses/natural-writing-sources.md (stripped: licenses/natural-writing-sources.md)
- Skipped unsupported source entry: NOTICE.md (stripped: NOTICE.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs