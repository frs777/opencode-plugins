import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'software-engineering-toolkit',
  name: 'Software Engineering Toolkit',
  version: '0.1.0',
  description: 'Ship disciplined software ',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'software-engineering-toolkit', description: 'Ship disciplined software ' })
    })

    return () => console.log('[software-engineering-toolkit] Plugin unloaded')
  }
})
