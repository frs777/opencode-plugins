---
name: research
description: Investigate engineering questions with high-trust primary sources and cited findings.
metadata:
  opencode/autoinvoke: true
---

# Engineering Research

Define the question, constraints, and decision. Prefer official documentation, standards, source code, issue trackers, papers, and first-party announcements. Capture findings, citations, alternatives, uncertainty, and the decision impact in a concise Markdown report.
