---
name: domain-modeling
description: Build a shared vocabulary and test it against real scenarios before changing code.
metadata:
  opencode/autoinvoke: true
---

# Domain Modeling

Extract domain terms, definitions, entities, states, events, invariants, ownership, and boundaries. Challenge ambiguous words with concrete examples and edge cases. Keep the glossary and decisions consistent with code, tests, and documentation.
