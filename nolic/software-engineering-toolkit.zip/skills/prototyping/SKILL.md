---
name: prototyping
description: Build small throwaway prototypes to answer uncertain design, interaction, or technical questions.
metadata:
  opencode/autoinvoke: true
---

# Prototyping

State the question the prototype must answer, keep scope intentionally disposable, explore materially different options when useful, measure the result, and document what was learned. Do not let a prototype silently become production architecture.
