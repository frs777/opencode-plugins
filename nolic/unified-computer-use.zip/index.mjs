import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'unified-computer-use',
  name: 'unified-computer-use',
  version: '26.917.71314',
  description: 'App-managed browser automation runtime.',
  async setup(ctx) {
    return () => console.log('[unified-computer-use] Plugin unloaded')
  }
})
