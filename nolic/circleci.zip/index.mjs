import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'circleci',
  name: 'CircleCI',
  version: '1.0.4',
  description: 'Build, test, and deploy any application',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'circleci', description: 'Build, test, and deploy any application' })
    })

    return () => console.log('[circleci] Plugin unloaded')
  }
})
