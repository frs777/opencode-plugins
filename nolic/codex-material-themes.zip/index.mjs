import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'codex-material-themes',
  name: 'Codex Material Themes',
  version: '1.0.2',
  description: 'Choose and export Codex themes',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'codex-material-themes', description: 'Choose and export Codex themes' })
    })

    return () => console.log('[codex-material-themes] Plugin unloaded')
  }
})
