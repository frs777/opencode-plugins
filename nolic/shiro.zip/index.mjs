import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'shiro',
  name: 'Shiro',
  version: '1.0.1',
  description: 'Fix your vibecoded UI ',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'shiro', description: 'Fix your vibecoded UI ' })
    })

    return () => console.log('[shiro] Plugin unloaded')
  }
})
