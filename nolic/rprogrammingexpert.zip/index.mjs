import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'rprogrammingexpert',
  name: 'rprogrammingexpert',
  version: '1.0.1',
  description: 'Your senior R expert: write, explain, debug and optimize R code, wrangle data with the tidyverse, build ggplot2 charts, run statistics and machine learning, and create Shiny apps, Quarto reports and R packages.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'rprogrammingexpert', description: 'Your senior R expert: write, explain, debug and optimize R code, wrangle data with the tidyverse, build ggplot2 charts, run statistics and machine learning, and create Shiny apps, Quarto reports and R packages.' })
    })

    return () => console.log('[rprogrammingexpert] Plugin unloaded')
  }
})
