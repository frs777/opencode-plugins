import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'codex-security',
  name: 'Codex Security',
  version: '0.1.24',
  description: 'Security scanning for your codebase',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'codex-security', description: 'Security scanning for your codebase' })
    })

    // Register tools
    await ctx.tool.transform(editor => {
      editor.namespace({ name: 'codex-security', description: 'Security scanning for your codebase tools' })
    })

    // Register MCP servers
    await ctx.mcp.transform(editor => {
      editor.namespace({ name: 'codex-security', description: 'Security scanning for your codebase MCP' })
    })

    return () => console.log('[codex-security] Plugin unloaded')
  }
})
