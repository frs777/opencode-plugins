# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: examples/completed-scan/coverage.json (stripped: examples/completed-scan/coverage.json)
- Skipped unsupported source entry: examples/completed-scan/findings.json (stripped: examples/completed-scan/findings.json)
- Skipped unsupported source entry: examples/completed-scan/report.md (stripped: examples/completed-scan/report.md)
- Skipped unsupported source entry: examples/completed-scan/scan-manifest.json (stripped: examples/completed-scan/scan-manifest.json)
- Skipped unsupported source entry: preflight/capability-profiles.toml (stripped: preflight/capability-profiles.toml)
- Skipped unsupported source entry: schemas/definitions/artifact-common.schema.json (stripped: schemas/definitions/artifact-common.schema.json)
- Skipped unsupported source entry: schemas/definitions/discovery-candidate.schema.json (stripped: schemas/definitions/discovery-candidate.schema.json)
- Skipped unsupported source entry: schemas/coverage.schema.json (stripped: schemas/coverage.schema.json)
- Skipped unsupported source entry: schemas/findings.schema.json (stripped: schemas/findings.schema.json)
- Skipped unsupported source entry: schemas/patch-risk-assessment.schema.json (stripped: schemas/patch-risk-assessment.schema.json)
- Skipped unsupported source entry: schemas/scan-manifest.schema.json (stripped: schemas/scan-manifest.schema.json)
- Skipped unsupported source entry: .app.json (stripped: .app.json)
- Skipped unsupported source entry: .mcp.json (stripped: .mcp.json)
- Skipped unsupported source entry: OWNERS (stripped: OWNERS)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs