import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'google-calendar',
  name: 'Google Calendar',
  version: '1.2.6',
  description: 'Manage Google Calendar events',
  async setup(ctx) {
    return () => console.log('[google-calendar] Plugin unloaded')
  }
})
