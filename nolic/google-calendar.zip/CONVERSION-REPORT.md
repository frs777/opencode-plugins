# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: tests/test_google_calendar_plugin_contract.py (stripped: tests/test_google_calendar_plugin_contract.py)
- Skipped unsupported source entry: .app.json (stripped: .app.json)
- Skipped unsupported source entry: .mcp.json (stripped: .mcp.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs