import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'writingassistant',
  name: 'Writing Assistant',
  version: '1.0.1',
  description: 'Write, rewrite and proofread',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'writingassistant', description: 'Write, rewrite and proofread' })
    })

    return () => console.log('[writingassistant] Plugin unloaded')
  }
})
