import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'gh-review-loop',
  name: 'GH Review Loop',
  version: '0.4.2',
  description: 'Capped AI PR review fix loop',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'gh-review-loop', description: 'Capped AI PR review fix loop' })
    })

    return () => console.log('[gh-review-loop] Plugin unloaded')
  }
})
