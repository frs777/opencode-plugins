#!/usr/bin/env python3
"""PreToolUse gate: enforce verification-profile-before-fixes during the loop.

The skill requires that, on the first run for a repo, the verification profile
is set up (detect -> preset menu -> save) *before* any fix is applied — so the
verification strategy is fixed before edits. That ordering was previously prose
the agent could skip. This gate makes it mechanical.

It blocks Edit/Write/MultiEdit only in the precise violation window: a Gemini
loop is active for the current repo AND no profile decision has been saved yet.
Saving any profile — including a deliberate Skip — satisfies the gate, so the
agent unblocks itself simply by making the decision the skill already asks for.

Fails OPEN: any error (not a repo, judge unimportable, malformed payload) allows
the edit. A visibility/ordering aid must never wedge unrelated editing.
"""

from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from loop_state import (  # noqa: E402 — slim, stdlib-only (see #83)
    any_active_run,
    find_active_run,
    reap_stale_sentinel,
    resolve_current_repo,
)
from hook_runtime import load_hook_payload, tool_name  # noqa: E402


def profile_required_for_repo(repo_full: str) -> bool:
    """True when an edit should be blocked pending a profile decision.

    Requires an active loop for the repo and no saved profile. Fails open
    (returns False) if the judge module can't be imported.
    """
    if find_active_run(repo_full) is None:
        return False
    try:
        import judge  # noqa: PLC0415
    except ImportError:
        return False
    return judge.get_profile(repo_full) is None


BLOCK_MESSAGE = (
    "[gh-review-loop] A review loop is active for {repo} and no "
    "verification profile is saved yet. Set up the profile BEFORE editing: run "
    "detect_profile.py, present the preset menu, and persist the choice with "
    "judge.save_profile(...). Choosing 'Skip' also satisfies this. See the "
    "skill's 'Verification Profile' section. This keeps the verify strategy "
    "fixed before any fix is applied."
)


def main() -> int:
    # The shell guard only checks the sentinel exists (#103); a stale one
    # means a crashed/abandoned loop. Reap BEFORE the tool filter so even a
    # payload that doesn't match still disarms the stale loop (mirror of the
    # ordering in loop_summary_gate).
    if reap_stale_sentinel():
        return 0

    try:
        raw_payload = sys.stdin.read() if sys.stdin is not None else ""
        payload = load_hook_payload(raw_payload)
    except (OSError, ValueError):
        return 0  # malformed/unreadable payload -> fail open

    tool = tool_name(payload)
    if tool not in ("Edit", "Write", "MultiEdit", "NotebookEdit"):
        return 0

    try:
        if not any_active_run():
            return 0
        repo = resolve_current_repo()
        needs_profile = profile_required_for_repo(repo)
    except (RuntimeError, OSError, ValueError, TypeError, AttributeError):
        # not a gh repo, no remote, or corrupt/hand-edited state.json -> allow
        return 0

    if not needs_profile:
        return 0

    # Exit code 2 blocks the tool call; stderr is surfaced to the agent.
    print(BLOCK_MESSAGE.format(repo=repo), file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
