import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'prompt-engineer',
  name: 'Prompt Engineer',
  version: '0.1.0',
  description: 'Design and test AI prompts',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'prompt-engineer', description: 'Design and test AI prompts' })
    })

    return () => console.log('[prompt-engineer] Plugin unloaded')
  }
})
