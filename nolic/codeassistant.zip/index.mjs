import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'codeassistant',
  name: 'codeassistant',
  version: '1.0.1',
  description: 'Your expert coding partner for every language. Write, debug, explain, review, refactor and convert code, write SQL, regex and scripts, solve algorithms, prep for interviews, write tests and plan and ship projects faster.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'codeassistant', description: 'Your expert coding partner for every language. Write, debug, explain, review, refactor and convert code, write SQL, regex and scripts, solve algorithms, prep for interviews, write tests and plan and ship projects faster.' })
    })

    return () => console.log('[codeassistant] Plugin unloaded')
  }
})
