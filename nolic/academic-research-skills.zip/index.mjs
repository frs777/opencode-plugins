import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'academic-research-skills',
  name: 'academic-research-skills',
  version: '3.23.0',
  description: 'Contract-audited academic research pipeline for Claude Code: research → write → review → revise → finalize. 5 skills, 35 modes, 43 prompt roles (4 plugin-exposed agents; the rest run inline by default), v3.7.3 + v3.8 L3 claim-faithfulness gate, v3.9.0 cross-index triangulation, v3.10 triangulation policy layer, v3.11 deterministic citation verification gate (#182). Capability ceilings: docs/STAGE_CAPABILITY_MATRIX.md.',
  async setup(ctx) {
    // Register tools
    await ctx.tool.transform(editor => {
      editor.namespace({ name: 'academic-research-skills', description: 'Contract-audited academic research pipeline for Claude Code: research → write → review → revise → finalize. 5 skills, 35 modes, 43 prompt roles (4 plugin-exposed agents; the rest run inline by default), v3.7.3 + v3.8 L3 claim-faithfulness gate, v3.9.0 cross-index triangulation, v3.10 triangulation policy layer, v3.11 deterministic citation verification gate (#182). Capability ceilings: docs/STAGE_CAPABILITY_MATRIX.md. tools' })
    })

    // Register commands
    await ctx.command.transform(editor => {
      editor.namespace({ name: 'academic-research-skills', description: 'Contract-audited academic research pipeline for Claude Code: research → write → review → revise → finalize. 5 skills, 35 modes, 43 prompt roles (4 plugin-exposed agents; the rest run inline by default), v3.7.3 + v3.8 L3 claim-faithfulness gate, v3.9.0 cross-index triangulation, v3.10 triangulation policy layer, v3.11 deterministic citation verification gate (#182). Capability ceilings: docs/STAGE_CAPABILITY_MATRIX.md. commands' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'academic-research-skills', description: 'Contract-audited academic research pipeline for Claude Code: research → write → review → revise → finalize. 5 skills, 35 modes, 43 prompt roles (4 plugin-exposed agents; the rest run inline by default), v3.7.3 + v3.8 L3 claim-faithfulness gate, v3.9.0 cross-index triangulation, v3.10 triangulation policy layer, v3.11 deterministic citation verification gate (#182). Capability ceilings: docs/STAGE_CAPABILITY_MATRIX.md. agents' })
    })

    return () => console.log('[academic-research-skills] Plugin unloaded')
  }
})
