import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'zzzops',
  name: 'zzzops',
  version: '2.1.0',
  description: 'Agentic engineering with durable goals for autonomous coding agents',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'zzzops', description: 'Agentic engineering with durable goals for autonomous coding agents' })
    })

    return () => console.log('[zzzops] Plugin unloaded')
  }
})
