# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: concepts/bounded-commitment.md (stripped: concepts/bounded-commitment.md)
- Skipped unsupported source entry: concepts/effective-engineering-rigor.md (stripped: concepts/effective-engineering-rigor.md)
- Skipped unsupported source entry: concepts/exact-head.md (stripped: concepts/exact-head.md)
- Skipped unsupported source entry: concepts/safe-useful-work.md (stripped: concepts/safe-useful-work.md)
- Skipped unsupported source entry: rules/BACKENDS.md (stripped: rules/BACKENDS.md)
- Skipped unsupported source entry: rules/BLOCKERS.md (stripped: rules/BLOCKERS.md)
- Skipped unsupported source entry: rules/CONTINUATION.md (stripped: rules/CONTINUATION.md)
- Skipped unsupported source entry: rules/EXECUTION_STRATEGY.md (stripped: rules/EXECUTION_STRATEGY.md)
- Skipped unsupported source entry: rules/FEEDBACK.md (stripped: rules/FEEDBACK.md)
- Skipped unsupported source entry: rules/GOAL_SYSTEM.md (stripped: rules/GOAL_SYSTEM.md)
- Skipped unsupported source entry: rules/INITIALIZATION.md (stripped: rules/INITIALIZATION.md)
- Skipped unsupported source entry: zzzops/templates/project-goals/INIT_PLAN.json (stripped: zzzops/templates/project-goals/INIT_PLAN.json)
- Skipped unsupported source entry: zzzops/templates/project-goals/MIGRATION_PLAN.json (stripped: zzzops/templates/project-goals/MIGRATION_PLAN.json)
- Skipped unsupported source entry: zzzops/templates/project-goals/MIGRATION_STATE.json (stripped: zzzops/templates/project-goals/MIGRATION_STATE.json)
- Skipped unsupported source entry: zzzops/templates/project-goals/MIGRATION_SUMMARY.md (stripped: zzzops/templates/project-goals/MIGRATION_SUMMARY.md)
- Skipped unsupported source entry: zzzops/templates/project-goals/ZZZOPS_GITIGNORE (stripped: zzzops/templates/project-goals/ZZZOPS_GITIGNORE)
- Skipped unsupported source entry: zzzops/coaching.py (stripped: zzzops/coaching.py)
- Skipped unsupported source entry: zzzops/concepts.py (stripped: zzzops/concepts.py)
- Skipped unsupported source entry: zzzops/entropy.py (stripped: zzzops/entropy.py)
- Skipped unsupported source entry: zzzops/feedback.py (stripped: zzzops/feedback.py)
- Skipped unsupported source entry: zzzops/goals.py (stripped: zzzops/goals.py)
- Skipped unsupported source entry: zzzops/installation.py (stripped: zzzops/installation.py)
- Skipped unsupported source entry: zzzops/package.py (stripped: zzzops/package.py)
- Skipped unsupported source entry: zzzops/policy.py (stripped: zzzops/policy.py)
- Skipped unsupported source entry: zzzops/portfolio.py (stripped: zzzops/portfolio.py)
- Skipped unsupported source entry: zzzops/reservation.py (stripped: zzzops/reservation.py)
- Skipped unsupported source entry: zzzops/zzzops.py (stripped: zzzops/zzzops.py)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs