import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'skill-craft',
  name: 'Skill Craft',
  version: '1.3.0',
  description: 'Review skills before release',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'skill-craft', description: 'Review skills before release' })
    })

    return () => console.log('[skill-craft] Plugin unloaded')
  }
})
