import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'gpt-vers-plugin-qg',
  name: 'GPT vers Plugin · Le QG',
  version: '2.0.0',
  description: 'Convertir, tester, soumettre',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'gpt-vers-plugin-qg', description: 'Convertir, tester, soumettre' })
    })

    return () => console.log('[gpt-vers-plugin-qg] Plugin unloaded')
  }
})
