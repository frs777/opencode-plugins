import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'eczid-agent-trust',
  name: 'ECZ-ID Agent Trust',
  version: '0.1.1',
  description: 'Review agent reach in a repo',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'eczid-agent-trust', description: 'Review agent reach in a repo' })
    })

    return () => console.log('[eczid-agent-trust] Plugin unloaded')
  }
})
