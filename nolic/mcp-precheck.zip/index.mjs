import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'mcp-precheck',
  name: 'MCP Precheck',
  version: '1.0.0',
  description: 'Check MCP servers first',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'mcp-precheck', description: 'Check MCP servers first' })
    })

    return () => console.log('[mcp-precheck] Plugin unloaded')
  }
})
