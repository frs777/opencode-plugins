# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: fixtures/coverage-samples/coverage-final.json (stripped: fixtures/coverage-samples/coverage-final.json)
- Skipped unsupported source entry: fixtures/coverage-samples/coverage.xml (stripped: fixtures/coverage-samples/coverage.xml)
- Skipped unsupported source entry: fixtures/coverage-samples/lcov.info (stripped: fixtures/coverage-samples/lcov.info)
- Skipped unsupported source entry: fixtures/metric-pack/emit-pack.js (stripped: fixtures/metric-pack/emit-pack.js)
- Skipped unsupported source entry: fixtures/metric-pack/manifest.json (stripped: fixtures/metric-pack/manifest.json)
- Skipped unsupported source entry: fixtures/minimal-skill/SKILL.md (stripped: fixtures/minimal-skill/SKILL.md)
- Skipped unsupported source entry: fixtures/observed-usage/responses.jsonl (stripped: fixtures/observed-usage/responses.jsonl)
- Skipped unsupported source entry: fixtures/ts-python-sample/src/sample.py (stripped: fixtures/ts-python-sample/src/sample.py)
- Skipped unsupported source entry: fixtures/ts-python-sample/src/sample.ts (stripped: fixtures/ts-python-sample/src/sample.ts)
- Skipped unsupported source entry: fixtures/ts-python-sample/tests/sample.test.ts (stripped: fixtures/ts-python-sample/tests/sample.test.ts)
- Skipped unsupported source entry: fixtures/ts-python-sample/tests/test_sample.py (stripped: fixtures/ts-python-sample/tests/test_sample.py)
- Skipped unsupported source entry: src/core/analyze.js (stripped: src/core/analyze.js)
- Skipped unsupported source entry: src/core/baseline.js (stripped: src/core/baseline.js)
- Skipped unsupported source entry: src/core/benchmark-events.js (stripped: src/core/benchmark-events.js)
- Skipped unsupported source entry: src/core/benchmark-workspace.js (stripped: src/core/benchmark-workspace.js)
- Skipped unsupported source entry: src/core/benchmark.js (stripped: src/core/benchmark.js)
- Skipped unsupported source entry: src/core/budget.js (stripped: src/core/budget.js)
- Skipped unsupported source entry: src/core/compare.js (stripped: src/core/compare.js)
- Skipped unsupported source entry: src/core/improvement-brief.js (stripped: src/core/improvement-brief.js)
- Skipped unsupported source entry: src/core/measurement-plan.js (stripped: src/core/measurement-plan.js)
- Skipped unsupported source entry: src/core/metric-packs.js (stripped: src/core/metric-packs.js)
- Skipped unsupported source entry: src/core/observed-usage.js (stripped: src/core/observed-usage.js)
- Skipped unsupported source entry: src/core/presentation.js (stripped: src/core/presentation.js)
- Skipped unsupported source entry: src/core/schema.js (stripped: src/core/schema.js)
- Skipped unsupported source entry: src/core/scoring.js (stripped: src/core/scoring.js)
- Skipped unsupported source entry: src/core/target.js (stripped: src/core/target.js)
- Skipped unsupported source entry: src/core/workflow-guide.js (stripped: src/core/workflow-guide.js)
- Skipped unsupported source entry: src/evaluators/code.js (stripped: src/evaluators/code.js)
- Skipped unsupported source entry: src/evaluators/coverage.js (stripped: src/evaluators/coverage.js)
- Skipped unsupported source entry: src/evaluators/plugin.js (stripped: src/evaluators/plugin.js)
- Skipped unsupported source entry: src/evaluators/python.js (stripped: src/evaluators/python.js)
- Skipped unsupported source entry: src/evaluators/skill.js (stripped: src/evaluators/skill.js)
- Skipped unsupported source entry: src/evaluators/typescript.js (stripped: src/evaluators/typescript.js)
- Skipped unsupported source entry: src/lib/files.js (stripped: src/lib/files.js)
- Skipped unsupported source entry: src/lib/frontmatter.js (stripped: src/lib/frontmatter.js)
- Skipped unsupported source entry: src/lib/tokens.js (stripped: src/lib/tokens.js)
- Skipped unsupported source entry: src/renderers/html.js (stripped: src/renderers/html.js)
- Skipped unsupported source entry: src/renderers/index.js (stripped: src/renderers/index.js)
- Skipped unsupported source entry: src/renderers/markdown.js (stripped: src/renderers/markdown.js)
- Skipped unsupported source entry: src/cli.js (stripped: src/cli.js)
- Skipped unsupported source entry: src/index.js (stripped: src/index.js)
- Skipped unsupported source entry: tests/plugin-eval.test.js (stripped: tests/plugin-eval.test.js)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs