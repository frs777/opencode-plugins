---
name: alpha
description: Alpha fixture skill. Use when plugin-eval tests need one of two bundled skills.
metadata:
  opencode/autoinvoke: true
---

# Alpha

Use this fixture skill as the first bundled plugin skill.
