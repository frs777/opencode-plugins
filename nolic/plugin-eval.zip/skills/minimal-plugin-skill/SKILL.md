---
name: minimal-plugin-skill
description: Minimal plugin skill fixture. Use when a test needs a valid plugin skill.
metadata:
  opencode/autoinvoke: true
---

# Minimal Plugin Skill

Use this bundled skill to verify plugin-level skill discovery.
