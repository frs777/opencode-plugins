import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'multi-skill-plugin',
  name: 'Multi Skill Plugin',
  version: '0.1.0',
  description: 'Plugin fixture with two skills',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'multi-skill-plugin', description: 'Plugin fixture with two skills' })
    })

    return () => console.log('[multi-skill-plugin] Plugin unloaded')
  }
})
