import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'defense-factory',
  name: 'Codex Security Cloud',
  version: '0.1.1',
  description: 'Find and fix vulnerabilities across your repositories',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'defense-factory', description: 'Find and fix vulnerabilities across your repositories' })
    })

    return () => console.log('[defense-factory] Plugin unloaded')
  }
})
