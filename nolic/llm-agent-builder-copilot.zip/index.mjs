import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'llm-agent-builder-copilot',
  name: 'llm-agent-builder-copilot',
  version: '0.1.0',
  description: 'Design reliable LLM, tool, MCP, and agent workflows.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'llm-agent-builder-copilot', description: 'Design reliable LLM, tool, MCP, and agent workflows.' })
    })

    return () => console.log('[llm-agent-builder-copilot] Plugin unloaded')
  }
})
