import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'god-prompt',
  name: 'god-prompt',
  version: '1.0.24',
  description: 'A scoped production-engineering workflow for implementing, debugging, reviewing, refactoring, and release-preparing software with explicit scope and verification evidence.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'god-prompt', description: 'A scoped production-engineering workflow for implementing, debugging, reviewing, refactoring, and release-preparing software with explicit scope and verification evidence.' })
    })

    return () => console.log('[god-prompt] Plugin unloaded')
  }
})
