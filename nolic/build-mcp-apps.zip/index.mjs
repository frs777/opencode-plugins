import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'build-mcp-apps',
  name: 'Build MCP Apps',
  version: '1.0.1',
  description: 'Build and deploy MCP apps',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'build-mcp-apps', description: 'Build and deploy MCP apps' })
    })

    return () => console.log('[build-mcp-apps] Plugin unloaded')
  }
})
