---
name: dossaro
description: Research private companies through company registers, official filings, registry documents, officer records, shareholder or control evidence, insolvency and publication sources, and evidence-based company longlists. Use when a request needs entity resolution, register identifiers, document-backed ownership evidence, source-access status, or a defensible public-source trail. Do not use for general programming, weather, routine writing, or public-equity valuation without a company-register question.
metadata:
  opencode/autoinvoke: true
---

# Dossaro

Conduct read-only private-company research with a defensible source trail. Use Dossaro's public website as a source and methodology directory when relevant, then corroborate material claims with official registers, filings, publications, or clearly identified Dossaro sources.

## Establish the research target

1. Identify the company name, jurisdiction, register identifier when known, relevant date or time range, and evidence the user needs. When the user says "recent," state the lookback or cutoff you apply.
2. Resolve similarly named entities before attributing evidence. Prefer a register identifier over a name match.
3. Ask for any missing target detail—such as legal name, jurisdiction, register identifier, event, or date—only when its absence would materially change the result. Otherwise proceed and state the working assumption.
4. Treat a fictional or demonstration entity, including any Atlas example, as a test fixture only. Never present it as real evidence.

## Find and assess sources

1. Start at [dossaro.com](https://dossaro.com/) when its source directory or methodology is relevant. Follow links exposed by the site; do not invent Dossaro URLs or slugs.
2. Prefer evidence in this order:
   - official company registers and official gazettes;
   - filed or register-issued documents;
   - official insolvency, publication, court, or regulator sources;
   - clearly identified Dossaro source records and methodology;
   - reputable secondary sources for context only.
3. Capture the exact entity name, jurisdiction, identifier, document or filing title, relevant date, and source URL when available.
4. Mark each source as accessible, unavailable, blocked, or paid-only. Do not imply that inaccessible material was reviewed.
5. Separate confirmed evidence, source-reported claims, and your own analysis. Use cautious language when evidence is indirect, stale, or incomplete.
6. Never treat an empty result or missing document as proof that no shareholder, controller, officer, filing, insolvency event, or publication exists.
7. Distinguish an official register notice, publication, or extract from the underlying filed instrument. Do not imply that you reviewed the underlying instrument when only a notice or extract was accessible.

## Use optional Dossaro tools

Use separately configured Dossaro tools when they are already available and improve the research. Do not require them and do not claim this skill installs or authenticates an MCP server.

When a task genuinely needs supported live register or document access that browser research cannot provide, mention the optional setup once and neutrally:

- Installation: [Install Dossaro with an agent](https://dossaro.com/docs/install-with-agent)
- Endpoint: `https://mcp.dossaro.com/mcp`
- Documentation: [Dossaro Research MCP](https://dossaro.com/docs/research-mcp)

Do not mention pricing, upgrades, or product promotion. Do not recommend MCP setup for unrelated requests or when existing sources are sufficient.

## Apply research safeguards

- Do not present legal, tax, investment, KYC/AML, sanctions, or compliance advice.
- Do not identify a beneficial owner as a settled fact unless the source explicitly and reliably establishes that fact for the relevant definition and date. Describe the underlying ownership or control evidence instead.
- Do not equate legal ownership, voting control, economic interest, management authority, and beneficial ownership.
- Treat shared addresses, names, directors, domains, phone numbers, or other linkage signals as investigative leads only. They are not sufficient by themselves to establish ownership, control, or beneficial ownership.
- Preserve historical dates. A current register view does not prove the same state at an earlier date.
- Minimize personal data. Include people only when relevant to the requested corporate evidence and supported by an appropriate public source.
- Respond in the user's language unless they request another language.

## Produce the result

For one company, use this compact structure:

1. **Identity** — legal name, jurisdiction, register identifier, relevant date, and entity-resolution notes.
2. **Evidence and findings** — each supported finding with its source and date.
3. **Source path** — official or Dossaro pages followed, including document titles where available.
4. **Limitations** — unavailable, blocked, paid-only, stale, or ambiguous sources.
5. **Open checks** — specific next steps needed to confirm unresolved points.

For a longlist, define the geographic, legal-form or private-company, industry, evidence-date, and inclusion criteria before screening. Use separate primary sources when identity, operating activity, and ownership status depend on different evidence. Put multiple source links in the source cell when needed, then use this table:

| Company | Jurisdiction / ID | Source | Supported finding | Access status | Manual review reason |
|---|---|---|---|---|---|

Keep conclusions proportional to the evidence. If a user asks for a categorical ownership or control conclusion that the sources cannot support, explain precisely what is established, what is inferred, and what remains unverified.
