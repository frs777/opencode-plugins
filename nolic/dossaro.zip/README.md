# Dossaro plugin

Dossaro guides AI agents through evidence-based private-company, register, filing, document, officer, shareholder, control, insolvency, publication, and longlist research.

This is a skill-only plugin. It includes no MCP server, executable product code, authentication, background process, or write action. The shared Agent Skill lives at `skills/dossaro/SKILL.md`; the OpenAI and Anthropic manifests package that same skill without duplicating its instructions.

## Example prompts

- Research a German GmbH and identify the register documents that support its shareholder history.
- Find ownership or control evidence for a private UK company as of a specific date.
- Build a source-backed longlist of private companies in a defined jurisdiction.
- Check whether official insolvency or publication evidence exists for a company.
- Show me how to configure the optional Dossaro Research MCP with my agent.

## Package structure

```text
dossaro/
├── .claude-plugin/plugin.json
├── .codex-plugin/plugin.json
├── assets/icon.svg
├── assets/icon.png
└── skills/dossaro/
    ├── SKILL.md
    └── agents/openai.yaml
```

## Local validation

```bash
python3 /path/to/skill-creator/scripts/quick_validate.py ./skills/dossaro
python3 /path/to/plugin-creator/scripts/validate_plugin.py .
claude plugin validate .
```

Load the plugin directly in Claude Code while developing:

```bash
claude --plugin-dir .
```

For the OpenAI Plugin Directory, upload `dist/dossaro-plugin.zip`. Use `dist/dossaro-skill.zip` only on surfaces that explicitly request a bare Agent Skill.

## Optional live-data acceleration

Normal browser or web access is sufficient for the skill. If separately configured Dossaro tools are available, the skill may use them. See [agent installation](https://dossaro.com/docs/install-with-agent) and the [Research MCP documentation](https://dossaro.com/docs/research-mcp) for the optional endpoint `https://mcp.dossaro.com/mcp`.

The plugin never treats missing search results as proof of missing ownership or control and never presents legal, tax, investment, KYC/AML, or beneficial-ownership conclusions as settled facts without adequate evidence.
