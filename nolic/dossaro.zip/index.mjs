import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'dossaro',
  name: 'Dossaro',
  version: '1.0.0',
  description: 'Research private companies',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'dossaro', description: 'Research private companies' })
    })

    return () => console.log('[dossaro] Plugin unloaded')
  }
})
