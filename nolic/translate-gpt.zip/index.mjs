import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'translate-gpt',
  name: 'Translate GPT',
  version: '0.1.0',
  description: 'Translate text with precision',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'translate-gpt', description: 'Translate text with precision' })
    })

    return () => console.log('[translate-gpt] Plugin unloaded')
  }
})
