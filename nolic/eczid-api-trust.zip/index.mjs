import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'eczid-api-trust',
  name: 'ECZ-ID API Trust',
  version: '0.1.1',
  description: 'Review API surfaces in a repo',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'eczid-api-trust', description: 'Review API surfaces in a repo' })
    })

    return () => console.log('[eczid-api-trust] Plugin unloaded')
  }
})
