# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: evals/expected/missing-context.json (stripped: evals/expected/missing-context.json)
- Skipped unsupported source entry: evals/expected/parallel-topics.json (stripped: evals/expected/parallel-topics.json)
- Skipped unsupported source entry: evals/fixtures/missing-context.json (stripped: evals/fixtures/missing-context.json)
- Skipped unsupported source entry: evals/fixtures/parallel-topics.json (stripped: evals/fixtures/parallel-topics.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs