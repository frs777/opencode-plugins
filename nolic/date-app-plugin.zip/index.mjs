import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'date-app-plugin',
  name: 'Date App Plugin',
  version: '0.1.0',
  description: 'Generates responses',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'date-app-plugin', description: 'Generates responses' })
    })

    return () => console.log('[date-app-plugin] Plugin unloaded')
  }
})
