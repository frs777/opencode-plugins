import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'research-plugin',
  name: 'Research Methodology',
  version: '1.1.0',
  description: 'Research to checkable results',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'research-plugin', description: 'Research to checkable results' })
    })

    return () => console.log('[research-plugin] Plugin unloaded')
  }
})
