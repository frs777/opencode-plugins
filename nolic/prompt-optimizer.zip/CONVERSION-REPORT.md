# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: examples/long-request.txt (stripped: examples/long-request.txt)
- Skipped unsupported source entry: examples/optimized-brief.json (stripped: examples/optimized-brief.json)
- Skipped unsupported source entry: brief.schema.json (stripped: brief.schema.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs