import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'prompt-optimizer',
  name: 'Prompt Optimizer',
  version: '0.1.9',
  description: 'Turn brain dumps into prompts.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'prompt-optimizer', description: 'Turn brain dumps into prompts.' })
    })

    return () => console.log('[prompt-optimizer] Plugin unloaded')
  }
})
