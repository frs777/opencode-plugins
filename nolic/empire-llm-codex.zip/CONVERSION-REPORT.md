# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: readiness/api-endpoint-comparison.csv (stripped: readiness/api-endpoint-comparison.csv)
- Skipped unsupported source entry: readiness/api-endpoint-inventory.json (stripped: readiness/api-endpoint-inventory.json)
- Skipped unsupported source entry: readiness/api-fuzz-results.json (stripped: readiness/api-fuzz-results.json)
- Skipped unsupported source entry: CHANGELOG.md (stripped: CHANGELOG.md)
- Skipped unsupported source entry: SECURITY_TESTING.md (stripped: SECURITY_TESTING.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs