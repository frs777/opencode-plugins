import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'empire-llm-codex',
  name: 'Empire LLM for Codex',
  version: '1.7.2',
  description: 'Intelligent Model Routing',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'empire-llm-codex', description: 'Intelligent Model Routing' })
    })

    return () => console.log('[empire-llm-codex] Plugin unloaded')
  }
})
