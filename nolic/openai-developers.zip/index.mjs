import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'openai-developers',
  name: 'OpenAI Developers',
  version: '1.3.6',
  description: 'Develop AI apps and agents with OpenAI best practices',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'openai-developers', description: 'Develop AI apps and agents with OpenAI best practices' })
    })

    // Register MCP servers
    await ctx.mcp.transform(editor => {
      editor.namespace({ name: 'openai-developers', description: 'Develop AI apps and agents with OpenAI best practices MCP' })
    })

    return () => console.log('[openai-developers] Plugin unloaded')
  }
})
