import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'plugin-management',
  name: 'Plugin Management',
  version: '0.1.0',
  description: 'Discover and manage plugins',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'plugin-management', description: 'Discover and manage plugins' })
    })

    return () => console.log('[plugin-management] Plugin unloaded')
  }
})
