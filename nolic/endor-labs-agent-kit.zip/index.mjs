import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'endor-labs-agent-kit',
  name: 'Endor Labs Agent Kit',
  version: '2.2.2',
  description: 'Endor Labs Agentic AppSec',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'endor-labs-agent-kit', description: 'Endor Labs Agentic AppSec' })
    })

    return () => console.log('[endor-labs-agent-kit] Plugin unloaded')
  }
})
