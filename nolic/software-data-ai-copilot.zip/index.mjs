import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'software-data-ai-copilot',
  name: 'software-data-ai-copilot',
  version: '0.1.0',
  description: 'Repository-first coding help for software, data, and AI projects.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'software-data-ai-copilot', description: 'Repository-first coding help for software, data, and AI projects.' })
    })

    return () => console.log('[software-data-ai-copilot] Plugin unloaded')
  }
})
