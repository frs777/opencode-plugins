import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'softwarearchitect',
  name: 'softwarearchitect',
  version: '1.0.0',
  description: 'Design any software system like a principal architect: system design, microservices, APIs, databases, AWS, Azure and GCP, scalability, C4 and UML diagrams, ADRs, architecture reviews and tech stack advice.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'softwarearchitect', description: 'Design any software system like a principal architect: system design, microservices, APIs, databases, AWS, Azure and GCP, scalability, C4 and UML diagrams, ADRs, architecture reviews and tech stack advice.' })
    })

    return () => console.log('[softwarearchitect] Plugin unloaded')
  }
})
