import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'write-for-me',
  name: 'Write For Me',
  version: '0.1.0',
  description: 'All in One Writer',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'write-for-me', description: 'All in One Writer' })
    })

    return () => console.log('[write-for-me] Plugin unloaded')
  }
})
