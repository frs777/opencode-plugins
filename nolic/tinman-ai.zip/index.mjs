import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'tinman-ai',
  name: 'Tinman AI',
  version: '1.0.3',
  description: 'Tinman AI helps loan officers and underwriters quickly underwrite home financing scenarios and answer compl...',
  async setup(ctx) {
    return () => console.log('[tinman-ai] Plugin unloaded')
  }
})
