import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'production-data-engineering-copilot',
  name: 'production-data-engineering-copilot',
  version: '0.1.0',
  description: 'Production data engineering architecture, debugging, recovery, and reliability workflows.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'production-data-engineering-copilot', description: 'Production data engineering architecture, debugging, recovery, and reliability workflows.' })
    })

    return () => console.log('[production-data-engineering-copilot] Plugin unloaded')
  }
})
