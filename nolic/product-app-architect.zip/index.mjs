import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'product-app-architect',
  name: 'product-app-architect',
  version: '0.1.0',
  description: 'Turn product ideas and existing apps into focused product plans, UX flows, architecture decisions, and implementation-ready build plans.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'product-app-architect', description: 'Turn product ideas and existing apps into focused product plans, UX flows, architecture decisions, and implementation-ready build plans.' })
    })

    return () => console.log('[product-app-architect] Plugin unloaded')
  }
})
