import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'ha-interaction-audit',
  name: 'HA Interaction Audit',
  version: '1.0.1+codex.20260910130500',
  description: 'Home Assistant Audit',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'ha-interaction-audit', description: 'Home Assistant Audit' })
    })

    return () => console.log('[ha-interaction-audit] Plugin unloaded')
  }
})
