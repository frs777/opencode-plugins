import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-skills-for-go',
  name: 'Go: Production Engineering',
  version: '0.4.0',
  description: 'Build, test & operate Go',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-skills-for-go', description: 'Build, test & operate Go' })
    })

    return () => console.log('[engineering-skills-for-go] Plugin unloaded')
  }
})
