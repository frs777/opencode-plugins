import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'product-design',
  name: 'Product Design',
  version: '0.1.56',
  description: 'Explore and prototype ideas',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'product-design', description: 'Explore and prototype ideas' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'product-design', description: 'Explore and prototype ideas agents' })
    })

    return () => console.log('[product-design] Plugin unloaded')
  }
})
