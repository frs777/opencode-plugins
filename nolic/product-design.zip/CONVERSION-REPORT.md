# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: templates/mobile-app/.openai/hosting.json (stripped: templates/mobile-app/.openai/hosting.json)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/BottomSheet.tsx (stripped: templates/mobile-app/src/mobile/BottomSheet.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/COMPONENTS.md (stripped: templates/mobile-app/src/mobile/COMPONENTS.md)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/Carousel.tsx (stripped: templates/mobile-app/src/mobile/Carousel.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/Device.tsx (stripped: templates/mobile-app/src/mobile/Device.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/FlowStack.tsx (stripped: templates/mobile-app/src/mobile/FlowStack.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/Keyboard.tsx (stripped: templates/mobile-app/src/mobile/Keyboard.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/MobileCursor.tsx (stripped: templates/mobile-app/src/mobile/MobileCursor.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/MobileRuntime.tsx (stripped: templates/mobile-app/src/mobile/MobileRuntime.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/MobileScroll.tsx (stripped: templates/mobile-app/src/mobile/MobileScroll.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/PhoneFrame.tsx (stripped: templates/mobile-app/src/mobile/PhoneFrame.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/assets.ts (stripped: templates/mobile-app/src/mobile/assets.ts)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/components.tsx (stripped: templates/mobile-app/src/mobile/components.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/geometry.ts (stripped: templates/mobile-app/src/mobile/geometry.ts)
- Skipped unsupported source entry: templates/mobile-app/src/mobile/index.ts (stripped: templates/mobile-app/src/mobile/index.ts)
- Skipped unsupported source entry: templates/mobile-app/src/App.tsx (stripped: templates/mobile-app/src/App.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/Prototype.tsx (stripped: templates/mobile-app/src/Prototype.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/main.tsx (stripped: templates/mobile-app/src/main.tsx)
- Skipped unsupported source entry: templates/mobile-app/src/prototype.css (stripped: templates/mobile-app/src/prototype.css)
- Skipped unsupported source entry: templates/mobile-app/src/styles.css (stripped: templates/mobile-app/src/styles.css)
- Skipped unsupported source entry: templates/mobile-app/src/vite-env.d.ts (stripped: templates/mobile-app/src/vite-env.d.ts)
- Skipped unsupported source entry: templates/mobile-app/tests/mobile-runtime.spec.ts (stripped: templates/mobile-app/tests/mobile-runtime.spec.ts)
- Skipped unsupported source entry: templates/mobile-app/tests/runtime-fixture.css (stripped: templates/mobile-app/tests/runtime-fixture.css)
- Skipped unsupported source entry: templates/mobile-app/tests/runtime-fixture.html (stripped: templates/mobile-app/tests/runtime-fixture.html)
- Skipped unsupported source entry: templates/mobile-app/tests/runtime-fixture.tsx (stripped: templates/mobile-app/tests/runtime-fixture.tsx)
- Skipped unsupported source entry: templates/mobile-app/tests/sites-worker.test.mjs (stripped: templates/mobile-app/tests/sites-worker.test.mjs)
- Skipped unsupported source entry: templates/mobile-app/worker/index.js (stripped: templates/mobile-app/worker/index.js)
- Skipped unsupported source entry: templates/mobile-app/index.html (stripped: templates/mobile-app/index.html)
- Skipped unsupported source entry: templates/mobile-app/mobile-runtime.lock.json (stripped: templates/mobile-app/mobile-runtime.lock.json)
- Skipped unsupported source entry: templates/mobile-app/package-lock.json (stripped: templates/mobile-app/package-lock.json)
- Skipped unsupported source entry: templates/mobile-app/playwright.config.ts (stripped: templates/mobile-app/playwright.config.ts)
- Skipped unsupported source entry: templates/mobile-app/tsconfig.json (stripped: templates/mobile-app/tsconfig.json)
- Skipped unsupported source entry: templates/mobile-app/vite.config.ts (stripped: templates/mobile-app/vite.config.ts)
- Skipped unsupported source entry: templates/prototype/.openai/hosting.json (stripped: templates/prototype/.openai/hosting.json)
- Skipped unsupported source entry: templates/prototype/src/App.jsx (stripped: templates/prototype/src/App.jsx)
- Skipped unsupported source entry: templates/prototype/src/main.jsx (stripped: templates/prototype/src/main.jsx)
- Skipped unsupported source entry: templates/prototype/src/styles.css (stripped: templates/prototype/src/styles.css)
- Skipped unsupported source entry: templates/prototype/tests/sites-worker.test.mjs (stripped: templates/prototype/tests/sites-worker.test.mjs)
- Skipped unsupported source entry: templates/prototype/worker/index.js (stripped: templates/prototype/worker/index.js)
- Skipped unsupported source entry: templates/prototype/.npmrc (stripped: templates/prototype/.npmrc)
- Skipped unsupported source entry: templates/prototype/index.html (stripped: templates/prototype/index.html)
- Skipped unsupported source entry: templates/prototype/package-lock.json (stripped: templates/prototype/package-lock.json)
- Skipped unsupported source entry: templates/prototype/vite.config.mjs (stripped: templates/prototype/vite.config.mjs)
- Skipped unsupported source entry: .npmignore (stripped: .npmignore)
- Skipped unsupported source entry: integrity.json (stripped: integrity.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs