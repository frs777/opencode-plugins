import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'writer',
  name: 'Writer',
  version: '1.0.0',
  description: 'Writing that\'s ready to send',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'writer', description: 'Writing that\'s ready to send' })
    })

    return () => console.log('[writer] Plugin unloaded')
  }
})
