import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'lovable',
  name: 'Lovable',
  version: '3.0.0',
  description: 'Build full-stack apps by chat',
  async setup(ctx) {
    return () => console.log('[lovable] Plugin unloaded')
  }
})
