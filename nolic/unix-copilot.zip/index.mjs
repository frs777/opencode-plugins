import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'unix-copilot',
  name: 'unix-copilot',
  version: '0.1.0',
  description: 'Safe Unix, Linux, macOS, and shell command workflows.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'unix-copilot', description: 'Safe Unix, Linux, macOS, and shell command workflows.' })
    })

    return () => console.log('[unix-copilot] Plugin unloaded')
  }
})
