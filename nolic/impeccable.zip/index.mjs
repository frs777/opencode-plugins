import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'impeccable',
  name: 'Impeccable',
  version: '4.3.1',
  description: 'Design and refine interfaces',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'impeccable', description: 'Design and refine interfaces' })
    })

    return () => console.log('[impeccable] Plugin unloaded')
  }
})
