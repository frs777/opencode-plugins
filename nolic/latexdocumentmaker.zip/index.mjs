import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'latexdocumentmaker',
  name: 'latexdocumentmaker',
  version: '1.0.1',
  description: 'Your expert LaTeX engineer: complete, compile-ready documents, papers, theses, resumes, Beamer slides, posters, equations, tables, TikZ diagrams, bibliographies, journal templates and fast compile-error fixes.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'latexdocumentmaker', description: 'Your expert LaTeX engineer: complete, compile-ready documents, papers, theses, resumes, Beamer slides, posters, equations, tables, TikZ diagrams, bibliographies, journal templates and fast compile-error fixes.' })
    })

    return () => console.log('[latexdocumentmaker] Plugin unloaded')
  }
})
