import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'research',
  name: 'Rohas Legal AI: Research',
  version: '0.2.1',
  description: 'Legal research workflows',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'research', description: 'Legal research workflows' })
    })

    return () => console.log('[research] Plugin unloaded')
  }
})
