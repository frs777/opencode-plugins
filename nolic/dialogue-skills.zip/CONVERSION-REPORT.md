# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: LICENSE-dialogue-essay (stripped: LICENSE-dialogue-essay)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs