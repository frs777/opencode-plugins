import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'dialogue-skills',
  name: 'Dialogue Skills',
  version: '0.1.0+codex.20260916024048',
  description: '対話から、論考・指示・レビュー・掲載を育てる',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'dialogue-skills', description: '対話から、論考・指示・レビュー・掲載を育てる' })
    })

    return () => console.log('[dialogue-skills] Plugin unloaded')
  }
})
