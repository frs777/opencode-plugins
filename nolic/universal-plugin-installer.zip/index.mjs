import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'universal-plugin-installer',
  name: 'Universal Plugin Installer',
  version: '0.1.0',
  description: 'Convert Skills 2 Codex Plugins',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'universal-plugin-installer', description: 'Convert Skills 2 Codex Plugins' })
    })

    return () => console.log('[universal-plugin-installer] Plugin unloaded')
  }
})
