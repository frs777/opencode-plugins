import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'infra-orchestrator',
  name: 'Enterprise Infra Orchestrator',
  version: '1.3.4',
  description: 'Infrastructure engineering',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'infra-orchestrator', description: 'Infrastructure engineering' })
    })

    return () => console.log('[infra-orchestrator] Plugin unloaded')
  }
})
