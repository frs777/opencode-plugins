import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'htmlcodegenerator',
  name: 'htmlcodegenerator',
  version: '1.0.1',
  description: 'Generate clean, responsive HTML, CSS and JavaScript like a senior developer: landing pages, full websites, portfolios, emails, forms, components, Tailwind, image to HTML, SEO, speed fixes and debugging.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'htmlcodegenerator', description: 'Generate clean, responsive HTML, CSS and JavaScript like a senior developer: landing pages, full websites, portfolios, emails, forms, components, Tailwind, image to HTML, SEO, speed fixes and debugging.' })
    })

    return () => console.log('[htmlcodegenerator] Plugin unloaded')
  }
})
