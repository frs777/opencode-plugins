import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'code-review',
  name: 'Code Review',
  version: '26.1007.21434',
  description: 'Review and manage GitHub pull requests',
  async setup(ctx) {
    return () => console.log('[code-review] Plugin unloaded')
  }
})
