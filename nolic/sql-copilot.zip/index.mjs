import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'sql-copilot',
  name: 'sql-copilot',
  version: '0.1.0',
  description: 'Write, debug, review, and tune dialect-aware SQL with correctness checks, safer data changes, and evidence-based performance guidance.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'sql-copilot', description: 'Write, debug, review, and tune dialect-aware SQL with correctness checks, safer data changes, and evidence-based performance guidance.' })
    })

    return () => console.log('[sql-copilot] Plugin unloaded')
  }
})
