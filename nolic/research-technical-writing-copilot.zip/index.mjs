import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'research-technical-writing-copilot',
  name: 'research-technical-writing-copilot',
  version: '0.1.0',
  description: 'Deep research, source verification, technical writing, documentation, and publishable content.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'research-technical-writing-copilot', description: 'Deep research, source verification, technical writing, documentation, and publishable content.' })
    })

    return () => console.log('[research-technical-writing-copilot] Plugin unloaded')
  }
})
