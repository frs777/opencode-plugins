# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: submission/listing-and-prompts.md (stripped: submission/listing-and-prompts.md)
- Skipped unsupported source entry: submission/public-submission-checklist.md (stripped: submission/public-submission-checklist.md)
- Skipped unsupported source entry: submission/release-notes.md (stripped: submission/release-notes.md)
- Skipped unsupported source entry: submission/test-cases.md (stripped: submission/test-cases.md)
- Skipped unsupported source entry: PLUGIN_CREATOR_PROMPT.md (stripped: PLUGIN_CREATOR_PROMPT.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs