import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'technical-interview-copilot',
  name: 'technical-interview-copilot',
  version: '0.1.0',
  description: 'Role-aware technical interview preparation, practice, and feedback.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'technical-interview-copilot', description: 'Role-aware technical interview preparation, practice, and feedback.' })
    })

    return () => console.log('[technical-interview-copilot] Plugin unloaded')
  }
})
