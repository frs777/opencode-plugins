import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'plugin-creator',
  name: 'plugin-creator',
  version: '0.1.26',
  description: 'Create and improve plugins from your ideas, instructions, and workflows.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'plugin-creator', description: 'Create and improve plugins from your ideas, instructions, and workflows.' })
    })

    return () => console.log('[plugin-creator] Plugin unloaded')
  }
})
