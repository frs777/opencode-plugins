import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'jam',
  name: 'Jam',
  version: '1.16.2',
  description: 'Investigate bug reports',
  async setup(ctx) {
    return () => console.log('[jam] Plugin unloaded')
  }
})
