import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'replit',
  name: 'Replit',
  version: '4.0.0',
  description: 'Turn your ideas into real apps',
  async setup(ctx) {
    return () => console.log('[replit] Plugin unloaded')
  }
})
