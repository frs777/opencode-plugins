import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'compliance-horizon-scanner',
  name: 'compliance-horizon-scanner',
  version: '0.2.0+codex.20260914234654',
  description: 'Scan US federal, optionally selected US states, EU, and UK primary regulatory sources for new and upcoming changes scoped to a specific business profile, score each for materiality, and cite every claim to a primary source.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'compliance-horizon-scanner', description: 'Scan US federal, optionally selected US states, EU, and UK primary regulatory sources for new and upcoming changes scoped to a specific business profile, score each for materiality, and cite every claim to a primary source.' })
    })

    return () => console.log('[compliance-horizon-scanner] Plugin unloaded')
  }
})
