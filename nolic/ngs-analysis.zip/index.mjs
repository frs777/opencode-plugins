import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'ngs-analysis',
  name: 'Life Sciences NGS Analysis',
  version: '1.0.3',
  description: 'Guided NGS routing and local execution for sequencing analysis',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'ngs-analysis', description: 'Guided NGS routing and local execution for sequencing analysis' })
    })

    return () => console.log('[ngs-analysis] Plugin unloaded')
  }
})
