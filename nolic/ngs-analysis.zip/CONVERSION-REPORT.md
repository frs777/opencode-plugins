# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: tests/test_bcl_to_fastq_runner.py (stripped: tests/test_bcl_to_fastq_runner.py)
- Skipped unsupported source entry: tests/test_bulk_rnaseq_counts_qc_runner.py (stripped: tests/test_bulk_rnaseq_counts_qc_runner.py)
- Skipped unsupported source entry: tests/test_new_backend_planners.py (stripped: tests/test_new_backend_planners.py)
- Skipped unsupported source entry: tests/test_ngs_preflight.py (stripped: tests/test_ngs_preflight.py)
- Skipped unsupported source entry: tests/test_scrnaseq_post_count_qc_runner.py (stripped: tests/test_scrnaseq_post_count_qc_runner.py)
- Skipped unsupported source entry: workflows/amplicon_microbiome/run_dada2_backend.R (stripped: workflows/amplicon_microbiome/run_dada2_backend.R)
- Skipped unsupported source entry: workflows/bulk_rnaseq_counts_qc/Snakefile.smk (stripped: workflows/bulk_rnaseq_counts_qc/Snakefile.smk)
- Skipped unsupported source entry: workflows/bulk_rnaseq_counts_qc/aggregate_salmon_quant.py (stripped: workflows/bulk_rnaseq_counts_qc/aggregate_salmon_quant.py)
- Skipped unsupported source entry: workflows/bulk_rnaseq_differential_expression/run_bulk_de.R (stripped: workflows/bulk_rnaseq_differential_expression/run_bulk_de.R)
- Skipped unsupported source entry: workflows/scrnaseq_fastq_to_count/Snakefile.smk (stripped: workflows/scrnaseq_fastq_to_count/Snakefile.smk)
- Skipped unsupported source entry: workflows/scrnaseq_fastq_to_count/run_star_genome_generate.py (stripped: workflows/scrnaseq_fastq_to_count/run_star_genome_generate.py)
- Skipped unsupported source entry: workflows/scrnaseq_fastq_to_count/run_starsolo.py (stripped: workflows/scrnaseq_fastq_to_count/run_starsolo.py)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs