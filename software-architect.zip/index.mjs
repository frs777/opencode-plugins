import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'software-architect',
  name: 'Software Architect',
  version: '0.1.0',
  description: 'Design robust software',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'software-architect', description: 'Design robust software' })
    })

    return () => console.log('[software-architect] Plugin unloaded')
  }
})
