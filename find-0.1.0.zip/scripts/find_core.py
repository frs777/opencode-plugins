#!/usr/bin/env python3
"""Core discovery/indexing logic for the find plugin. Standard library only."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Iterable


def parse_skill_frontmatter(path: Path) -> dict[str, str] | None:
    text = path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None
    end = text.find("\n---", 3)
    if end < 0:
        return None
    front = text[3:end].strip("\n")
    lines = front.splitlines()
    name = None
    description = None
    collecting = False
    desc_lines: list[str] = []
    for line in lines:
        if collecting:
            if line.startswith((" ", "\t")):
                desc_lines.append(line.strip())
                continue
            collecting = False
        if line.startswith("name:"):
            name = line.split(":", 1)[1].strip().strip("'\"")
        elif line.startswith("description:"):
            value = line.split(":", 1)[1].strip()
            if value in (">-", ">", "|-", "|"):
                collecting = True
                desc_lines = []
            else:
                description = value.strip("'\"")
    if collecting:
        description = " ".join(x for x in desc_lines if x).strip()
    if not name:
        return None
    return {"name": name, "description": description or ""}


def _tokens(text: str) -> set[str]:
    return {t.lower() for t in re.findall(r"[\wąćęłńóśźż]+", text.lower()) if len(t) > 1}


def match_capabilities(query: str, items: Iterable[dict[str, str]], limit: int = 10) -> list[dict[str, str]]:
    query_tokens = _tokens(query)
    scored = []
    for item in items:
        haystack = f"{item.get('name', '')} {item.get('description', '')}"
        tokens = _tokens(haystack)
        overlap = query_tokens & tokens
        related = 0
        for q in query_tokens - overlap:
            if any((len(q) >= 4 and (q.startswith(t) or t.startswith(q) or q in t or t in q)) for t in tokens):
                related += 1
        score = len(overlap) + related
        if item.get("name", "").lower() in query.lower():
            score += 3
        if score:
            scored.append((score, item))
    scored.sort(key=lambda x: (-x[0], x[1].get("name", "").lower()))
    return [item for _, item in scored[:limit]]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_index(root: Path, db_path: Path) -> dict[str, int]:
    root = Path(root).expanduser().resolve()
    db_path = Path(db_path).expanduser().resolve()
    old = json.loads(db_path.read_text(encoding="utf-8")) if db_path.exists() else {"skills": {}}
    old_skills = old.get("skills", {})
    current: dict[str, dict] = {}
    added = changed = unchanged = invalid = 0
    for path in sorted(root.rglob("SKILL.md")):
        try:
            stat = path.stat()
            rel = str(path.relative_to(root))
            digest = _sha256(path)
            parsed = parse_skill_frontmatter(path)
            if not parsed:
                invalid += 1
                continue
            current[rel] = {
                **parsed,
                "path": str(path),
                "sha256": digest,
                "mtime_ns": stat.st_mtime_ns,
            }
            if rel not in old_skills:
                added += 1
            elif old_skills[rel].get("sha256") == digest:
                unchanged += 1
            else:
                changed += 1
        except OSError:
            invalid += 1
    removed = len(set(old_skills) - set(current))
    payload = {"version": 1, "root": str(root), "skills": current}
    db_path.parent.mkdir(parents=True, exist_ok=True)
    db_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"added": added, "changed": changed, "unchanged": unchanged, "removed": removed, "invalid": invalid}


def help_text() -> str:
    return """# find — pomoc

@find <zadanie> — analizuje zadanie i dobiera pasujące skille/wtyczki.
@find help — pokazuje dostępne funkcje find.
@find lista <temat> — listuje zainstalowane możliwości związane z tematem.
@find szukaj <temat> — wyszukuje możliwości bez wykonywania zadania.
@find użyj <nazwa> — wskazuje konkretny skill/wtyczkę do użycia.
@find status — pokazuje stan lokalnego indeksu.
@find rescan — wykonuje pełny skan i aktualizuje indeks zmian.
"""
