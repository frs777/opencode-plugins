#!/usr/bin/env python3
import json, sys
from pathlib import Path

def main(root):
    root = Path(root)
    manifest = root / 'plugin.json'
    skill = root / 'skills/find/SKILL.md'
    if not manifest.is_file(): raise SystemExit('missing plugin.json')
    data = json.loads(manifest.read_text(encoding='utf-8'))
    if data.get('name') != 'find': raise SystemExit('wrong plugin name')
    if not skill.is_file(): raise SystemExit('missing find skill')
    text = skill.read_text(encoding='utf-8')
    if not text.startswith('---') or '\nname:' not in text or '\ndescription:' not in text:
        raise SystemExit('invalid skill frontmatter')
    for p in root.rglob('*'):
        if p.is_symlink(): raise SystemExit(f'symlink not allowed: {p}')
    print('OK: find')

if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else '.')
