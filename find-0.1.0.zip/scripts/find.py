#!/usr/bin/env python3
"""CLI for the local find capability index."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from find_core import build_index, help_text, match_capabilities


def load_items(db: Path):
    if not db.exists():
        return []
    return list(json.loads(db.read_text(encoding='utf-8')).get('skills', {}).values())


def main() -> int:
    p = argparse.ArgumentParser(prog='find', description='Local capability discovery index')
    p.add_argument('--index', default='~/.cache/find/index.json')
    sub = p.add_subparsers(dest='command')
    sub.add_parser('help')
    for name in ('lista', 'szukaj'):
        cmd = sub.add_parser(name)
        cmd.add_argument('query', nargs='+')
    use = sub.add_parser('użyj')
    use.add_argument('name')
    sub.add_parser('status')
    scan = sub.add_parser('rescan')
    scan.add_argument('--root', default='~/.agents/skills/')
    args = p.parse_args()
    db = Path(args.index).expanduser()
    if args.command in (None, 'help'):
        print(help_text())
        return 0
    if args.command == 'rescan':
        print(json.dumps(build_index(Path(args.root).expanduser(), db), ensure_ascii=False, indent=2))
        return 0
    items = load_items(db)
    if args.command in ('lista', 'szukaj'):
        query = ' '.join(args.query)
        print(json.dumps(match_capabilities(query, items), ensure_ascii=False, indent=2))
        return 0
    if args.command == 'użyj':
        found = [x for x in items if x.get('name') == args.name]
        print(json.dumps(found, ensure_ascii=False, indent=2))
        return 0
    if args.command == 'status':
        print(json.dumps({'index': str(db), 'count': len(items)}, ensure_ascii=False, indent=2))
        return 0
    return 2

if __name__ == '__main__':
    raise SystemExit(main())
