import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'find',
  name: '🔎 find',
  version: '0.1.0',
  description: 'Meta-plugin do wyszukiwania i dobierania zainstalowanych skilli oraz wtyczek na podstawie naturalnego opisu zadania. Posiada lokalny indeks, wyszukiwanie po opisach, tryb listowania, status, rescan i wbudowaną pomoc.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'find', description: 'Meta-plugin do wyszukiwania i dobierania zainstalowanych skilli oraz wtyczek na podstawie naturalnego opisu zadania. Posiada lokalny indeks, wyszukiwanie po opisach, tryb listowania, status, rescan i wbudowaną pomoc.' })
    })

    return () => console.log('[find] Plugin unloaded')
  }
})
