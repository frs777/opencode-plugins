import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'comptext-guard',
  name: 'CompText Guard',
  version: '0.1.0',
  description: 'Guard autonomous repo work.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'comptext-guard', description: 'Guard autonomous repo work.' })
    })

    return () => console.log('[comptext-guard] Plugin unloaded')
  }
})
