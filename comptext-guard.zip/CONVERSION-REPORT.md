# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: hooks/hooks.json (stripped: hooks/hooks.json)
- Skipped unsupported source entry: hooks/policy_common.py (stripped: hooks/policy_common.py)
- Skipped unsupported source entry: hooks/policy_remote.py (stripped: hooks/policy_remote.py)
- Skipped unsupported source entry: hooks/policy_secret.py (stripped: hooks/policy_secret.py)
- Skipped unsupported source entry: hooks/pre_tool_use_policy.py (stripped: hooks/pre_tool_use_policy.py)
- Skipped unsupported source entry: tests/test_policy.py (stripped: tests/test_policy.py)
- Skipped unsupported source entry: PRIVACY.md (stripped: PRIVACY.md)
- Skipped unsupported source entry: TERMS.md (stripped: TERMS.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs