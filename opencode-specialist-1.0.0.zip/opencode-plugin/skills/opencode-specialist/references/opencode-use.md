# OpenCode — kompendium konfiguracji, modeli, projektów i rozszerzeń

> **Stan opracowania:** 10 października 2026 r.  
> **Środowisko odniesienia użytkownika:** OpenCode v2.0.26 (sprawdzone poleceniem `opencode --version`).  
> **Zasada:** V2 jest aktywnie rozwijane; dokumentacja online może zmienić się szybciej niż lokalna instalacja. Przed zmianą konfiguracji sprawdzaj schemat i dokumentację dla dokładnej wersji.

## 1. Szybka mapa pojęć

OpenCode to agent programistyczny, a nie tylko klient czatu. Najważniejsze warstwy:

- **Provider** — integracja transportowa i uwierzytelnianie usługi modelowej (Google, OpenAI, lokalny endpoint, bramka zgodna z API).
- **Model** — konkretny model dostępny u providera; identyfikator OpenCode ma zwykle postać `provider-id/model-id`.
- **Variant** — wariant parametrów danego modelu, np. poziom rozumowania; w natywnej konfiguracji V2 wybierany jako `provider/model#variant`.
- **Session** — rozmowa/zadanie; zapisuje swój wybrany model, więc zmiana domyślnego modelu nie musi zmienić już istniejącej sesji.
- **Agent** — profil wykonawczy z instrukcjami, mode, modelem i uprawnieniami.
- **Skill** — instrukcje i materiały ładowane na żądanie; sam skill nie jest wykonywalnym narzędziem.
- **Command** — powtarzalny prompt wywoływany poleceniem slash.
- **Plugin** — kod rozszerzający zachowanie, hooki, narzędzia, rejestry lub integracje.
- **Custom tool** — funkcja dostępna agentowi jako narzędzie; może być dostarczona przez plugin.
- **MCP server** — zewnętrzny serwer narzędzi/zasobów/promptów podłączany przez Model Context Protocol.
- **Project/workspace** — katalog i kontekst repozytorium, w którym OpenCode ładuje instrukcje i konfigurację projektową.

Nie rozwiązuj błędu modelu przez losową zmianę providera. Najpierw ustal, na której warstwie wystąpił problem: identyfikator, aktywacja providera, poświadczenia, transport, endpoint, zgodność API czy uprawnienia/quota.

## 2. Źródła pierwszej kategorii

Dokumentacja referencyjna:
- [OpenCode V2 — konfiguracja](https://opencode.ai/v2/docs/config)
- [Providers](https://opencode.ai/v2/docs/providers)
- [Models](https://opencode.ai/v2/docs/models)
- [Migracja V1 → V2](https://opencode.ai/v2/docs/migrate-v1)
- [Agents](https://opencode.ai/v2/docs/agents)
- [Skills](https://opencode.ai/v2/docs/skills)
- [Commands](https://opencode.ai/v2/docs/commands)
- [Permissions](https://opencode.ai/v2/docs/permissions)
- [MCP servers](https://opencode.ai/v2/docs/mcp-servers)
- [Plugin API](https://opencode.ai/v2/docs/build/plugins)
- [Migracja pluginów V1 → V2](https://opencode.ai/v2/docs/build/plugins/migrate-v1)
- [CLI](https://opencode.ai/v2/docs/cli)
- [Schemat JSON](https://opencode.ai/config.json)
- [Repozytorium źródłowe](https://github.com/anomalyco/opencode)

Dokumentacja oficjalna jest nadrzędna wobec poradników społecznościowych. Issues/PR i kod źródłowy służą do wyjaśniania zachowania nieopisanego w dokumentacji. Przykłady z repozytoriów społecznościowych traktuj jako hipotezy, dopóki nie zostaną dopasowane do wersji.

## 3. Konfiguracja: lokalizacje, scalanie i kontrola zmian

### 3.1 Najważniejsze pliki

Typowe ścieżki:
- Globalny config: `~/.config/opencode/opencode.json` lub `opencode.jsonc`.
- Config repozytorium: `<repo>/opencode.json` lub `opencode.jsonc`.
- Config w katalogu OpenCode projektu: `<repo>/.opencode/opencode.json` lub `opencode.jsonc`.
- Instrukcje repozytorium: `AGENTS.md`.
- Agenci: `.opencode/agents/<id>.md`.
- Komendy: `.opencode/commands/<id>.md`.
- Skille: `.opencode/skills/<id>/SKILL.md`.
- Pluginy lokalne V2: `.opencode/plugins/<plugin>/index.ts`.
- Narzędzia własne (jeśli obsługiwane przez instalację): katalog `.opencode/tools/`; sprawdź aktualną dokumentację narzędzi.
- Globalne odpowiedniki definicji zwykle znajdują się pod `~/.config/opencode/` w tych samych katalogach.

Warianty nazw w liczbie pojedynczej są w niektórych miejscach obsługiwane ze względu na zgodność wsteczną. Dla nowych plików preferuj formy mnogie: `agents/`, `commands/`, `plugins/`, `skills/`, `tools/`.

### 3.2 Format i walidacja

OpenCode obsługuje JSON oraz JSONC (JSON z komentarzami i przecinkami końcowymi). Zalecany początek pliku:

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "model": "provider/model-id"
}
```

Schemat pomaga edytorowi wykrywać literówki, ale nie dowodzi, że model istnieje, poświadczenia są poprawne ani API jest kompatybilne.

### 3.3 Scalanie konfiguracji

W V2 dokumentacja opisuje scalanie warstw zamiast zastępowania całego pliku. Typowe warstwy to konfiguracja globalna, konfiguracja repozytorium i konfiguracja w `.opencode/`. W obrębie drzewa katalogów OpenCode może najpierw scalić pliki bezpośrednie od katalogu nadrzędnego do bieżącego, a potem zastosować pliki w katalogach `.opencode`; przez to konfiguracja w `.opencode` może nadpisać plik bezpośredni.

Praktyczne zasady:
1. Używaj jednego stylu pliku na danym poziomie, chyba że celowo testujesz priorytety.
2. Nie zakładaj, że tablica w warstwie niższej zostanie zawsze połączona z tablicą z warstwy wyższej — zależy to od pola.
3. Zmiana pola w konfiguracji projektu może być przyczyną, że konfiguracja globalna „nie działa”.
4. Przy debugowaniu zapisuj dokładny katalog roboczy i uruchomienie, bo dostępność modelu jest zależna od projektu.
5. Nie trzymaj kluczy API w repozytorium ani w plikach konfiguracyjnych wersjonowanych przez Git.

Dokumentacja obsługuje również zmienne środowiskowe i ścieżki konfiguracyjne, m.in. `OPENCODE_CONFIG` i `OPENCODE_CONFIG_DIR`. Przed użyciem niestandardowej ścieżki sprawdź aktualne zachowanie w lokalnej wersji.

### 3.4 Bezpieczna edycja

Przed zmianą:
- wykonaj kopię pliku;
- sprawdź, czy plik jest parsowalny;
- zmieniaj tylko niezbędne pola;
- zachowaj istniejące providery, pluginy, MCP i uprawnienia;
- po zmianie wykonaj test listy modeli i rzeczywiste, małe żądanie;
- jeśli wynik jest gorszy, przywróć kopię, zamiast nakładać kolejne losowe poprawki.

## 4. Providers i modele

### 4.1 Użycie providera katalogowego

Dla providera wbudowanego najpierw połącz konto w TUI:

```text
/connect
/models
```

Wybierz provider, skonfiguruj autoryzację, a następnie wybierz model z katalogu. Nie wpisuj identyfikatora modelu „na wyczucie”: użyj listy `/models` i sprawdź dokładny identyfikator. To, że model istnieje u dostawcy, nie oznacza, że jest włączony, dostępny dla danego konta, dostępny w danym regionie lub obsługiwany przez aktualny runtime.

Domyślny model w configu:
```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "model": "google/gemini-model-id"
}
```

Wybór modelu dla bieżącej sesji i zapis domyślnego modelu to odrębne operacje. Zmiana ustawienia domyślnego nie musi zmienić już utworzonej sesji.

### 4.2 Własny provider w V2

Natywny kształt V2 wykorzystuje `providers` (liczba mnoga), `package`, `settings`, `env`, `headers`, `body` oraz `models`. Przykład dla API zgodnego z OpenAI Chat Completions:

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "model": "acme/qwen3-coder",
  "providers": {
    "acme": {
      "name": "Acme",
      "env": ["ACME_API_KEY"],
      "package": "@opencode/ai/providers/openai-compatible",
      "settings": {
        "baseURL": "https://llm.example.com/v1"
      },
      "models": {
        "qwen3-coder": {
          "name": "Qwen 3 Coder",
          "modelID": "vendor-model-id",
          "limit": { "context": 128000, "output": 8192 }
        }
      }
    }
  }
}
```

Znaczenie pól:
- `providers.acme`: ID providera i prefiks referencji modelu.
- `env`: nazwy zmiennych, z których runtime może pobrać credential; nie wartość sekretu.
- `package`: implementacja transportu/API. Dla zgodności z OpenAI używaj właściwego pakietu compatible; dla natywnego API preferuj runtime dedykowany.
- `settings.baseURL`: endpoint bazowy, którego ścieżka musi odpowiadać temu, czego oczekuje runtime.
- `models`: lokalne aliasy/definicje modeli.
- Klucz mapy modelu to identyfikator w OpenCode; `modelID` to identyfikator wysyłany do serwera.

**Nie wybieraj pakietu tylko dlatego, że nazwa API zawiera słowo „Gemini”.** Google Generative Language REST, Google Vertex, OpenAI-compatible gateway oraz Gemini Live WebSocket to różne kontrakty transportu.

### 4.3 Ponowne wykorzystanie providera katalogowego

Jeżeli istniejący provider obsługuje API, a potrzebujesz tylko proxy lub zmiany endpointu, nadpisanie `settings.baseURL` może zachować jego runtime, katalog modeli i połączenie:

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "providers": {
    "google": {
      "settings": {
        "baseURL": "http://127.0.0.1:8765/v1beta"
      }
    }
  }
}
```

Ten przykład jest **właściwy wyłącznie wtedy**, gdy lokalny adapter implementuje dokładnie API oczekiwane przez runtime providera Google. Jeśli adapter obsługuje tylko model specjalny albo inny transport, nie kieruj przez niego całego providera — utwórz osobny provider ID i przypnij do niego tylko te modele, które rzeczywiście obsługuje.

### 4.4 Model i wariant

W V2 model może definiować:
- `modelID` — identyfikator upstream;
- `name`, `family`;
- `package` — ewentualny runtime specyficzny dla modelu;
- `settings`, `headers`, `body`;
- `capabilities` — narzędzia, wejściowe/wyjściowe media;
- `compatibility` — nadpisania kompatybilności;
- `limit` — limity kontekstu i wyjścia;
- `cost` — metadane cenowe;
- `disabled`;
- `variants` — warianty z własnymi ustawieniami, nagłówkami i body.

Przykład aliasu:
```jsonc
{
  "providers": {
    "openai": {
      "models": {
        "coding": {
          "name": "Model do kodowania",
          "modelID": "gpt-model-upstream"
        }
      }
    }
  }
}
```
Wybór: `openai/coding`. Nie `openai/gpt-model-upstream`, jeśli klucz mapy to `coding`.

Warianty w V2 są używane np. jako `provider/model#high` w odwołaniu do modelu. Root `model` nie zachowuje obecnie wariantu jako trwałej domyślnej wartości; wariant wybieraj w sesji, agencie lub komendzie.

### 4.5 Credentials i limity

Rozróżniaj:
1. login/OAuth w aplikacji lub CLI;
2. klucz API;
3. ADC / tożsamość chmurową, np. Vertex;
4. token/proxy firmowy;
5. sesję webową w przeglądarce.

Nie zakładaj, że limit albo uprawnienie jednego sposobu logowania obowiązuje w innym. Uprawnienia do czatu w przeglądarce nie oznaczają automatycznie dostępu do API programistycznego. Nie przechwytuj ani nie przenoś tokenów prywatnych narzędzi CLI do nieautoryzowanych klientów. Używaj oficjalnie wspieranego sposobu uwierzytelniania providera i respektuj jego warunki.

Sekrety:
- wczytuj ze zmiennych środowiskowych lub menedżera poświadczeń;
- nie wpisuj do promptów, logów, commitów ani dokumentacji;
- nie wypisuj zawartości plików auth podczas debugowania;
- do testów loguj status i typ błędu, nigdy pełny token.

### 4.6 Debugowanie „model unavailable”, 401, 404, timeout

| Objaw | Kolejność kontroli |
|---|---|
| Model nie ma go na liście | Czy provider aktywny? Czy model znajduje się w mapie pod właściwym kluczem? Czy nie jest `disabled`? Czy projekt ma dostęp do credential? |
| `Model unavailable: provider/model` | Sprawdź prefiks providera, klucz modelu (nie tylko upstream `modelID`), allow/deny policy i katalog dynamiczny. |
| 401 / brak credential | Sprawdź, czy **ten provider ID** otrzymuje credential. Credential zapisany dla `google` nie musi być dostępny dla osobnego `google-live`. |
| 404 | Sprawdź `baseURL`, wersję API, ścieżkę endpointu i to, czy runtime dokleja `/models/...:generateContent` lub `/v1/chat/completions`. |
| 400 / invalid argument | Porównaj JSON payload z dokumentacją dokładnie tego API; usuń pola nieobsługiwane przez dany endpoint. |
| Timeout | Ustal, czy serwer przyjął żądanie, czy odpowiedział nagłówkami, czy wysyłał fragmenty/ramki. Dopiero potem zwiększ timeout. |
| Model Live / audio / streaming nie działa | Sprawdź wymagany transport (WebSocket, bidi), handshake, setup message, kolejność wiadomości i obsługę odpowiedzi. Zwykłe `generateContent` nie jest zamiennikiem Live API. |
| 429 / quota | Rozróżnij quota projektu, rate limit, billing, model eligibility i liczbę rzeczywistych żądań. Zmierz requesty po stronie adaptera; nie wnioskuj z liczby widocznych bloków UI. |

Diagnostyka w małych krokach:
1. potwierdź wersję i katalog roboczy;
2. potwierdź parsowanie configu;
3. potwierdź listę providerów/modeli;
4. sprawdź dostępność credential bez ujawniania sekretu;
5. wykonaj pojedynczy minimalny request;
6. przeanalizuj status, endpoint, czas i liczbę wywołań;
7. dodaj test regresyjny dla wykrytego błędu.

## 5. Migracja konfiguracji V1 → V2

OpenCode V2 potrafi normalizować część starszych pól w pamięci, więc nie trzeba przepisywać wszystkiego przed pierwszym uruchomieniem. **Kod pluginów i integracje z API serwera są istotnymi wyjątkami**. Konwersję rób etapami i zachowaj kopię V1.

| V1 | Natywne V2 | Uwagi |
|---|---|---|
| `provider` | `providers` | Provider fields zmieniają się szerzej niż tylko nazwa mapy. |
| `npm` | `package` | Pakiety AI SDK w V2 mogą wymagać prefiksu `aisdk:`; natywne pakiety OpenCode używają `@opencode/ai/providers/...`. |
| `api` | `settings.baseURL` | Weryfikuj ścieżkę endpointu. |
| provider `options` | `settings`, `headers`, `body` | Rozdziel opcje runtime, nagłówki i pola request body. |
| model `id` | `modelID` | Klucz modelu mapy nadal stanowi alias OpenCode. |
| `tool_call`, `modalities` | `capabilities.tools/input/output` | Przenieś semantykę możliwości. |
| variants jako obiekt | `variants` jako tablica z `id` | Nie zakładaj identycznego kształtu. |
| `plugin` | `plugins` | Konfiguracja pakietu zmienia tuple na obiekt `{package, options}`. |
| `agent` | `agents` | W definicjach JSON: `prompt` → `system`, `disable` → `disabled`, `permission` → `permissions`. |
| `mode` map | `agents` | Stare mapy mode reprezentują zwykle agentów primary. |
| `command` | `commands` | `subtask` → `subagent`; wariant modelu dołącza się jako `#variant`. |
| `skills.paths` i `skills.urls` | tablica `skills` | Ścieżki i URL-e w jednej uporządkowanej tablicy. |
| `permission` | `permissions` | V2 używa uporządkowanej listy reguł. |
| `bash` | `shell` | Zmiana nazwy akcji uprawnień. |
| `task` | `subagent` | Zmiana nazwy akcji uprawnień. |
| `write`, `patch` | `edit` | Zmiana nazwy akcji uprawnień. |
| `mcp.<server>` | `mcp.servers.<server>` | `enabled` → `disabled` (odwrócona semantyka), timeouty mogą być obiektem. |
| `autoshare` | `share` | `true` staje się zwykle `"auto"`. |
| `snapshot` | `snapshots` | Liczba mnoga. |
| `attachment` | `media` | Ustawienia mediów. |
| `small_model` | model agenta `title` | W V2 użyj `agents.title.model`. |
| `tui.json(c)` | `cli.json` | Ustawienia klienta terminalowego; nie są to ustawienia serwera. |

Provider ID, które zmieniły nazwę w natywnej V2:
- `azure-cognitive-services` → `azure`
- `google-vertex-anthropic` → `google-vertex`

W mieszanej konfiguracji V2 nie mieszaj pól V1 i V2 wewnątrz pojedynczej definicji providera, modelu, agenta lub komendy. Część pól jest normalizowana, ale nie ma rekurencyjnego automatycznego rozpoznawania obu formatów we wszystkich zagnieżdżeniach. Ostrzeżenia o polach ignorowanych trzeba traktować poważnie.

### 5.1 Co naprawdę łamie zgodność

- **Pluginy V1 nie działają jako pluginy V2** tylko dlatego, że zmieniono ścieżkę lub nazwę konfiguracji.
- **API serwera i klienty** mają nowe kontrakty; integracje korzystające ze starego API trzeba dostosować.
- **Konfiguracja TUI/CLI** przechodzi z warstwowych `tui.json(c)` do globalnego `cli.json`.
- Niektóre dawne pola są akceptowane przez parser, ale w V2 nie mają działania; czytaj ostrzeżenia i listę pól bez odpowiednika w migracji.

Dokumentacja V2 jest aktywnie zmieniana i różne strony/wersje mogą opisywać inną dystrybucję (np. sposób instalacji równoległej V1/V2). W praktyce rozstrzygaj to przez `opencode --version`, ścieżkę binarki, aktualną stronę migracji dla używanej dystrybucji i jej CLI — nie kopiuj bezwarunkowo instrukcji instalacyjnej z archiwalnego wpisu.

## 6. Agenci, instrukcje i subagenci

### 6.1 AGENTS.md

`AGENTS.md` zawiera reguły repozytorium: architekturę, komendy testów, konwencje, granice bezpieczeństwa i Definition of Done. Trzymaj go zwięzłego; szczegóły konkretnej procedury przenieś do skilla. Nie umieszczaj w nim sekretów ani ogromnych kopii dokumentacji.

Przydatna struktura:
- cel repozytorium i katalogi;
- wymagane komendy testowe;
- zasady edycji / migracji;
- standardy kodu;
- definicja zakończenia zadania;
- pliki źródłowe prawdy.

### 6.2 Agent Markdown w V2

Przykład agenta tylko do przeglądu:

```md
---
description: Przegląda zmiany pod kątem regresji i luk w testach
mode: subagent
model: openai/model-id
permissions:
  - action: edit
    resource: "*"
    effect: deny
---
Sprawdź diff, testy i kontrakty. Nie modyfikuj plików.
Zwróć ustalenia uporządkowane według ważności, z dowodami.
```

Umieść w `.opencode/agents/reviewer.md` (projekt) albo globalnym katalogu agentów. W V2 frontmatter definiuje metadane, a treść Markdown staje się instrukcjami systemowymi. Mode może być `primary`, `subagent` albo `all`. `hidden: true` usuwa agenta z normalnej listy. Uprawnienia rodzica do `subagent` ograniczają, które subagenty może uruchamiać; agent potomny ma własne uprawnienia.

Nie zakładaj, że agent z innym modelem automatycznie dziedziczy model z innego providera albo jego credentials. Sprawdź dostępność tego modelu w projekcie.

### 6.3 Orkiestracja zadań

Dobre zadanie dla subagenta ma:
- cel i zakres;
- listę plików lub modułów;
- wymagany wynik (raport, patch, testy);
- ograniczenia (bez zmian, bez instalacji, bez sieci itp.);
- kryteria akceptacji;
- sposób przekazania dowodów.

Równoległe agenty nie powinny edytować tych samych plików bez uzgodnionej strategii. Rozdzielaj pracę według niezależnych modułów lub powierzaj jednemu agentowi analizę, drugiemu testy, a koordynatorowi integrację i weryfikację.

## 7. Skills: instrukcje ładowane na żądanie

Skill to katalog z plikiem `SKILL.md`, metadanymi `name` i `description` w YAML frontmatter oraz opcjonalnymi materiałami pomocniczymi. Skill dostarcza wiedzę i procedurę; nie tworzy samodzielnie funkcji wykonawczej.

Przykład:
```text
.opencode/skills/opencode-specialist/
├── SKILL.md
└── references/
    └── opencode-use.md
```

Skill powinien mówić:
1. kiedy go używać;
2. jak diagnozować problem;
3. jakie źródła są nadrzędne;
4. jak rozróżniać wersje;
5. jakie operacje wymagają kopii/zgody;
6. jak zweryfikować wynik;
7. jak raportować brak dowodów.

Dłuższe tabele, schematy i przykłady trzymaj w `references/`; instrukcje główne powinny być krótkim routerem do tych materiałów. Nie zakładaj, że każdy skill jest ładowany automatycznie w każdej sesji: sprawdź ścieżki wykrywania, frontmatter, nazwę katalogu i aktualną komendę `/skill`.

## 8. Komendy

Komendy to szablony promptów, nie pełnoprawne skrypty systemowe. W V2 config używa `commands`; Markdown zwykle trafia do `.opencode/commands/<name>.md`.

Przykładowa komenda:
```md
---
description: Diagnozuje konfigurację OpenCode bez zmieniania plików
agent: explore
---
Sprawdź wersję OpenCode, katalog roboczy, wykryte pliki config i model.
Nie odczytuj sekretów. Najpierw przedstaw dowody i plan naprawy.
```

Argumenty i placeholdery komend są zależne od aktualnej dokumentacji Commands. Nie wpisuj poleceń destrukcyjnych do promptu, jeśli intencją jest analiza. Po migracji V1 sprawdź `subtask`/ `subagent` i dołączanie wariantów `#variant`.

## 9. Pluginy i rozszerzenia

### 9.1 Kiedy użyć którego mechanizmu

| Potrzeba | Najlepszy mechanizm |
|---|---|
| Wiedza, instrukcje, checklista, procedura | Skill |
| Powtarzalny prompt / skrót | Command |
| Profil roli i ograniczenia wykonawcze | Agent |
| Nowe narzędzie wywoływane przez model | Custom tool albo MCP |
| Połączenie z istniejącym serwerem narzędzi | MCP server |
| Hooki, zmiany zachowania, provider/model registry, eventy, trwały stan | Plugin |
| UI/rozszerzenie terminalowego klienta | CLI plugin, zgodnie z osobną dokumentacją |
| Zwykły skrypt lokalny | Skrypt poza OpenCode, wywoływany jawnie; nie twórz pluginu bez potrzeby |

### 9.2 Plugin V2: podstawowy szkielet

W dokumentacji V2 plugin lokalny może znajdować się w `.opencode/plugins/example/index.ts`:

```ts
import { Plugin } from "@opencode/plugin"

export default Plugin.define({
  id: "example",
  async setup(ctx) {
    await ctx.storage.set("loaded", true)
  },
})
```

Plugin ma stabilne `id`; `setup(ctx)` rejestruje hooki, transformaty, narzędzia lub subskrypcje. Może zwrócić cleanup function, która zwalnia zasoby przy wyładowaniu. Dla pakietu npm określ poprawny `package.json`, moduł ESM, eksporty i wersję `@opencode/plugin` zgodną z docelowym OpenCode.

W V2:
- `ctx.location` opisuje lokalizację załadowania pluginu;
- `ctx.options` zawiera opcje przekazane w konfiguracji;
- `ctx.storage` służy do trwałego stanu przypisanego do ID pluginu;
- `ctx.provider.transform`, `ctx.model.transform`, `ctx.tool.transform`, `ctx.command.transform`, `ctx.agent.transform` itd. modyfikują konkretne domeny;
- hooki rejestruje się w domenie, np. `ctx.tool.hook("execute.before", ...)` lub `ctx.session.hook("context", ...)`;
- transformaty muszą być tanie, powtarzalne i bez jednorazowych efektów ubocznych; wczytaj dane przed rejestracją i wywołuj `reload()`, gdy dane źródłowe się zmienią;
- event subscription i zasoby muszą mieć cleanup.

### 9.3 Rejestracja modelu przez plugin

Oficjalny wzorzec V2 to `ctx.provider.transform` z definicją providera i modeli. W ten sposób plugin może dodać model do katalogu, zamiast jedynie zmieniać tekst promptu. Wybór runtime, ID providera, `settings.baseURL`, capabilities i ID modelu muszą odpowiadać realnemu kontraktowi API.

Nie traktuj „model widoczny na liście” jako dowodu działania. Po rejestracji wykonaj prawdziwe żądanie i sprawdź transport, credential, payload i odpowiedź.

### 9.4 Plugin V1 a V2

API pluginów jest niekompatybilne:
- V1 zwykle eksportował funkcję zwracającą obiekt hooków i narzędzi z pakietu `@opencode-ai/plugin`;
- V2 eksportuje `Plugin.define({id, setup(ctx)})` z `@opencode/plugin`;
- V1 `directory/project/client` przechodzi na `ctx.location` i metody domenowe;
- stary `event` staje się `ctx.event.subscribe()`;
- stare mapy narzędzi przechodzą na `ctx.tool.transform`;
- stare hooki konfiguracyjne/providerowe przechodzą na transformacje domen;
- stare hooki zwracające `dispose()` zastępuje cleanup zwracany z `setup`.

Jeden pakiet może chwilowo wspierać V1 i V2, eksportując osobne implementacje `server()` oraz `setup()`, ale to nie oznacza automatycznej translacji API. Testuj obie implementacje osobno.

### 9.5 MCP a plugin

MCP jest zwykle najlepszy, gdy narzędzia mają działać niezależnie od konkretnego hosta i mają jasno określony kontrakt narzędzi/zasobów. Plugin OpenCode jest lepszy dla hooków wewnętrznego cyklu agenta, rejestru modeli, zdarzeń sesji i integracji z API OpenCode.

W V2 serwery MCP są pod `mcp.servers`. Serwer lokalny używa `type: "local"` i tablicy `command`; serwer zdalny zwykle używa `type: "remote"` i URL. Ustawiaj środowisko przez pole `environment` i nagłówki przez konfigurację, nie przez wpisywanie sekretów w repo. OAuth zdalnego MCP ma odrębną obsługę; `oauth: false` tylko gdy serwer używa klucza/credential w nagłówku i nie potrzebuje OAuth.

### 9.6 Walidacja i publikowanie

Lista kontrolna:
- manifest i ID są stabilne;
- zależności są minimalne i przypięte do kompatybilnych wersji;
- brak kluczy, auth.json, logów, danych użytkownika i plików środowiskowych;
- poprawne uprawnienia i walidacja wejścia narzędzi;
- test każdej ścieżki sukcesu i błędu;
- test wyładowania/cleanup;
- test czystej instalacji pakietu, a nie tylko lokalnego importu;
- test na wersji V1/V2, jeśli deklarowane jest wsparcie obu;
- dokumentacja mówi, co plugin robi, jakie dane dotyka i czego nie gwarantuje.

## 10. Projekty i workflow

### 10.1 Konfiguracja globalna vs projektowa

Globalny config ma sens dla providerów, domyślnego modelu i osobistych narzędzi. Config projektu powinien przechowywać ustawienia, które zespół chce wersjonować: reguły, komendy, agenty, nie-sekretne modele i ustawienia MCP, jeśli są bezpieczne do współdzielenia.

Nie kopiuj całej globalnej konfiguracji do repozytorium. Unikaj konfliktów nazw providerów, nadpisywania globalnych ustawień i przypadkowego commitowania sekretów.

### 10.2 Typowy cykl pracy

1. Otwórz OpenCode z katalogu repozytorium.
2. Przeczytaj `AGENTS.md`, README i instrukcje budowania/testów.
3. Ustal cel i kryteria akceptacji przed edycją.
4. Rozpoznaj stan repozytorium: branch, diff, testy i pliki zmodyfikowane wcześniej.
5. Podziel zadanie na niezależne moduły, jeśli wymaga subagentów.
6. Zmień kod w małych partiach.
7. Uruchom testy celowane, potem odpowiednie testy całościowe.
8. Przejrzyj diff, sekrety, formatowanie i niezamierzone zmiany.
9. Raportuj konkretne komendy i ich wynik; odróżnij test uruchomiony od testu zaliczonego.

### 10.3 Praktyczne „triki” bez ryzykownych hacków

- **Sprawdź wersję zanim skopiujesz przykład:** `opencode --version`.
- **Używaj schematu:** `"$schema": "https://opencode.ai/config.json"`.
- **Alias modelu:** dodaj klucz czytelny dla człowieka i ustaw `modelID` upstream; zmniejsza to zależność od zmian nazw katalogowych.
- **Oddzielny provider dla adaptera:** nie przekierowuj całej integracji do endpointu, który obsługuje tylko jeden model.
- **Sprawdź katalog modeli w bieżącym projekcie:** konfiguracja i credential mogą być zależne od kontekstu.
- **Uprawnienia przez allow/ask/deny:** użyj ograniczeń zamiast polegać na samych instrukcjach promptu.
- **Skill zamiast gigantycznego AGENTS.md:** wczytuj procedurę tylko wtedy, gdy jest potrzebna.
- **Command zamiast ponownego pisania promptu:** standaryzuje rutynę, ale nie gwarantuje, że narzędzia wykonają zadanie.
- **Loguj metadane, nie sekrety:** status HTTP, ścieżka bez tokena, czas, ID modelu, liczba prób i requestów.
- **Testuj endpoint osobno od UI:** minimalny request pomaga rozdzielić błąd OpenCode od błędu providera.
- **Zapisuj konfigurację w repozytorium z historią:** mały diff jest łatwiejszy do cofnięcia.
- **Nie edytuj plików cache jako źródła prawdy:** katalog modeli w cache może być użyteczny diagnostycznie, ale config i oficjalny runtime decydują o zachowaniu.

### 10.4 Co nie jest bezpiecznym „hackiem”

Nie obchodź limitów dostawcy przez kopiowanie tokenów z innego klienta, podszywanie się pod inny klient lub używanie prywatnych endpointów bez wspieranej integracji. Nie wyłączaj wszystkich uprawnień ani walidacji, by naprawić pojedynczy błąd. Nie kieruj produkcyjnego ruchu na localhost bez sprawdzenia procesu, zakresu nasłuchu i tego, czy adapter nie loguje danych. Nie uznawaj obejścia działającego w jednej wersji za stabilny kontrakt API.

## 11. Debugging playbook

Przed działaniem zbierz tylko niezbędne, niesekretne dane:
- wersja `opencode --version`;
- katalog roboczy;
- ścieżki configu, które istnieją;
- ID providera i modelu (bez tokenów);
- komunikat błędu i status HTTP;
- czy request w ogóle dotarł do serwera;
- liczba requestów, retry i czasy;
- wynik testu parsowania configu / lista modeli.

Następnie:
1. **Reproduce:** minimalne polecenie/żądanie, jeden przypadek.
2. **Isolate:** config vs provider vs adapter vs sieć vs model/quota.
3. **Inspect:** oficjalny schemat, logi z redakcją, kod implementacji.
4. **Patch:** najmniejsza zmiana możliwa do cofnięcia.
5. **Test:** test regresyjny przed i po poprawce, a potem smoke test.
6. **Verify:** uruchom komendy po zmianie; nie deklaruj sukcesu bez wyniku.
7. **Document:** dodaj przyczynę, wersję i ograniczenia do notatki/kompendium.

### Minimalny raport diagnostyczny

```text
OpenCode version:
Working directory:
Config source(s):
Provider/model ID:
Expected endpoint contract:
Actual endpoint/status:
Credential source (type only; no secret):
Reproduction:
Observed request count:
Root cause (verified / probable / unknown):
Patch:
Tests run + results:
Rollback:
```

## 12. Granice wiedzy i utrzymanie kompendium

- Nie wszystkie opcje są wspólne między providerami; pole `settings` zależy od wybranego runtime.
- Dostępność modelu i kwoty zmieniają się niezależnie od składni konfiguracji.
- Plugin API V2 może ewoluować podczas beta; zawsze czytaj dokumentację dla konkretnej wersji.
- Brak przykładu w dokumentacji nie dowodzi, że funkcja nie istnieje.
- Poradniki społecznościowe mogą dotyczyć V1, wcześniejszej bety V2 lub forków.
- Nie wpisuj w tym dokumencie credentiali, lokalnych tokenów, zawartości auth.json ani prywatnych logów.

Po każdej aktualizacji OpenCode:
1. sprawdź `opencode --version`;
2. przejrzyj release notes / migration guide;
3. porównaj config schema;
4. zweryfikuj provider/model, agent, MCP i pluginy;
5. zaktualizuj datę oraz sekcję zmian;
6. oznacz niezweryfikowane przykłady.

## 13. Rejestr głównych źródeł

| Temat | Oficjalne źródło |
|---|---|
| Konfiguracja i priorytety | https://opencode.ai/v2/docs/config |
| Providers i endpointy | https://opencode.ai/v2/docs/providers |
| Modele i warianty | https://opencode.ai/v2/docs/models |
| V1 → V2 | https://opencode.ai/v2/docs/migrate-v1 |
| Agenci | https://opencode.ai/v2/docs/agents |
| Skills | https://opencode.ai/v2/docs/skills |
| Commands | https://opencode.ai/v2/docs/commands |
| Permissions | https://opencode.ai/v2/docs/permissions |
| MCP | https://opencode.ai/v2/docs/mcp-servers |
| Plugin API | https://opencode.ai/v2/docs/build/plugins |
| Migracja pluginów | https://opencode.ai/v2/docs/build/plugins/migrate-v1 |
| CLI | https://opencode.ai/v2/docs/cli |
| Schemat | https://opencode.ai/config.json |
| Kod | https://github.com/anomalyco/opencode |

**Ograniczenie badania:** BrowserAct CLI nie jest zainstalowany w środowisku użytkownika, więc nie został użyty ani doinstalowany. Zastosowano Firecrawl, Exa, Parallel Search, Keenable, Context.dev oraz końcowe wyszukiwanie internetowe; wnioski oparto głównie na dokumentacji oficjalnej.