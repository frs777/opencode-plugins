import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-prototype',
  name: 'Prototype',
  version: '2.0.0',
  description: 'Build throwaway prototypes',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-prototype', description: 'Build throwaway prototypes' })
    })

    return () => console.log('[engineering-suite-prototype] Plugin unloaded')
  }
})
