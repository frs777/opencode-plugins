import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'mattpocock-skills',
  name: 'Matt Pocock Skills',
  version: '1.2.3',
  description: 'Engineering workflow skills',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'mattpocock-skills', description: 'Engineering workflow skills' })
    })

    return () => console.log('[mattpocock-skills] Plugin unloaded')
  }
})
