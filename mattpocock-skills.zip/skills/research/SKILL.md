---
name: research
description: Use when a software project or workspace needs a Markdown research note grounded in high-trust primary technical
  sources, documentation, or API facts.
metadata:
  opencode/autoinvoke: true
---

Spin up a **background agent** to do the research, so you keep working while it reads.

Its job:

1. Investigate the question against **primary sources** — official docs, source code, specs, first-party APIs — not a secondary write-up of them. Follow every claim back to the source that owns it.
2. Write the findings to a single Markdown file, citing each claim's source.
3. Save it where the repo already keeps such notes; match the existing convention, and if there is none, put it somewhere sensible and say where.
