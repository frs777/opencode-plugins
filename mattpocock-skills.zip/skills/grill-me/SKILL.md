---
name: grill-me
description: Use when the user explicitly asks to be grilled or interviewed to sharpen a plan, design, or decision before
  proceeding.
metadata:
  opencode/autoinvoke: true
---

Run a `/grilling` session.
