import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'plugin-creator-plus',
  name: 'Plugin Creator Plus',
  version: '0.1.1',
  description: '创建、测试并发布 ChatGPT 与 Codex 插件',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'plugin-creator-plus', description: '创建、测试并发布 ChatGPT 与 Codex 插件' })
    })

    return () => console.log('[plugin-creator-plus] Plugin unloaded')
  }
})
