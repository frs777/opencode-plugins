import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'frontend-design-premium',
  name: 'Frontend Design Premium',
  version: '1.4.0',
  description: 'Build production-ready UX',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'frontend-design-premium', description: 'Build production-ready UX' })
    })

    return () => console.log('[frontend-design-premium] Plugin unloaded')
  }
})
