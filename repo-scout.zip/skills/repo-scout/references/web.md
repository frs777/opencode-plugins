# Web/frontend and interaction

Inspect routes, forms, state ownership, navigation, caching, subscriptions, rendering
boundaries, server/client contracts and browser-specific assumptions. Review loading,
empty, error, timeout, retry, disabled, partial-success and stale-data states. Check
whether duplicate taps or out-of-order responses corrupt visible or stored state.

Where applicable inspect keyboard navigation, focus restoration, semantics, screen
reader labels, contrast, reduced motion, text scaling, localization/RTL, responsive
layout and touch targets. Code-based concerns are not measured accessibility or
visual verification. Record viewport, browser, input method and observed result for
actual UI checks; missing browser/device tooling is a coverage gap.

Look for hydration/client-server mismatches, unsafe HTML rendering, token exposure,
cache isolation, expensive repeated fetches and unnecessarily retained resources.
Performance claims need a relevant trace/measurement and baseline. Do not declare
an effect, rerender, bundle dependency or lack of memoization a bug by appearance.
Aesthetic suggestions are optional design proposals unless they violate a specified
requirement or show a reproducible usability problem.
