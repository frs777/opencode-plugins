# Desktop, CLI, libraries, native, embedded and protocols

For desktop/CLI inspect startup/shutdown, argument parsing, exit codes, stderr/stdout
contracts, pipe handling, filesystem permissions, path portability, encoding, config
migration, safe defaults and concurrency. Differentiate Linux/macOS/Windows targets;
compiling one does not validate the others.

For libraries/SDKs inspect public contracts, compatibility, ownership/lifetimes,
thread safety, cancellation, serialization, errors, documentation examples and
consumer tests. Assess ABI/FFI boundaries, unsafe code, integer sizes, signedness,
endianness and buffer/length validation where applicable. Native verification may
require sanitizers/fuzzing, but these are not automatically installed or authorized.

For embedded/IoT inspect resource bounds, watchdog/recovery, interrupts/concurrency,
protocol state machines, framing, declared lengths, checksums, version negotiation,
reconnect and partial packets. Use official specifications, known-answer vectors and
isolated emulators where available. Passing a parser test is not a physical-device
compatibility claim. Preserve hardware safety boundaries.

For wallets/contracts inspect chain/network separation, address formats, amount
precision, signature domain separation, replay protection, transaction serialization,
key lifecycle, confirmation/reorg handling and permission boundaries. Never request
live private keys or submit real transactions to verify a hypothesis. Use deterministic
vectors and isolated test environments. Do not invent cryptographic algorithms or
recommend home-made primitives as a convenient fix.

For games/graphics inspect frame/update ownership, resource lifecycle, input state,
save compatibility and deterministic logic where intended. Performance requires
actual target hardware/workload evidence, not engine fashion.
