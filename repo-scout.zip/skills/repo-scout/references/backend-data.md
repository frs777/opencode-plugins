# Backend, APIs, databases and data

Map API contracts, consumers, background jobs, message flows, persistence and access
control. Inspect boundary validation, tenant/user authorization, idempotency, retries,
timeouts, pagination consistency, transactional updates and error normalization.
Trace cancellation and partial failure through a complete path. Distinguish transient
failures from permanent ones and verify retry bounds and duplicate side effects.

For storage inspect migration order, version skew, locking, uniqueness, isolation,
backups/restores, schema evolution, retention and deletion. Assess queries against
actual schema and workload. N+1 or missing-index suspicions require reachability and
query plan/workload evidence before making quantitative performance claims.

For data/ML pipelines inspect provenance, schema contracts, time zones, ordering,
missing/duplicate records, replay/reprocessing, leakage, training/serving skew and
reproducible evaluation. Model quality is not verified by code review alone.

For reliability inspect health/readiness, graceful shutdown, queue backlog, bounded
concurrency, rate limiting, actionable logs/metrics and rollback behavior. Testing
must use isolated resources. Do not connect to production, run migrations, delete
data, or replay business events merely because a verification recipe suggests it.
