# Tests, delivery, documentation and observability

Map what actually runs: test framework discovery, task wiring, filters, skips,
platform/build variants and CI conditions. A file named test or a green badge does
not establish that relevant assertions were executed. Inspect mocks for behavior
they erase and assertions for the contract they actually check.

Prioritize regression tests at high-risk boundaries: interrupted writes/restores,
async cancellation, pagination, duplicate events, tenant isolation, migrations and
protocol errors. Coverage percentages are context, not a universal goal. Missing
tests are a risk/gap, not by themselves a demonstrated runtime bug.

For CI/release inspect triggers, permissions, artifact provenance, version alignment,
cache correctness, secrets and fork behavior, reproducibility, package publication,
rollback and install paths. Audit config without triggering workflows or incurring
runner costs unless authorized. Prefer existing local verification; do not silently
substitute a private paid pipeline for an unavailable local environment.

Check README, API examples, feature matrices, install commands and changelogs against
current source and release artifacts. Distinguish main, an unmerged PR, a dirty local
workspace and a shipped release. Do not claim a feature is released because source
exists. Documentation promises can reveal meaningful missing work; cosmetic prose
changes should not overwhelm a technical backlog.

For observability ask whether failures can be diagnosed without sensitive data.
Propose specific events/metrics tied to failure modes, not logging everywhere.
