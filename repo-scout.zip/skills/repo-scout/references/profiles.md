# Language and tool selection

The workflow is language-agnostic; parser and runtime verification are not. Never
claim that a filename hint equals complete support for that language or platform.

For each first-party module record: language/framework and observed versions;
manifest/build target; entry points; runtime; existing checks; environment availability;
applicable review lanes; unsupported or ambiguous constructs. Monorepos need per-module
profiles and shared contracts, not one guessed root language.

Prefer the repository's pinned toolchain and existing test commands. Read manifests,
lockfiles and CI; do not invent a command simply because it is conventional. The
following are candidate families to investigate, NOT commands or preinstalled adapters:

| Observed ecosystem | Potential existing verification |
| --- | --- |
| JS/TS and web | package scripts, configured type checker/linter, component tests, browser E2E |
| Python | project-configured lint/type checks, unit/integration tests, environment lock |
| JVM/Kotlin/Scala | declared Gradle/Maven tasks, JVM tests, platform-specific targets |
| Android | declared app/library variants, lint, JVM tests, instrumentation/emulator/device tests |
| Swift/Objective-C | package targets or Xcode schemes, unit/UI tests on applicable Apple hosts |
| Dart/Flutter | inspect SDK constraints and actual Flutter dependency, analyzer, unit/widget/integration tests |
| Go/Rust | workspace targets, compiler/static checks, unit/integration tests, races/sanitizers where applicable |
| C/C++/Zig/native | actual build system, compiler diagnostics, sanitizers, fuzzers and ABI tests |
| .NET | solutions/projects/target frameworks, build and configured analyzers/test projects |
| Ruby/PHP/Elixir/other | pinned ecosystem tools and project-defined tests discovered from source/config |
| SQL/data/IaC | target dialect/engine, migration dry-runs, schema checks, local integration fixtures |
| Solidity/Move/protocols | pinned compiler/framework, test vectors, invariants, fuzzing and isolated execution |
| Unknown language/tool | source/spec reasoning, local docs and upstream official documentation; explicit gaps |

Do not install all tools or apply every checklist. Distinguish wrapper trust, network
requirements, license/subscription costs, local resource costs and production access.
A compile pass is not functional parity; a linter pass is not semantic correctness.
A test suite pass establishes only the tests actually run, not absence of defects.
