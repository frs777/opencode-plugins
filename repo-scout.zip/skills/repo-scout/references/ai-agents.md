# AI agents, MCP, skills and model-integrated systems

Map model/provider configuration, tool registry, prompts, retrieval, persistent
memory, sessions, checkpoints, delegation and approval boundaries. Distinguish a
model's capability from what the current harness actually exposes or enforces.

Inspect tool input validation, least privilege, tenant/session isolation, prompt
injection boundaries, secret redaction, replay/duplicate actions, idempotency,
termination, bounded retries, cancellation, timeout propagation and budget controls.
Check schema/version drift between tool definitions, clients and runtime behavior.
Do not treat a tool description saying read-only as enforcement if its code can write.

For multi-agent work inspect handoff contracts, provenance, task ownership, shared
filesystem collisions and independent verification. Two agents agreeing is not
runtime evidence. A prompt saying spawn workers does not implement concurrency.
Evaluate fallback behavior when a provider, subagent, connector or tool is absent.

For skills inspect trigger precision, prompt length/loading, relative file paths,
platform assumptions, allowed operations and expected outputs. Use positive,
negative, ambiguous, clean-repo and adversarial fixtures. Measure false findings,
missed seeded defects, ungrounded success claims, tool misuse and cost—not output
volume. Model-generated test plans are not completed evaluations.

For scheduled work require explicit enablement, bounded scope, overlap prevention,
a run ledger, stale-result detection, failure reporting and publication gates.
Never silently turn a one-time code review into a persistent background worker.
