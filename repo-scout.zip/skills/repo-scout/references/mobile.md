# Mobile, cross-platform and wearables

Determine actual targets and supported OS/device ranges from manifests and product
requirements. Review native Android/iOS, Flutter, React Native and KMP with the same
end-to-end invariants while respecting platform-specific lifecycle and APIs.

Inspect process death and restoration, rotation/window resizing/foldables, navigation
and deep links, runtime permissions, background execution, cancellation, offline
state, connectivity changes, locale changes, large text and accessibility semantics.
Trace data persistence and version migration; backups and restores need interruption,
partial attachment failure, re-import, integrity and recovery analysis.

Review threading/structured concurrency, cancellation ownership, retained views or
contexts, subscription cleanup and state delivery across lifecycle transitions.
Treat a suspected leak or race as a hypothesis unless proven from reachable code or
runtime evidence. Never call a lifecycle API wrong solely by its name.

For shared libraries inspect platform implementations separately. Build a feature
parity matrix only for supported/promised features, including deliberate differences.
A shared Kotlin/Dart implementation does not establish identical native behavior.
Check store/release documentation against actual artifact behavior without assuming
unsigned/debug builds equal store builds.

For Bluetooth/NFC/location/camera/sensors and wearables, separate parser/simulator,
emulator and physical-device evidence. Simulated peripherals do not prove radio,
firmware or hardware compatibility. For automotive/physical-control software, keep
inspection and test traffic within authorized, safe, isolated scenarios; never send
actuator commands or expand hardware write permissions during discovery.

Verification ledger must identify OS version, device/emulator, build variant, app
state and actions. No Apple SDK/device means iOS runtime is blocked, not passed.
Source inspection is not UI/UX validation; screenshots alone do not test interaction.
