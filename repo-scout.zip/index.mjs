import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'repo-scout',
  name: 'Repo Scout',
  version: '0.1.2',
  description: 'Find real work in any repo',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'repo-scout', description: 'Find real work in any repo' })
    })

    return () => console.log('[repo-scout] Plugin unloaded')
  }
})
