# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: .grok-plugin/plugin.json (stripped: .grok-plugin/plugin.json)
- Skipped unsupported source entry: CHANGELOG.md (stripped: CHANGELOG.md)
- Skipped unsupported source entry: README.zh-TW.md (stripped: README.zh-TW.md)
- Skipped unsupported source entry: install.py (stripped: install.py)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs