import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'comptext-evidence',
  name: 'CompText Evidence',
  version: '0.1.0',
  description: 'Verify evidence freshness',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'comptext-evidence', description: 'Verify evidence freshness' })
    })

    return () => console.log('[comptext-evidence] Plugin unloaded')
  }
})
