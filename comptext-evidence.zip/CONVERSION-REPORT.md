# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: fixtures/failed-mutation-does-not-stale.jsonl (stripped: fixtures/failed-mutation-does-not-stale.jsonl)
- Skipped unsupported source entry: fixtures/fresh-after-verification.jsonl (stripped: fixtures/fresh-after-verification.jsonl)
- Skipped unsupported source entry: fixtures/stale-after-mutation.jsonl (stripped: fixtures/stale-after-mutation.jsonl)
- Skipped unsupported source entry: PRIVACY.md (stripped: PRIVACY.md)
- Skipped unsupported source entry: TERMS.md (stripped: TERMS.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs