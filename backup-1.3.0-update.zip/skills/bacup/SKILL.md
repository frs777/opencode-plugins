---
name: bacup
description: Zapisuje i odtwarza mały handoff zawierający wyłącznie kluczowy kontekst bieżącej rozmowy. Użyj po „Bacup zapisz” albo „Bacup odczytaj <ścieżka>”.
metadata:
  opencode/autoinvoke: true
---

# Bacup — zwięzły handoff rozmowy

## Twarda zasada źródła

**Bacup korzysta wyłącznie z kontekstu bieżącej rozmowy dostępnego modelowi.** Nie wolno podczas `Bacup zapisz` przeszukiwać, otwierać, indeksować ani archiwizować projektu, repozytorium, katalogu domowego, plików, załączników, pamięci zewnętrznej, Stele, Engram, connectorów, MCP ani innych źródeł tylko po to, aby uzupełnić backup.

Nie twórz kopii projektu. Nie zapisuj kodu, logów, diffów, katalogów, zależności, buildów ani dużych artefaktów.

## Bacup zapisz

Na podstawie **wyłącznie bieżącego kontekstu rozmowy** utwórz krótki handoff do pliku Markdown. Zapisuj tylko informacje potrzebne do wznowienia pracy przez inną sesję.

### Co zachować

- **Cel** — 1–3 zdania.
- **Kluczowe zagadnienia** — tylko tematy istotne dla kontynuacji.
- **Najważniejsze ustalenia i decyzje** — co zostało faktycznie uzgodnione.
- **Wnioski** — tylko wnioski wynikające z rozmowy.
- **Aktualny stan** — co faktycznie wykonano i gdzie praca się zatrzymała.
- **Problemy / ograniczenia** — tylko aktywne i istotne.
- **Ważne identyfikatory i ścieżki** — tylko te, które są niezbędne do wznowienia pracy; same referencje, nigdy zawartość plików.
- **Otwarte zadania** — maksymalnie kilka najważniejszych.
- **Następny krok** — jedna konkretna pierwsza czynność.

### Czego NIE zachowywać

- pełnego transkryptu rozmowy;
- wszystkich wiadomości, odpowiedzi lub narzędzi;
- zawartości projektu lub repozytorium;
- całych plików, kodu, logów, diffów i dokumentacji;
- danych, które można ponownie odczytać z projektu;
- informacji pobranych z pamięci zewnętrznej;
- sekretów, tokenów, haseł i kluczy API.

### Limit kompresji

Backup ma być **mały**. Preferuj około 1–3 strony Markdown i zwykle nie więcej niż 1500 słów. Jeśli rozmowa jest bardzo długa, wybierz tylko informacje, których utrata realnie uniemożliwiłaby lub utrudniła kontynuację.

### Format

```markdown
# Bacup — <tytuł rozmowy>

## Cel
...

## Kluczowe zagadnienia
- ...

## Ustalenia i decyzje
- ...

## Wnioski
- ...

## Aktualny stan
...

## Problemy / ograniczenia
- ...

## Ważne referencje
- ...

## Otwarte zadania
- ...

## Następny krok
...
```

Pomijaj puste sekcje. Nie wypełniaj ich domysłami.

## Zapis pliku

1. Zapisz do `~/Dokumenty/`. Utwórz katalog tylko jeśli jest potrzebny do zapisu.
2. Nazwa: `bacup-<nazwa-czatu>-<YYYY-MM-DD>.md`; jeśli tytuł rozmowy nie jest dostępny, użyj `sesja`.
3. Nie nadpisuj istniejącego backupu bez potrzeby; dodaj `-2`, `-3` itd.
4. Po zapisie zweryfikuj, że plik zawiera **wyłącznie skompresowany handoff rozmowy**, a nie dane projektu.
5. Podaj rzeczywistą ścieżkę pliku.

## Bacup odczytaj <ścieżka>

1. Odczytaj wskazany plik.
2. Użyj jego treści jako kontekstu wznowienia rozmowy.
3. **Nie inicjalizuj Stele ani Engram.**
4. **Nie przeszukuj projektu, repozytorium ani zewnętrznej pamięci w celu odzyskania stanu.**
5. Nie porównuj backupu z aktualnym projektem automatycznie. Jeśli użytkownik później poprosi o weryfikację, jest to osobne zadanie.
6. Przywróć tylko: cel, wymagania, ustalenia, decyzje, aktualny stan, otwarte zadania i następny krok zapisane w bacupie.

## Zasada końcowa

`Bacup zapisz` = **tylko kontekst rozmowy → mały handoff → plik Markdown**.

`Bacup odczytaj <plik>` = **tylko odczyt tego handoffu → odzyskanie kontekstu rozmowy**.

Żadnego skanowania projektu. Żadnej zewnętrznej pamięci. Żadnego archiwum 1,6 GB.
