import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'bacup',
  name: 'bacup',
  version: '1.3.0',
  description: 'Zapisuje zwięzły handoff najważniejszych informacji z bieżącej rozmowy, bez archiwizowania projektu i bez zewnętrznej pamięci.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'bacup', description: 'Zapisuje zwięzły handoff najważniejszych informacji z bieżącej rozmowy, bez archiwizowania projektu i bez zewnętrznej pamięci.' })
    })

    return () => console.log('[bacup] Plugin unloaded')
  }
})
