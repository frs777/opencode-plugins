import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-mobile-mockup',
  name: 'MobileMockup',
  version: '2.0.0',
  description: 'Generate mobile design comps',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-mobile-mockup', description: 'Generate mobile design comps' })
    })

    return () => console.log('[engineering-suite-mobile-mockup] Plugin unloaded')
  }
})
