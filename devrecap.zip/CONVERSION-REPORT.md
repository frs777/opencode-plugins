# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: apps/cli/src/commands.ts (stripped: apps/cli/src/commands.ts)
- Skipped unsupported source entry: apps/cli/src/config.ts (stripped: apps/cli/src/config.ts)
- Skipped unsupported source entry: apps/cli/src/index.ts (stripped: apps/cli/src/index.ts)
- Skipped unsupported source entry: apps/cli/src/source-runner.ts (stripped: apps/cli/src/source-runner.ts)
- Skipped unsupported source entry: packages/activity-engine/src/classify.ts (stripped: packages/activity-engine/src/classify.ts)
- Skipped unsupported source entry: packages/activity-engine/src/correlate.ts (stripped: packages/activity-engine/src/correlate.ts)
- Skipped unsupported source entry: packages/activity-engine/src/engine.ts (stripped: packages/activity-engine/src/engine.ts)
- Skipped unsupported source entry: packages/activity-engine/src/index.ts (stripped: packages/activity-engine/src/index.ts)
- Skipped unsupported source entry: packages/activity-engine/src/normalize.ts (stripped: packages/activity-engine/src/normalize.ts)
- Skipped unsupported source entry: packages/activity-engine/src/projects.ts (stripped: packages/activity-engine/src/projects.ts)
- Skipped unsupported source entry: packages/activity-engine/src/synthesize.ts (stripped: packages/activity-engine/src/synthesize.ts)
- Skipped unsupported source entry: packages/codex-parser/src/adapter.ts (stripped: packages/codex-parser/src/adapter.ts)
- Skipped unsupported source entry: packages/codex-parser/src/index.ts (stripped: packages/codex-parser/src/index.ts)
- Skipped unsupported source entry: packages/codex-parser/src/parse.ts (stripped: packages/codex-parser/src/parse.ts)
- Skipped unsupported source entry: packages/codex-parser/src/stream.ts (stripped: packages/codex-parser/src/stream.ts)
- Skipped unsupported source entry: packages/collectors/src/index.ts (stripped: packages/collectors/src/index.ts)
- Skipped unsupported source entry: packages/git-parser/src/git.ts (stripped: packages/git-parser/src/git.ts)
- Skipped unsupported source entry: packages/git-parser/src/index.ts (stripped: packages/git-parser/src/index.ts)
- Skipped unsupported source entry: packages/import-core/src/decompress.ts (stripped: packages/import-core/src/decompress.ts)
- Skipped unsupported source entry: packages/import-core/src/detect.ts (stripped: packages/import-core/src/detect.ts)
- Skipped unsupported source entry: packages/import-core/src/generic.ts (stripped: packages/import-core/src/generic.ts)
- Skipped unsupported source entry: packages/import-core/src/index.ts (stripped: packages/import-core/src/index.ts)
- Skipped unsupported source entry: packages/import-core/src/limits.ts (stripped: packages/import-core/src/limits.ts)
- Skipped unsupported source entry: packages/import-core/src/storage.ts (stripped: packages/import-core/src/storage.ts)
- Skipped unsupported source entry: packages/report-engine/src/analysis-quality.ts (stripped: packages/report-engine/src/analysis-quality.ts)
- Skipped unsupported source entry: packages/report-engine/src/analysis.ts (stripped: packages/report-engine/src/analysis.ts)
- Skipped unsupported source entry: packages/report-engine/src/build.ts (stripped: packages/report-engine/src/build.ts)
- Skipped unsupported source entry: packages/report-engine/src/composer.ts (stripped: packages/report-engine/src/composer.ts)
- Skipped unsupported source entry: packages/report-engine/src/context.ts (stripped: packages/report-engine/src/context.ts)
- Skipped unsupported source entry: packages/report-engine/src/deterministic.ts (stripped: packages/report-engine/src/deterministic.ts)
- Skipped unsupported source entry: packages/report-engine/src/html.ts (stripped: packages/report-engine/src/html.ts)
- Skipped unsupported source entry: packages/report-engine/src/index.ts (stripped: packages/report-engine/src/index.ts)
- Skipped unsupported source entry: packages/report-engine/src/language.ts (stripped: packages/report-engine/src/language.ts)
- Skipped unsupported source entry: packages/report-engine/src/providers.ts (stripped: packages/report-engine/src/providers.ts)
- Skipped unsupported source entry: packages/report-engine/src/redact.ts (stripped: packages/report-engine/src/redact.ts)
- Skipped unsupported source entry: packages/report-engine/src/validate.ts (stripped: packages/report-engine/src/validate.ts)
- Skipped unsupported source entry: packages/report-engine/src/workstreams.ts (stripped: packages/report-engine/src/workstreams.ts)
- Skipped unsupported source entry: packages/shared/src/db.ts (stripped: packages/shared/src/db.ts)
- Skipped unsupported source entry: packages/shared/src/index.ts (stripped: packages/shared/src/index.ts)
- Skipped unsupported source entry: packages/shared/src/migrations.ts (stripped: packages/shared/src/migrations.ts)
- Skipped unsupported source entry: packages/shared/src/settings.ts (stripped: packages/shared/src/settings.ts)
- Skipped unsupported source entry: packages/shared/src/types.ts (stripped: packages/shared/src/types.ts)
- Skipped unsupported source entry: packages/shared/src/util.ts (stripped: packages/shared/src/util.ts)
- Skipped unsupported source entry: packages/shared/src/validate.ts (stripped: packages/shared/src/validate.ts)
- Skipped unsupported source entry: PRIVACY.md (stripped: PRIVACY.md)
- Skipped unsupported source entry: SUPPORT.md (stripped: SUPPORT.md)
- Skipped unsupported source entry: TERMS.md (stripped: TERMS.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs