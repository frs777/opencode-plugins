import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'devrecap',
  name: 'devrecap',
  version: '0.3.0',
  description: 'Reconstruct evidence-backed developer work from authorized local coding history and let Codex turn it into polished recaps.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'devrecap', description: 'Reconstruct evidence-backed developer work from authorized local coding history and let Codex turn it into polished recaps.' })
    })

    return () => console.log('[devrecap] Plugin unloaded')
  }
})
