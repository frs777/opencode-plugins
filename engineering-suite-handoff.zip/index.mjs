import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-handoff',
  name: 'Handoff',
  version: '2.0.0',
  description: 'Package context for handoff',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-handoff', description: 'Package context for handoff' })
    })

    return () => console.log('[engineering-suite-handoff] Plugin unloaded')
  }
})
