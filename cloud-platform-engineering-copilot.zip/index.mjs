import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'cloud-platform-engineering-copilot',
  name: 'cloud-platform-engineering-copilot',
  version: '0.1.0',
  description: 'Cloud platform architecture, Kubernetes, IaC, reliability, and developer-platform workflows.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'cloud-platform-engineering-copilot', description: 'Cloud platform architecture, Kubernetes, IaC, reliability, and developer-platform workflows.' })
    })

    return () => console.log('[cloud-platform-engineering-copilot] Plugin unloaded')
  }
})
