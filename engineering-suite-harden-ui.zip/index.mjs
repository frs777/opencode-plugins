import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-harden-ui',
  name: 'HardenUI',
  version: '2.0.0',
  description: 'Harden UI edge cases',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-harden-ui', description: 'Harden UI edge cases' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'engineering-suite-harden-ui', description: 'Harden UI edge cases agents' })
    })

    return () => console.log('[engineering-suite-harden-ui] Plugin unloaded')
  }
})
