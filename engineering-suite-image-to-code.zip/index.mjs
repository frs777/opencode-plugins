import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-image-to-code',
  name: 'ImageToCode',
  version: '2.0.0',
  description: 'Turn visual refs into UI',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-image-to-code', description: 'Turn visual refs into UI' })
    })

    return () => console.log('[engineering-suite-image-to-code] Plugin unloaded')
  }
})
