import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite',
  name: 'EngineeringSuite',
  version: '1.1.1',
  description: 'Engineering skill toolkit',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite', description: 'Engineering skill toolkit' })
    })

    return () => console.log('[engineering-suite] Plugin unloaded')
  }
})
