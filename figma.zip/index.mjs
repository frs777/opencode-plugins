import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'figma',
  name: 'Figma',
  version: '15.0.0',
  description: 'Create designs, ship to code',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'figma', description: 'Create designs, ship to code' })
    })

    return () => console.log('[figma] Plugin unloaded')
  }
})
