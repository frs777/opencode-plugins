import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'webmcp-enable',
  name: 'WebMCP Enable',
  version: '1.0.2',
  description: 'Build and verify WebMCP ',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'webmcp-enable', description: 'Build and verify WebMCP ' })
    })

    return () => console.log('[webmcp-enable] Plugin unloaded')
  }
})
