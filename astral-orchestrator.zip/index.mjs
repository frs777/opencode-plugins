import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'astral-orchestrator',
  name: 'astral-orchestrator',
  version: '3.12.1',
  description: 'Automatically chooses and coordinates GPT models for project tasks, with the right effort and safeguards for each job.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'astral-orchestrator', description: 'Automatically chooses and coordinates GPT models for project tasks, with the right effort and safeguards for each job.' })
    })

    // Register agents
    await ctx.agent.transform(editor => {
      editor.namespace({ name: 'astral-orchestrator', description: 'Automatically chooses and coordinates GPT models for project tasks, with the right effort and safeguards for each job. agents' })
    })

    return () => console.log('[astral-orchestrator] Plugin unloaded')
  }
})
