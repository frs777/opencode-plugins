import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'skarn',
  name: 'Skarn',
  version: '0.27.0',
  description: 'AI session security scanner',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'skarn', description: 'AI session security scanner' })
    })

    return () => console.log('[skarn] Plugin unloaded')
  }
})
