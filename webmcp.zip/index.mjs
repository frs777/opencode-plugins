import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'webmcp',
  name: 'WebMCP',
  version: '0.1.1',
  description: 'Add reliable WebMCP tools to websites.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'webmcp', description: 'Add reliable WebMCP tools to websites.' })
    })

    return () => console.log('[webmcp] Plugin unloaded')
  }
})
