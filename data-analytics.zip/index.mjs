import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'data-analytics',
  name: 'Data',
  version: '1.0.11',
  description: 'Answer questions with data',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'data-analytics', description: 'Answer questions with data' })
    })

    return () => console.log('[data-analytics] Plugin unloaded')
  }
})
