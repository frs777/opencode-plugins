import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'canonical-memory-verifier',
  name: 'Canonical Memory Verifier',
  version: '0.1.0',
  description: 'Verify imported agent memory',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'canonical-memory-verifier', description: 'Verify imported agent memory' })
    })

    // Register tools
    await ctx.tool.transform(editor => {
      editor.namespace({ name: 'canonical-memory-verifier', description: 'Verify imported agent memory tools' })
    })

    return () => console.log('[canonical-memory-verifier] Plugin unloaded')
  }
})
