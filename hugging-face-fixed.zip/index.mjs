import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'hugging-face',
  name: 'Hugging Face',
  version: '1.0.0',
  description: 'Inspect models, datasets, Spaces, and research',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'hugging-face', description: 'Inspect models, datasets, Spaces, and research' })
    })

    return () => console.log('[hugging-face] Plugin unloaded')
  }
})
