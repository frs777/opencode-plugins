import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'pstack-plugin',
  name: 'pstack',
  version: '0.2.0',
  description: 'Engineering agent workflows',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'pstack-plugin', description: 'Engineering agent workflows' })
    })

    return () => console.log('[pstack-plugin] Plugin unloaded')
  }
})
