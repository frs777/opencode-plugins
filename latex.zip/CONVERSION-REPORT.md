# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: bin/tectonic (stripped: bin/tectonic)
- Skipped unsupported source entry: tests/test_compile_latex_strategy.py (stripped: tests/test_compile_latex_strategy.py)
- Skipped unsupported source entry: tests/test_install_texlive_profile.py (stripped: tests/test_install_texlive_profile.py)
- Skipped unsupported source entry: DEPENDENCIES.md (stripped: DEPENDENCIES.md)
- Skipped unsupported source entry: THIRD_PARTY_NOTICES.md (stripped: THIRD_PARTY_NOTICES.md)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs