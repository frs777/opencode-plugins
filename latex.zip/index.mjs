import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'latex',
  name: 'LaTeX',
  version: '0.2.7',
  description: 'Compile LaTeX with TeX tools',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'latex', description: 'Compile LaTeX with TeX tools' })
    })

    return () => console.log('[latex] Plugin unloaded')
  }
})
