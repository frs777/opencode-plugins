import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'skillquiver',
  name: 'Skillquiver',
  version: '2.1.0',
  description: 'Plan, code, debug, and review.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'skillquiver', description: 'Plan, code, debug, and review.' })
    })

    return () => console.log('[skillquiver] Plugin unloaded')
  }
})
