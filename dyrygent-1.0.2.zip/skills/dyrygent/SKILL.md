---
name: dyrygent
description: >-
  Procedura orkiestracji pracy wielu agentów - dekompozycja celu na elementy,
  dobór profilu wykonawcy według zdolności (model i uprawnienia), układanie fal
  równoległych, zlecanie subagentom, weryfikacja i raport. Użyj, gdy zadanie jest
  zbyt duże na jedną sesję, wymaga równoległego wykonania, albo trzeba rozdzielić
  pracę między modele o różnych kompetencjach (np. tani model tylko indeksuje,
  mocny koduje). Wyzwalacze: "podziel na zadania", "zrównoleglij", "orkiestruj",
  "rozdeleguj", "/dyrygent".
---

# Dyrygent — procedura orkiestracji

Cel: zamienić jedno duże zlecenie w zestaw małych, rozłącznych elementów z przypisanym wykonawcą i kolejnością.

## Anatomia elementu

```
id:            E1
cel:           jedno zdanie, czasownik dokonany
typ:           code | review | index | mech
zakres:        dokładne ścieżki (pliki/katalogi) — bez tego element nie startuje
wejście:       co wykonawca dostaje (pliki, ustalenia, wynik E<n>)
wyjście:       dokładny format zwrotu
kryterium:     testowalny warunek akceptacji
zależy_od:     [] albo lista id
```

Jeśli element nie ma `zakresu` i `kryterium` — nie jest gotowy do zlecenia.

## Dobór profilu

| Element | Profil | Model (domyślny) | Uprawnienia |
|---|---|---|---|
| pisze/zmienia kod | `dyr-code` | mocny | edit + shell |
| ocenia wynik | `dyr-review` | mocny | read-only |
| czyta, skanuje, streszcza | `dyr-index` | tani | read-only, bez shell |
| masowa edycja wg reguły | `dyr-mech` | tani | edit w zakresie, bez shell |

Zasada: **im mniej twórcza praca, tym tańszy model**. Praca wymagająca rozumienia kodu nigdy nie idzie do profilu bez `edit`.

Zmiana modelu profilu = edycja pola `model:` w `~/.config/opencode/agents/dyr-*.md`. Nic więcej.

## Fale

1. Zbuduj graf: elementy bez zależności → fala 1, reszta → kolejne.
2. W obrębie fali zlecaj wszystko naraz (`background: true`), maks. 4 na falę.
3. Elementy edytujące muszą mieć rozłączne `zakres` w tej samej fali.
4. Po każdej fali: zbierz wyniki, zaktualizuj kontekst następnej fali.

## Zlecenie

```
subagent(agent: "dyr-code", description: "E2: <3-5 słów>", prompt: """
ZADANIE: ...
ZAKRES: ...
KONTEKST: ...
WYNIK: ...
KRYTERIUM AKCEPTACJI: ...
NIE RÓB: ...
""")
```

Prompt musi być samowystarczalny — subagent startuje z pustym kontekstem.

## Weryfikacja

- `code` i `mech` → `dyr-review` z kryterium akceptacji i listą zmienionych plików.
- `index` → sprawdź kompletność (liczby, brak `brak` tam, gdzie dane istnieją).
- FAIL → poprawka przez `sessionID` tego samego wykonawcy (nie nowa sesja).
- Dwa FAIL pod rząd → eskaluj do `dyr-code` (jeśli winny był tani profil) albo do użytkownika.

## Raport

```
| id | profil | status | wynik (1 linia) |
```
Plus: elementy odrzucone i dlaczego, następny krok. Bez wklejania odpowiedzi subagentów.

## Anti-wzorce

- 12 drobnych elementów zamiast 4 sensownych — łącz.
- Równoległa edycja tych samych plików → konflikty i nadpisania.
- Zlecenie „popraw cały projekt” bez zakresu — wykonawca zgadnie i zepsuje.
- Oddanie weryfikacji temu samemu profilowi, który pisał kod.
- Użycie `dyr-index` do pracy wymagającej decyzji (nie ma `edit`, skończy się `NIE MOŻE WYKONAĆ`).
