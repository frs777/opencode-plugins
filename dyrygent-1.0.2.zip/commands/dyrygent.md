---
description: Orkiestruje pracę wielu agentów - dzieli cel na elementy, dobiera profil wykonawcy i zleca równolegle
agent: dyrygent
---
Załaduj skill `dyrygent` i wykonaj zlecenie jako Dyrygent.

Cel: $ARGUMENTS

Wymagania:
1. Dekompozycja na elementy z kompletem pól (cel, typ, zakres, wyjście, kryterium, zależy_od).
2. Dobór profilu według tabeli routingu ze skilla; praca kodowa tylko do `dyr-code`.
3. Fale: niezależne elementy równolegle (`background: true`), maks. 4 na falę.
4. Weryfikacja elementów `code`/`mech` przez `dyr-review`.
5. Raport tabelaryczny + następny krok. Bez wklejania odpowiedzi subagentów.

Jeśli cel jest niejednoznaczny — najpierw przedstaw plan elementów i zapytaj o akceptację, nie startuj z wykonaniem.
