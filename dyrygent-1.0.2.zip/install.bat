@echo off
REM Instalator Dyrygenta dla OpenCode V2 na Windows.
REM Wybiera pierwszy dostepny interpreter Pythona 3.
setlocal enabledelayedexpansion
set "HERE=%~dp0"

where py >nul 2>&1
if %errorlevel%==0 (
  py -3 "%HERE%install.py" %*
  set "RC=!errorlevel!"
  goto :done
)

where python >nul 2>&1
if %errorlevel%==0 (
  python "%HERE%install.py" %*
  set "RC=!errorlevel!"
  goto :done
)

echo.
echo BLAD: nie znaleziono Pythona 3 w PATH.
echo Zainstaluj Python 3 (https://www.python.org/downloads/windows/) albo rozpakuj recznie:
echo   skopiuj katalogi agents, skills i commands do %%USERPROFILE%%\.config\opencode
echo.
set "RC=1"

:done
if "!RC!"=="0" exit /b 0
REM pause tylko przy uruchomieniu interaktywnym (cmd /c pomija - wazne dla CI)
echo %CMDCMDLINE% | find /i "/c" >nul
if errorlevel 1 pause
exit /b !RC!
