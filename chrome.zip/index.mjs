import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'chrome',
  name: 'Chrome',
  version: '26.917.71314',
  description: 'Control Chrome with ChatGPT',
  async setup(ctx) {
    return () => console.log('[chrome] Plugin unloaded')
  }
})
