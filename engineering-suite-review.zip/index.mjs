import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-review',
  name: 'Review',
  version: '2.0.0',
  description: 'Review code from every angle',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-review', description: 'Review code from every angle' })
    })

    return () => console.log('[engineering-suite-review] Plugin unloaded')
  }
})
