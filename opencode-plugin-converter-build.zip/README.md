# OpenCode Plugin Bridge

Bidirectional converter for skill/plugin archives:

- ChatGPT/Codex -> OpenCode V2
- OpenCode V2 -> ChatGPT/Codex
- command namespace mapping: `gpt-*` <-> `oc-*`
- OpenCode skills are emitted as `.opencode/skills/<id>/SKILL.md`
- OpenCode commands are emitted as `.opencode/commands/<name>.md`
- lossy/unsupported entries are reported in `CONVERSION-REPORT.md`
- no source archive is modified in place

The implementation follows the current OpenCode V2 plugin, command, tool, instruction, agent, MCP server, and skill contracts.

New components added (Faza 2-3):
- `convertPluginManifest` — manifest conversion (`package.json` ↔ `opencode.json`)
- `convertMainPluginFile` — plugin entry file conversion (`index.*`)
- `convertTools` — tool registry conversion
- `convertAgents` — agent definition conversion
- `convertMcpServers` — MCP server configuration conversion
- `convertInstructions` — instruction mapping
- `validateOpenCodePlugin` — structural validation against OpenCode V2 schema (simplified)

CLI tools expanded (Faza 2.3):
- `convert-full` — full plugin conversion
- `validate-only` — validation without conversion
- `batch-convert` — batch mode
- `dry-run` — preview without output
- `report-format` — configurable report format
