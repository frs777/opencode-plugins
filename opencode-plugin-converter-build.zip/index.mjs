import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'converted-plugin',
  name: 'Converted Plugin',
  version: '1.0.0',
  description: 'Converted plugin',
  async setup(ctx) {
    return () => console.log('[converted-plugin] Plugin unloaded')
  }
})
