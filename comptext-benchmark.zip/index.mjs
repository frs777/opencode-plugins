import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'comptext-benchmark',
  name: 'CompText Benchmark',
  version: '0.1.5',
  description: 'Benchmark Raw vs CompText.',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'comptext-benchmark', description: 'Benchmark Raw vs CompText.' })
    })

    return () => console.log('[comptext-benchmark] Plugin unloaded')
  }
})
