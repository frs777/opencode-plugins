import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'agent-skills',
  name: 'Agent Skills',
  version: '0.6.10',
  description: 'Engineering agent workflows',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'agent-skills', description: 'Engineering agent workflows' })
    })

    return () => console.log('[agent-skills] Plugin unloaded')
  }
})
