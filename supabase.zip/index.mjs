import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'supabase',
  name: 'Supabase',
  version: '1.0.0',
  description: 'Manage and query databases',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'supabase', description: 'Manage and query databases' })
    })

    return () => console.log('[supabase] Plugin unloaded')
  }
})
