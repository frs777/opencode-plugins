import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'documents',
  name: 'Documents',
  version: '26.904.11930',
  description: 'Create and edit documents',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'documents', description: 'Create and edit documents' })
    })

    return () => console.log('[documents] Plugin unloaded')
  }
})
