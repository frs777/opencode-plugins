# OpenCode conversion report

Target: OpenCode V2

## Warnings
- Skipped unsupported source entry: third_party_licenses/addy-LICENSE (stripped: third_party_licenses/addy-LICENSE)
- Skipped unsupported source entry: third_party_licenses/aihero-LICENSE (stripped: third_party_licenses/aihero-LICENSE)
- Skipped unsupported source entry: third_party_licenses/ponytail-LICENSE (stripped: third_party_licenses/ponytail-LICENSE)
- Skipped unsupported source entry: third_party_licenses/taste-LICENSE (stripped: third_party_licenses/taste-LICENSE)
- Skipped unsupported source entry: THIRD_PARTY_NOTICES.md (stripped: THIRD_PARTY_NOTICES.md)
- Skipped unsupported source entry: UPSTREAM_LOCK.json (stripped: UPSTREAM_LOCK.json)

Plugin type detected: full
Command namespace mapping: `gpt-*` → `oc-*`.
Skills are emitted under `skills/<id>/SKILL.md`.
New components: tools, agents, mcp, plugin manifest converted.
Source: directory (unpacked plugin)
Plugin entry point: index.mjs