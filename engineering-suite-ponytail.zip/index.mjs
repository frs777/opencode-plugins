import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'engineering-suite-ponytail',
  name: 'Ponytail',
  version: '2.0.0',
  description: 'Cut code and complexity',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'engineering-suite-ponytail', description: 'Cut code and complexity' })
    })

    return () => console.log('[engineering-suite-ponytail] Plugin unloaded')
  }
})
