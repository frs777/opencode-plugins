import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'browser-act',
  name: 'BrowserAct',
  version: '0.1.6',
  description: 'Web browser automation',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'browser-act', description: 'Web browser automation' })
    })

    return () => console.log('[browser-act] Plugin unloaded')
  }
})
