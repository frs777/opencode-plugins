import { Plugin } from '@opencode/plugin';

export default Plugin.define({
  id: 'visualize',
  name: 'Visualize',
  version: '1.0.39',
  description: 'Create interactive visuals',
  async setup(ctx) {
    // Register skills
    await ctx.skill.transform(editor => {
      editor.namespace({ name: 'visualize', description: 'Create interactive visuals' })
    })

    return () => console.log('[visualize] Plugin unloaded')
  }
})
