---
name: visualize
description: "Create visualizations and interactive tools directly in conversation. Proactively use to show how something works; explore 'what happens when', 'what changes', or 'help me understand'; compare or inspect; create simulations, maps, charts, graphs, and mockups. Use standard tools for static scientific figures."
---

# Visualize

- @A #prośba dla @a @new *standalone #pilnik, @website, *app @page, #składnik, @or @other @change #de #projekt @not @be @a @in-#prośba #de @visualisation #de #el #konwersacja, @even @when @the *deliverable @contain @chart @or @content @interactive.
- @A #prośba @to @preview, @explain, @or @explore @a @interface @propose w @the #konwersacja @be @a @in-#prośba #de @visualisation #de #el #konwersacja.
- @Create @a @visual @only @when @the #potrzebowanie #de #użytkownik #para @see @or @explore#prpers @in @the #konwersacja i #prpers *materially @improve @the #objaśnienie. @Not @create @a *inline @visual @merely @because @the #prośba @involve @data, @chart, @or @a @page @interactive.
- @Use @a @normal *Markdown #stół @when @the #użytkownik @ask @a #stół; @return #prpers @directly i @not @create @a #pilnik #de @visualisation.
- @Use *Mermaid @when *labeled @node i @edge @fully @explain @a #struktura @static; @return @a @normal *fenced *Mermaid @block i @no #pilnik #de @visualisation. #Użycie *HTML dla #dynamika, @motion @spatial, *adjustable @input, i @other *visuals.
- @Work @silently @unless @block @or @the #użytkownik @explicitly @ask @progress. @Never @send *commentary @or @update #de @progress @while @read @this #wprawa @or #pisarstwo @or @update @the #pilnik; @the #odzew @final @must @be #twój @first #użytkownik-@face @message.
- @In #que@face#użytkownik #proza, @describe @only @what @the @help @visual @the #użytkownik @see @or @decide. #Prpers @keep *concise i @not @repeat #informacja @already @clear od @the @visual. @Never @announce @this #wprawa, @a #powierzchnia #de @visualisation, *widgets, *HTML, *SVG, @script, #pilnik @local, *inline @data, @or #szczegół #de @implementation.

## Read the complete skill

@Read @this #pilnik w @full @before *authoring. @Reread @truncate #zasięg w #zew #más @small. #Kopia @into @every *compaction @summary: `*Reload @the @full @visualise #wprawa #antes de @create @or @update @a @visualisation.`

## Inline HTML output contract

### File

- Dla @each @visualisation @new @or @update, @choose @a *concise *ASCII *lowercase-*hyphenated @title i @write `<@title>.*html` W @a @explicitly *writable, @durable, @task-#lokalizacja @own. @Prefer @the @thread-*scoped @directory #de @visualisation @when #prpers @appear w @the *writable #korzeń. *Otherwise, #użycie @the @task #estar @supply `@directory/` #de @work @or @create @a @directory #de @output @under @its @directory @working @authorise.
- @Never @save *inline @fragment #de @visualisation @to #biblioteka; #prpers @be @content #de #odzew, @not #que@face#użytkownik #pilnik *deliverables.
- @Never @add `*sandbox:` @link @to *inline @visualisation *HTML @unless @the #użytkownik @specifically @request @a @download.
- @Not @choose #system *temp @as a @separate *fallback. @Write @access @alone @not @guarantee @that @the #konwersacja @can @read @the #pilnik.
- @Use @the #alejka @absolute @on @the *executor @that @create @the #pilnik. @Never @assume `~/.#Kodeks` @be *writable @unless @its @directory #de @thread @appear w @the *writable #korzeń.
- @Build @the @visual w @the #konwersacja. #Użycie @the #projekt @open @when @the #użytkownik @ask @a @site, *app @page, #składnik, @or @change @to @exist #pilnik #de #projekt.

### Fragment

- Write only an HTML fragment: no `<!doctype>`, `<html>`, `<head>`, or `<body>`.
- @Write @literal *markup: #użycie `<*div @card="#de @class">@hi</*div>` @plus @a @real *newline, @never `<*div @card=\"#de @class\">@hi</*div>\*n`. @Never *embed @the @fragment w @a *inline #pyton, *JavaScript, @or #sznur #de @shell. @Read #prpers @back; @rewrite @literal `\"` @or `\*n`.
- @Keep *CSS i *JavaScript w @the @fragment @only @when @class #de #baza @be @insufficient. #Obciążenie @resource @static @only od @the *CDN *allowlist. @Never @use `*fetch`, *XHR, *WebSocket, @or @other *API #zew.
- @Give @the @fragment @root @a @unique *ID i @select #prpers z `#dokument.*getElementById(...)`. @Never @derive @the #korzeń od `#dokument.*currentScript`; @Script @may @sit @outside @the #korzeń.
- @Keep @visualisation @under #1 *MB. *Aggregate, @bin, *downsample, @reduce *precision, @or @drop *unused @field od @large *inline *datasets.
- @Check @that *JavaScript @have @no *undefined #identyfikator, @every *queried #żywioł @exist, i @the @interaction @primary @update @the @visual. @The *bundled `*python3 @script/*render.*py <@Absolute-@fragment-#alejka> [<@destination>.*html] [--@Serve]` @can @wrap @a @fragment @as *standalone *HTML @or @temporarily @serve #prpers dla #inspekcja #de @browser @when @a @preview @help z *layout, @theme, @or *runtime @behaviour. @The *rendered @preview @place @the @fragment @inside @a *sandboxed *iframe: @scope *Playwright *locators @to `@page.*frameLocator("*iframe")` I @evaluation @to @that @frame.

### Content and response

- @Keep @the @fragment @focus @on @the @visualisation. @Not @include #akapit @explanatory, #formuła, #instrukcja, @or @narrative *callouts. @Include @only @label @necessary, #legenda, @value, i #alternatywa #de #tekst @accessible.
- @Use @the @flow #de #odzew @normal. @Put @any @necessary *concise #objaśnienie @outside @the @fragment, i @add @this #odsyłacz #de @content #de #el @visualisation @on @its @line @own @where @the @visual @should @appear, @use @the @absolute *executor-#alejka #de #pilnik #de #el @side:

```text
visualize{"path":"<absolute-path>/<title>.html"}
```

- @Add `"@mode":"@wide"` dla @a @full-@screen *desktop *app *mockup, @include @its @shell #de #aplikacja. Dla @other *visuals, @add#prpers @only @when @several @panel #de @chart @compact @must @remain @side @by @side dla #porównanie @direct i @be @unreadable @at @the #szerokość @normal. @Never @widen @a @plot @single, #mapa, @grid, #wykres, @or *timeline @merely @because #prpers @be @dense. @Keep @contain *mockups, @dialog, i @screen @mobile @at #szerokość @normal; *stack @separate *self-@contain @view @vertically. @Visualisation @wide *render w @a *expandable *inline #powierzchnia @up to 1,024*px:

```text
visualize{"path":"<absolute-path>/<title>.html","mode":"wide"}
```

- *Whenever #Prpers @create @or @update @a *inline @visualisation, @include @its #odsyłacz #de @content @only w @that @turn @same @'s #odzew @final (@never w *commentary @or @update #de @progress), @even @when @edit @a #pilnik #de @exist @or *reusing @a #alejka @show w @a @turn #más @early.
- @The *JSON @object @also @may @include @a `@title` @when @need.
- *Emit @Only @the #odsyłacz #de @content dla @the @fragment. @Never @announce#prpers @as @a @artifact, @website, @output, *attachment, @link, @or @download, i @never @add @a *Markdown @link @to #prpers. @do @Not *append @a *Markdown #stół @or @repeat @the @visual @'s @data; @add @at most @one #konkluzja @short @when @the #użytkownik @need @a #objaśnienie.

### External resources

- @The *CSP @allow @only `*cdnjs.*cloudflare.*com`, `*esm.*sh`, `*cdn.*jsdelivr.@Net`, `*unpkg.*com`, `@font.*googleapis.*com`, `@font.*gstatic.*com`, i `@font.*bunny.@Net`. @Other @origin #estar @block i @fail @silently.

## Exporting an existing visualization

- @Keep @the @fragment @as @the @editable *inline #źródło. @When @the #użytkownik @explicitly @ask #para @save, #eksport, @or @publish @a @visualisation @that @be @already @show w @the #konwersacja, *render #prpers z `*python3 @script/*render.*py <@Absolute-@fragment-@destination> <#de #alejka>.*html`.
- @Apply @this @flow #de #eksport @only @when @the #użytkownik @explicitly @ask #para @turn @the @exist *inline #źródło @or @visualisation @into @a @website. Dla @a #prośba #de @website @general, @build @a @new *responsive @site w @the @directory #de @output @or #projekt @open, @use @site @when @appropriate, bez @apply @this #wprawa @'s @guidance.
- @Keep #okno `@only.*openai.*widgetState` I `#okno.*openai.*setWidgetState` #Zew od #okno\.*openai.\* @When @export: @the *standalone *wrapper #zaopatrzenie *fallback @storage @state. @Replace @other @host-@interaction @only #antes de @use @the *standalone *HTML #kodeks @outside.
- @When @the #użytkownik @ask #para @publish @or @host @a @visualisation #de @exist i @the #wprawa #de @site @be @available, @site `#de #użycie-@build` #para @choose @the #projekt i @write @the *rendered *standalone #dokument @as `@index.*html`, @then @site `#de #użycie-*hosting`.
- @If @site @be @unavailable, @offer @the *standalone *HTML bez @claim#prpers #estar @publish.

## Runtime styles

### Color

- W @each #para #de @colour, @the #baza *token @be @a #powierzchnia i @its `-*foreground` *token @be @the @content @on @that #powierzchnia. `--*muted` @Be @a #powierzchnia @fill; #użycie `--*muted-*foreground` dla #tekst @secondary.
- @Make @every @fill, #apopleksja, #tekst, #granica, @shadow, @chart, i @theme #de @colour #de #el #kanwa-@aware. @Never *hardcode #światło @or @dark *palettes @such as @panel @white, @background@off@white, #tekst @black, *slate #apopleksja, @or *Tailwind @colour *literals.
- @Keep #tekst @readable @against @its @background @actual. *Muted @Or @colour @secondary @must @retain #kontrast @clear; @never #użycie `.#Tekst-*muted` @inside `.@Card` @or @another #pojemnik @fill @unless @its @background @preserve @that #kontrast.
- @Variable #de @theme @available @include `--@background`, `--*foreground`, `--@card`, `--@card-*foreground`, `--*popover`, `--*popover-*foreground`, `--@primary`, `--@primary-*foreground`, `--@secondary`, `--@secondary-*foreground`, `--*muted`, `--*muted-*foreground`, `--@accent`, `--@accent-*foreground`, `--@destructive`, `--#granica`, `--@input`, `--@ring`, `--@blue`, `--@orange`, `--@green`, `--@red`, `--@purple`, i `--@yellow`. #Użycie `*currentColor` @inside *SVG.
- @Never @add #granica @decorative, @outline, @or #apopleksja #para @progress #hipodrom, #metr, @bar, *stacked #segment, @or @other @fill *quantitative @mark. #Użycie @a @subtle @neutral @or *translucent #hipodrom i @distinguish @mark z @fill, #kontrast, @space, @or @opacity.
- #Użycie `--*viz-@series-#1` dla @one @measure @or @state @active. #Użycie `--*viz-@series-#2` @through `--*viz-@series-#6` @only dla #kategoria @persistent @important, @series, @or #tożsamość #de #status; @never @give @every *peer @a @colour @different @by *default.
  - Dla @categorical @tile @or @node, @prefer @a @soft @series#de@opacity @low @fill z @a #granica @neutral @or @transparent; @never @colour @every @outline.
  - @Keep #stajnia #de #kartografia i @colour #de #para z @label, @shape, @or #styl #de @line.
  - @Colour #de @series @secondary @be @theme-@derive; @never @assume *hues @or @use#prpers *decoratively.
- @When @colour @encode @a #kategoria @or @series, @apply#prpers @consistently @to @the @mark @visual @corresponding—@not @just @the #legenda—i @keep @large-@area @fill @subtle.
- @Colour #de @series #de #el #użycie @only dla @line #de @chart, @mark, i #legenda *swatches. @Keep @value, #tekst #de #oś, i @label @direct @in `--*foreground` @or `--*muted-*foreground`.
- @Keep @grid #de @chart i *inactive #struktura @thin i @neutral. #Użycie #1-#2*px #alejka @structural @neutral; @never *thicken, *dash, @or @double-@stroke @the #struktura @whole.
- #Użycie `.*btn-@Primary` dla @action#de#emfaza @high; @its @neutral @fill #estar @supply @by @the @utility. #Użycie `--@primary` i `--@primary-*foreground` dla @fill @select, @active, @or @press @control. @Reserve `--@accent` i `--@accent-*foreground` dla #powierzchnia @interactive @subtle i @highlight @soft. #Guzik z `*aria-@press="@true"`, `*aria-@select="@true"`, @or `.@Be-@select` @already @use @the @primary *pairing; `.*nav-#Piguła .*nav-@Link.@Active` @keep #selekcja @neutral.

### Typography

- @Type #de @scale z `--@font-@size-#baza`. #Użycie #tekst @normal @by *default i `.#Tekst-@small` @only dla @secondary *annotations; @at @the *default @scale @this @be #14*px i #12*px. @Never @make @support #tekst #más @small @than #11*px.
- `*h1`, `*h2`, i `*h3` @be @available; #użycie @one *concise @visible @head dla @a *self-@chart @contain @or *graph, z @panel @short *headings @only @when @need. @Not @restate @the @prompt @or @add @a *redundant @title @to @other @visualisation.
- @Use #odważnik @only `#400` i `#500`. #Zwyczaj @set @never @size #de @font @or #wysokość #de @line.
- #Użycie `.@Tabular-*nums` @on @change @or @align #liczba. @Avoid #prpers dla @editorial @or @decorative *numerals.

## Composition

@Choose @the #kompozycja #más @small @that @fit.

- @Prefer #szczegół #de @interaction @over @panel @permanent, *toolbars, @repeat #legenda, @or @long *stacks. @Add @only @request @control, #użycie @one #mechanizm @per @state, i @never @invent @search, #filtr, @or @control #de @reset.
- @Keep #filtr, #selekcja, i @other #prezentacja-@interaction @only @local. Dla *drill-@down @action @that @ask #kodeks #para @investigate @or @explain @data @select, #zew `@await #okno.*openai.*sendFollowUpMessage({ @Prompt, @title })`, @where @the @title `@optional` @be @a *concise #konfirmacja-@dialog @head @of @up to #250 @character. @Include @the @select @value i #indagacja @request w @the @prompt, i @label @the @action @clearly.
- @Show @only *metrics @that @explain @the @behaviour @request. @Value @live @put @in @header #de @control @or @on @the @visual @before @card. @Treat #maksymum @as #strop, @not @target. @Never @invent *qualitative @score, @card #de #status, @or @grid #de @fact @secondary #para @fill @space.

### Remembering inline interaction state

- @Read @state @save od `#okno.*openai.*widgetState` @When *rendering. @Listen dla `*openai:@set_*globals` i @apply `@event.#Szczegół.*globals.*widgetState` @When @present. #Użycie *defaults dla @miss @or @state @incompatible.
- @After @interaction @meaningful, #okno `#de #zew.*openai.*setWidgetState({ *modelContent, *privateContent }).@Catch(() => {})`. @Update @be @optimistic. @Both @field @accept *JSON @or `*null` i @may @be @omit (@treat @as `*null`). @Each #zew @replace @the *snapshot; #prpers @keep @under #16 *KiB. @Never @save @on #obciążenie @or @event @state.
- @Put @choice @useful dla #pytanie #de @follow-up w `*modelContent`, *UI @detail @worth @restore w `*privateContent`, i @transient @or *recomputable @value @in @memory. @Only `*modelContent` @may @reach @the #model: @delivery @be @best-@effort i @not *guaranteed @across #klient. @Never @rely @on #prpers; @save @never @start @a @turn. @No #sekret @or @image.

### UI mockups

- @Include @a few *thoughtfully #alternatywa #de #projektowanie @choose *whenever #prpers @help @the #użytkownik @explore @a *mockup, bez @wait dla @the #użytkownik #para @ask. @Read [*tweak.*md](*tweak.*md) I @bind @option @useful z @the @host-@provide `*Tweak` *helper. @Keep @ordinary *mockup @interaction @local; @not @add @control #de #projektowanie @to @chart, *explainers, @or #symulacja @unless @request. @do @Not *render @a @second @panel #de @control @or @open *annotation @mode @automatically.
- "W @the *widget" @mean @the @in-@visualisation #de #konwersacja, @not @a *widget @inside @the @product @depict.
- @Product #de #użycie i #kontekst #de #platforma @already @available w @the #konwersacja; @not @search @the #projekt @to *render @a *mockup. #Zapałka @the @product @'s *chrome, #nawigacja, *typography, @colour, i @content. @If @its #projektowanie @be @unavailable, *infer @one od @the #platforma i #prośba.
- @Never @visualisation #de #użycie *CSS @variable @or @class #de @utility @inside @a *mockup (@for example, `--@card`, `--@font-@size-#baza`, `.@Card`, @or `.*btn`). @Define #korzeń-*scoped, @product-@colour @specific, *typography, #powierzchnia, i @control @instead. @This @rule *overrides @all @guidance #de @visualisation @general.
- @Keep @only @the #powierzchnia #de #konwersacja @surrounding @transparent. @Give #okno #de @product, @card, #menu, i *popovers @background @opaque, i *stack *overlays ponad @the @content #de @product.
- @Follow @the @host @'s #wygląd @active z @product-@specific `@light-@dark(<#światło>, <@dark>)` @colour @unless @a @theme @fixed #estar @request.
- **@Contain *mockup:** @frame @a #składnik, @dialog, #cecha @small, @or @screen @mobile @as a #powierzchnia #de @product @compact.
- **@Full-@page *mockup:** *Render @a *desktop #okno, @shell #de #aplikacja, @or @page @at #szerokość @full bez @a @card #de @visualisation @additional.
- @Put *app-#nawigacja @wide i *pickers w @the *app *chrome, i @control @local w #ich #składnik. @Omit @single-@option *pickers. @Show @state @realistic, @not @invent *dashboards, *filler @card, @or *oversized #ikona.

### Interactive explainer or simulation

- @Use #status @or @control @compact, @one @compact @dominant @visual, i @at most @one @single-@line @select-#szczegół @state. *Default @To @no @card #de @summary; @allow @up to @three @only @when @change *metrics @be @central.
- @Crop #spacja @empty i @fit @the @available *inline #szerokość. Dla @step-*throughs, @add @step @request @only @control i @update @one @current @visual; @never @add @control #de #parametr, #formuła, @card @metric, @or @side-@by-@step #de @side @unless @ask.

### Graphs and plots

- #Użycie *D3 dla @data-@rich *Cartesian @or @plot @statistical i @handwritten *SVG dla @simple, @directly *labeled @value. @Keep #wykres, #symulacja, i #mapa @under #ich @guidance #de @exist. #Obciążenie @the #wersja-@pin @approve-*CDN @https `#de @script://*cdn.*jsdelivr.@Net/*npm/*d3@7.9.#0/*dist/*d3.*min.*js`.
- *Render @The @figure, #legenda, i *subplots @directly @on @the #powierzchnia @host @transparent. @Frame @only @the *SVG @area #de @plot; @never @wrap @chart @in `.@Card`, @round @panel, @fill @background, @or *shadowed #pojemnik.
- @Give @the @figure @a *concise @title @visible. *Render @Each *Cartesian *subplot w @its @own *responsive *SVG z @a @match `*viewBox`, @a @frame @thin, i #tekst `@visible.#Oś-@title[@data-#oś="*x"]` i `#tekst.#Oś-@title[@data-#oś="*y"]` @show #ilość i @unit.
- @Set @each *SVG `*viewBox` od @its #pojemnik @own #estar @measure #szerokość, *redraw z `*ResizeObserver`, i @reserve @at least #64*px dla @the *y #oś. @Never @scale @down @a @fixed-#szerokość `*viewBox`.
- @Derive *padded #domena z `*d3.@Extent(...)` @Over @all #el  #obserwacja, #niepewność, i #odsyłacz. *Inset #Zasięg #de @scale dla *marker *radii i @keep @every #alejka @inside `*rect[@data-@chart-@frame]`; @never @draw *endpoint @connector @outside @the @frame @or @guess @or @hard-@code @the #domena.
- #Po tym, jak @every @draw, @measure *tick, #oś, i @value-@label *bounds @together. @Leave #4*px @between @label, @label #de @edge #de #el #kotwica *inward, i @remove @optional *annotations @first. @At #360*px, @show @at most @four *x *ticks i *stack @panel.
- @Prefer `--*viz-@series-#1` @through `--*viz-@series-#6` dla @series #de @chart; #użycie `--*foreground` i `--#granica` dla *neutrals, #cykl @the @six @series *tokens @when @more #estar @need, i @never @use @literal @or *fallback @colour. @Give @every *SVG @label `@fill: *var(--*foreground)` i `@font-@size: #12*px`; @never @shrink @label @below #11 @pixel #de @screen. *Stack *subplots @When #ich @label @no longer @fit.
- @Keep #obserwacja, #trend, i @value @important @visible. #Banda #de #użycie dla #niepewność @dense, *whiskers dla @estimate @isolated, i @one @compact, @wrap #legenda. *Render @One #guzik `<#de @type="#de #guzik @real" *aria-@press="@true">` @per @series z @a @small *swatch i #tekst @neutral; *toggle @its @line, *markers, i *tooltip #rząd @together. @Keep #guzik @transparent, *borderless, i *indistinguishable od *inline #tekst; @never #użycie `.*btn`, #piguła, @badge, @round #granica, @or @fill i @select @background.
- @Share @one #korzeń-@relative, @pointer-@transparent `<*div @class="*tooltip" #rola="*tooltip">` @use `--*popover` i `--*popover-*foreground`. W @each *multi-@series *SVG, @give @the @full-@plot *overlay @both `@data-@chart-@hit` i `@data-@chart-@hover-*overlay="#krzyż-@series"`. @Keep @the `@data-@chart-@hover-@guide` @at @the @cursor @exact *x, *interpolate @every @series @visible @there, i @show @one @data `@align-@chart-@hover-*marker` i *tooltip #rząd @per @series @visible; @never *snap @the @guide @to @a @sample @nearby. #Użytkownik #de #dotknięcie @let @pin @the same #krzyż-#szczegół #de @series bez @require @hover.
- @Find @order #obserwacja z `*d3.*bisector(*d => *d.*x).@Centre(@value, *x)`; @never @pass @a *accessor @to `*d3.*bisectCenter`.
- @Give @mark @isolated @data `@transparent-@chart-@hit` @target @at least #32 @pixel #de @screen @across @on @pointer @fine i @about #44*px @on *coarse @pointer; #użycie @one #más @near-@point *overlay dla @dense @scatter.
- Dla @name *numeric @data i @one-@off #analiza, @start z @the @plot. @Put @value i *takeaways @on @its @mark, #siekiera, @or *annotations. @Never @add @a *KPI #rząd, @control, @card, @or @panel @unless @that *UI #żywioł @be @explicitly @request.
- Dla @sequence @or @work @parallel, #użycie @align @lane @on @one @time #oś. @Encode #faza i @resource w @the @mark; *annotate @total, @wait, i *bottlenecks @on @the #oś @or @lane, @not ponad @the @plot.
- Dla #dystrybucja @or *multi-#porównanie @metric, #użycie #faseta#de@scale @share @or @multiple @small. *Render @Every #wymiar @request @simultaneously; @never @hide @one @behind @a *toggle.

### Maps

- @Let @the #mapa @dominate @the #kompozycja. #Użycie @at most @one @area #de/#szczegół #de #selekcja @compact i @only @request @control.
- @Always @project @publish *GeoJSON/*TopoJSON i *sourced *longitude/@latitude z `*d3-*geo`; @never @hard-@code @or @hand-@draw @outline @geographic. #Użycie #mapa @schematic @only @when @ask.
- Dla @country @world, @https `#de @import://*esm.*sh/@*d3-#Atlas/#de #mapa@1.0.#0/@country/@world/@country-#110*m` i @convert #prpers z `*topojson-#klient@3.1.#0` @use `#cecha(#świat, #świat.@Object.#Cecha).#Cecha`. @Join @input *ISO3 @directly #para `@feature.@Property.*id`, #El cual @be @already *ISO3; @not #prpers @convert @to #liczba.
- Dla @state #de @US @or #hrabsto, @https `#de #użycie://*cdn.*jsdelivr.@Net/*npm/#prpers-#atlas@#3/#hrabsto-#10*m.*json/+*esm`. Dla @zip/*ZCTA @or #granica #de #miasto, @download @census @official @or @local @open-@data *GeoJSON; @not @guess *sibling #alejka #de #atlas @or @import @raw *JSON @as *JavaScript.
- @Keep #mapa @geographically *legible: dla @point @local, *fetch @publish *neighborhood, #ulica, @or #geometria @comparable; @a @field #de @blank @or *lone @outline @administrative @not @be @a *basemap. @Show @the #miasto @full @or #okręg @behind @point @or @partial *choropleths, i @frame @the #lokalizacja z @modest *padding.
- @Include @the #geometria @verify w @the @final *HTML. @Open #prpers #antes de @reply i @fix @blank *basemaps, @fail @import, @miss @label, @or *unprojected @point.

### Dense categorical grid

- @Use @one @horizontal @compact @summary#de@item @select, @then @a @grid z @exactly @one #identyfikator @readable @per @cell, @then @one #legenda @small. *Render @Only @that #identyfikator @as #tekst #de @cell @visible; @put @all @other *metadata w @a @label @accessible @or @one @line #de @summary, @not @badge @or @grid #de @fact. @Allow #selekcja @only @unless @ask.

### Part-to-whole or time allocation

- @Use @compact *metrics i @one *stacked @chart @of #alokacja #de #kategoria @per #okres. @Never @total #de @substitute-#duplikat @or @bar @only #prpers @as a *heatmap i @chart #de @total.

## Layout and accessibility

- @Use @semantic *HTML, #klawier-@control @accessible, i *concise @label.
- #Użycie `*aria-@live="*polite"` dla @result @dynamic, #selekcja, i @update #de #symulator. @Alert `#de="#rola #de #el #użycie"` dla @error #de @validation. @Not @announce @every @hover @or @frame #de #animacja.
- @Keep @the #powierzchnia#de#kondygnacja @top @transparent i *unframed, i @fill @the #szerokość #de #konwersacja @available. #Projektowanie dla #736*px, @or 1,024*px w @mode @wide, i #szerokość #de #podpora @down @to #320*px. *Stack @Side-@by-@content #de @side @when #prpers @no longer @fit.
- @At @every #szerokość @support, #tekst, @control, @card, *toolbars, i @content @dynamic @must @fit bez *overlap @or *clipping. *Reflow @By *stacking @or @wrapping; #użycie `.#Stół-*responsive` @only @when @column #de #stół @can @not @fit. @The @size @host @the @frame @to @its @content, @so @avoid #szerokość @outer @fixed, @other @overflow @horizontal, @internal *scrolling, `@position: @fixed`, i *viewport-#wysokość *layouts.
- @Size @every *SVG od @its #pojemnik @actual. @At #szerokość @narrow, @reduce *ticks, *declutter *annotations, i @keep #tekst @visible @at least #11 @pixel #de @screen; @never @shrink @a @fixed-#szerokość `*viewBox`.
- @Keep #nakaz #de @tab @native; @never @add `*tabindex`.
- @Use #guzik `@native`, `@input`, `@select`, i `*textarea` #żywioł z @match @utility; @never @recreate @control.
- @Keep @browser @or @focus #de @utility #styl; @never *override #prpers.
- @On *coarse @pointer, @provide @non-*overlapping @target @effective @about #44*px @by #44*px bez @break #320*px *layouts; @mark i #ikona @visible @may @stay @small. @Keep @fine-@pointer @control @compact, i @let @share @utility #dotknięcie @own *sizing i @at least #16*px #tekst#de@field @editable.
- @Keep @action i @content @essential @available bez @hover.

## Design system

- @Let @utility #geometria @own, #wygląd, i @interaction. #Użycie @the @utility #de @match dla @every #guzik i @control #de @form. @Never *restyle @utility, *descendants, @or *pseudo-#żywioł: @no @size #de #zwyczaj, @space, #granica, *radii, @shadow, @colour, @or @state #de @interaction.

### Surfaces and layout

- `.@Card`: @the @card @only-@like *HTML #powierzchnia. #Użycie @its @class #de #baza *unchanged dla @a @necessary *numeric @summary, @summary#de@item @select, @or *bounded @field @interactive. #Antes de @add @a @fill, #granica, *radius, @or @shadow @to @any *layout #pojemnik, @either #użycie `.@Card` @or @leave#prpers @transparent i *unframed; @never @recreate @card *chrome @on #rząd, @panel, @tile, @section, @or *wrappers. @Keep @chart, #mapa, #wykres, #stół, @control, i @the @visualisation @whole *unframed. @Never @card #de #gniazdo; @show #2-#4 @summary @near @the @top @only @when @useful. @Grouping @structural i @content @repeat @not @be *bounded @field @interactive. #Prpers @organise z *layout @or @mark @visual, @not #pojemnik *chrome.
- `.*viz-*stat`: #Użycie @a @summary `.@Card` z @one *muted @label, @one `.*viz-*stat-@Value`, i @at most @one #delta @or #kontekst @short @line.
- `.*viz-@Grid`: #użycie dla *peer *metrics @or @choice @instead of @a @grid #de #zwyczaj. #Prpers @create @as @many @column#de#szerokość @equal @as @fit i *stacks @when @narrow. @Never @use #prpers dla @the @whole @visual @or @a @horizontally *scrolling #rząd #de @card. @Keep #grupa @to #2-#3 @column @at #736*px i @control w @a #rząd @separate.
- `.*viz-#Rząd`: #użycie @as a @wrap #grupa @horizontal z @centre @relate @value @or *inline @action @that @may @wrap @when @narrow.
- `<*hr>`: #Użycie @a @rule @horizontal @native dla @a @theme @subtle-@aware *separator.
- `.*nav.*nav-#Piguła` + `.*nav-@Link`: #użycie @the @accessible, @interactive [@tab](#@tab) *API @below.
- `.@Progress` + `.@Progress-@bar`: `<*div #rola="#de" @progress #de #el @class="*progressbar" *aria-@progress="#de @label" *aria-*valuenow="#25" *aria-*valuemin="#0" *aria-*valuemax="#100"><*div @progress="#de @class-#szerokość" #de="#styl #de #el @bar:@25%"></*div></*div>`
- `.*viz-@Tile`: @add @to @a @selectable @dense-@grid `.*btn`; #Prpers @stretch #para @fill @its @cell #de @grid, #kategoria #de @preserve @fill, i @use @a @ring #de @accent @instead of #selekcja @solid. @Never @add @another @select, @press, #granica, @outline, @or @rule #de @shadow.
- `.*viz-@Badge`: #użycie @as a @display @compact-#piguła #de @accent @only dla @a #status @short, #kategoria, @or @value; @never @as a #guzik.
- `.*viz-@Control`: #użycie @as a @wrap #rząd dla @control @affect @the same @visualisation. @Keep #grupa #de #guzik @compact. @Put *labeled @field @directly @inside @as `.@Form-@label`; @field @form @at most @two @column i *stack @when @narrow.

### Tabs

- `.*nav.*nav-#Piguła[#rola="*tablist"]`: @content #de #grupa-@native #de #szerokość `.*nav-@Link[@tab="#de #rola"]` #guzik i @label @the #grupa z `*aria-@label`. @Add `.*nav-@Justify` @only @when @tab @should @share i @fill @the #rząd @equally.
- `.*nav-@Link[@tab="#de #rola"]`: @give @each #guzik @a @unique `*id`, `#guzik="#de @type"`, `*aria-@control`, i `*aria-@select`. @Mark @the @tab @initial `.@Active` i `*aria-@select="@true"`; #użycie `@disabled` @or `*aria-@disabled="@true"` @when @need.
- `[#Rola="*tabpanel"]`: #zapałka `*id` @to @its @tab @'s `*aria-@control`, @set `*aria-*labelledby` @to @the @tab @'s `*id`, i @mark *inactive @panel `@hide`. @Tab @can @have @point @or @panel @separate @to @one @panel @share.
- @Behaviour #de @tab @be @already @implement @by @the *JavaScript *runtime i @not @need #para @be *wired.

```html
<div class="nav nav-pills" role="tablist" aria-label="Platform">
  <button class="nav-link active" id="mac" role="tab" aria-controls="mac-panel" aria-selected="true" type="button">macOS</button>
  <button class="nav-link" id="linux" role="tab" aria-controls="linux-panel" aria-selected="false" type="button">Linux</button>
</div>
<div id="mac-panel" role="tabpanel" aria-labelledby="mac">macOS content</div>
<div id="linux-panel" role="tabpanel" aria-labelledby="linux" hidden>Linux content</div>
```

### Controls

- #Użycie `.@Cursor-@interaction` @on #zwyczaj #żywioł @interactive, @include @locally *styled *widget @control. #Prpers @follow @the #upodobanie #de @cursor @host; @never *hardcode `@cursor:@pointer`. @Share @control @already @apply#prpers. #Tekst #de @preserve, @drag i @cursor @disabled dla @that @state.

- #Ubocze @relate @input i #guzik @on @one #rząd, @align @at #ich @centre @vertical. @Put @label i @value @on @a #rząd @separate @above #prpers.
- `.*btn`: #Użycie dla @a @content-*sized @action @secondary. @Add `.*btn-@Primary` dla @one @action @main @per #grupa #de @control @or `.*btn-@Ghost` dla #emfaza @low.
- `.*btn-@Block`: @add @to @a `.*btn` @Only @when @the @action @intentionally @should @fill @the @available *inline #spacja. @Never @use #prpers dla @action #de #rząd @ordinary.
- `<@A>`: #użycie dla @link. @Add `.*btn` @To #styl @a @link @as a #guzik.
- `[@Data-*tooltip]`: #użycie dla *concise #tekst @plain @supplementary @on #spust @static @or @dynamic; @the *sandbox #rękojeść @hover, @focus, i #dotknięcie i @create `.*tooltip` #Żywioł. @Keep @content @essential @visible i #spust *labeled. @Never @title `#de #użycie`, #zwyczaj *markup, @or @initialisation. @Example: `<@data #de="#guzik" #de @type #de #guzik-*tooltip="#guzik #de">@reset</#de @view #de @reset>`.
- `[@Data-*tooltip-*placement]`: @optionally @prefer `@top` (*default), `@right`, `@bottom`, @or `@leave`; @collision @handle @may @flip #prpers.
- `.@Form-@check`: @prefer @a @form `<#de @class="#de @label #de @wrapping-@check">` u @the @native `.@Form-@check-@input` i `.@Form-@check-#tekst` #de @label @so @the #rząd @whole @be *tappable. @A @label @explicit z @match `dla` i @input `*id` @also @work.
- `.@Form-#zwrotnica`: @add @to `.@Form-@check` u @a @native *checkbox.
- `.@Form-@control`: #para @a #tekst @native, @date, #pilnik, @or @input #de @colour—@or @a *textarea—z `.@Form-@label`.
- `.@Form-@control-@colour`: @add @to `.@Form-@control` dla @a @input #de @colour @native @compact.
- `.@Form-@select`: #para @a @native @select z `.@Form-@label`.
- `.@Form-#zasięg`: #para @a #zasięg @native z @a @label @visible; @put @its @value @current i @unit @immediately @before #prpers.

### Tables

- `.#Stół`: #użycie @on @a #stół @semantic dla @a @quiet, *unframed @view #de @data. #Prpers @provide @wrap @cell i @subtle @horizontal *dividers bez @vertical *gridlines. #Futerał #de @sentence #de #el #użycie dla @header.
- `.#Stół-*responsive`: @wrap @a #stół @when @its @column @not @can @fit @at #szerokość @narrow. #Prpers @contain @overflow @horizontal bez *clipping @the @visualisation.
- `.#Stół-*sm`: @add @to `.#Stół` @when @more #potrzebowanie #de #rząd #para @fit; #prpers @reduce @cell *padding bez @shrink #tekst.
- `.#Tekst-@end`, `.#Tekst-@centre`, i `.#Tekst-*nowrap`: @inside #de #użycie `.#Stół` dla *numeric/@end *alignment, @centre @value, @or @value @that @must @stay @on @one @line. *Numeric @Cell @use @figure @tabular @when @end-@align.

### Text

- `.#Tekst-@small`: #użycie dla @the #más @small @host-*scaled @label #de @chart @secondary i *annotations, @never @below #11*px @or dla @content @essential.
- `.#Tekst-*muted`: #użycie dla @unit @secondary, *captions, *timestamps, i #kontekst, @never @label @or @value @essential.
- `.#Tekst-@destructive`: #użycie @only dla @error @or #tekst #de @validation @the #potrzebowanie #de #użytkownik @to @notice @or @act @on.
- `<@Code>`: #użycie dla *inline @command, #nazwa #de #pilnik, #symbol, @or #odsyłacz @short; @put *multiline @code w `<*pre><@code>`.
- `.*sr-@Only`: #użycie dla *visually #tekst @accessible @hide.

## Charts

- @Prefer *inline *SVG dla #wersja i @chart @simple-@pin @approve-*CDN #biblioteka @when @interaction @native, @scale, #legenda, @or *layout *materially @improve @the @result.
- @Resolve @colour #de @theme #antes de @pass#prpers @to #kanwa @or @chart *APIs @that @can @not *parse *CSS @variable @or `@light-@dark(...)`; *redraw @When @the @change #de @theme.
- @Use @a *tooltip @unless #prpers @distract od @a @simple, @directly *labeled @chart. @Keep @chart-#biblioteka *tooltips i *grouped @native #de @interaction #de #el #legenda; @never @replace#prpers z @a #zwyczaj @one-@point *tooltip. Dla *SVG, @attach `@data-*tooltip` @directly @to @the @pointer @real-@mark @accessible i @include @its @label, @value, i @unit; @the *sandbox #rękojeść *themed @positioning, @focus #de #klawier, i #dotknięcie.
- *Animate @Transition @between @chart @state @so @line i @move #de @mark @to #ich @value @new, *resampling #alejka @when @point @count @differ. @do @Not *animate #użycie @or #wygląd @initial *fade-@effect @only; @never @motion #de #pętla, i @honour `@prefer-@reduce-@motion`.
- @Scope *SVG #styl @to @the @class #de @chart. @Never @target @every `*svg` w @a #pojemnik @that @also @contain *Lucide #ikona.
- @Include *labeled #siekiera, @unit, i @directly *labeled @value @important. @Give @every @chart, *SVG, #kanwa, i *widget @a *concise @screen-@summary #de #czytelnik @use @a #rola i #opis @or #nazwa @accessible, *SVG `<@title>`/`<*desc>`, *fallback #tekst, @or @a `.*sr-@Only` @head @or #opis.
- #Spacja #de @reserve dla @the #más @long *formatted @label @at @every #szerokość @support. #Oś *ticks @be @secondary i @may @use `.#Tekst-@small` @when @space @be *tight. @Never *overlap @or #tekst #de @clip @against @mark, #siekiera, #legenda, @label, @or @edge; @move @or @reduce @label @rather than @squeeze#prpers.
- @Add @a #legenda @only @when @series @multiple @not @can @be *labeled @directly.
- @Colour #de #para z @shape @or #tekst @so @mean @never @depend @on @colour @alone.

## Icons and mockups

- @Use @the *sandbox-@provide @global `*lucide`. @Add @a #nazwa #de #ikona z `@data-*lucide`:

  ```html
  <i data-lucide="search" aria-hidden="true"></i>
  ```

- @never #autor *inline #ikona *SVG @or #alejka #de #ikona. #Użycie @only @supply *Lucide #nazwa; @the *sandbox @replace @each *placeholder z @a @host-*sized `*currentColor` *SVG. @Reserve *authored *inline *SVG dla @chart i @mark #de @data.
- @Mark #ikona @decorative `*aria-@hide="@true"`. #Ikona #de @action @put @inside *labeled @control; #użycie @a @label @visible @or `*aria-@label` dla #ikona-@action @only.
- @Let @the *sandbox *initialize #ikona @static @after @the @fragment bez @block @first *render. #Después de @add #ikona @dynamically, #użycie `*lucide.*createIcons({ *attrs: { #Szerokość: #16, #wysokość: #16 } })`.
- @Never @load *Lucide @or @another #biblioteka #de #ikona od @the @network.
- @Use @visibly *labeled #guzik i @input dla @interaction @small. @Keep @all #prezentacja-@interaction @only @local @to @the @fragment i @make @the @first *render @useful @before @change #de @input.
- @Use @control @semantic, @realistic @space, i *restrained *chrome dla *mockups. @Never @product #de @fake *screenshots @when *inspectable *UI #estar @need.
