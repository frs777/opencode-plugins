import { Plugin } from "@opencode/plugin"
import { spawn } from "node:child_process"
import { join } from "node:path"
import { existsSync, readFileSync } from "node:fs"
import { fileURLToPath } from "node:url"

const REPO = fileURLToPath(new URL(".", import.meta.url)).replace(/\/$/, "")
const SCRIPTS = join(REPO, "scripts")
const PYTHON = process.env.PYTHON_BIN || "python3"

function runSkile(args) {
  return new Promise((resolve) => {
    const proc = spawn(PYTHON, [join(SCRIPTS, "skile.py"), ...args], { timeout: 30000 })
    let stdout = ""
    let stderr = ""
    proc.stdout.on("data", (d) => (stdout += d.toString()))
    proc.stderr.on("data", (d) => (stderr += d.toString()))
    proc.on("close", (code) => {
      if (code !== 0) resolve(`skile error (exit ${code}): ${stderr.trim() || stdout.trim()}`)
      else resolve(stdout.trim() || "(brak wyniku)")
    })
    proc.on("error", (err) => resolve(`skile error: ${err.message}`))
  })
}

export default Plugin.define({
  id: "find",
  name: "find",
  version: "0.2.0",
  description: "Meta-plugin do wyszukiwania zainstalowanych skilli, wtyczek, komend i MCP na podstawie naturalnego opisu zadania.",
  async setup(ctx) {
    const skillMd = join(REPO, "skills", "find", "SKILL.md")
    if (existsSync(skillMd)) {
      await ctx.skill.transform((editor) => {
        editor.add({
          id: "find",
          name: "find",
          description: "Meta-plugin do wyszukiwania i dobierania zainstalowanych skilli oraz wtyczek na podstawie naturalnego opisu zadania.",
          path: skillMd,
          content: readFileSync(skillMd, "utf-8"),
        })
      })
    }

    await ctx.tool.transform((editor) => {
      editor.namespace({ name: "find", description: "Discovery nad zainstalowanymi skillami, wtyczkami, komendami i MCP." })

      editor.add({
        name: "search",
        description: "Wyszukuje komponenty (skille, wtyczki, komendy, MCP) pasujące do opisu zadania (real-time, tymczasowy indeks).",
        input: {
          type: "object",
          properties: {
            query: { type: "string", description: "Opis zadania lub temat" },
            limit: { type: "number", description: "Maks. liczba wyników (domyślnie 10)" },
          },
          required: ["query"],
          additionalProperties: false,
        },
        options: { namespace: "find", codemode: true },
        execute: async (input) => {
          const args = ["--query", input.query, "--json"]
          if (input.limit) args.push("--limit", String(input.limit))
          const out = await runSkile(args)
          return { content: out }
        },
      })

      editor.add({
        name: "status",
        description: "Stan indeksu: liczba komponentów wg typu, źródła.",
        input: { type: "object", properties: {}, additionalProperties: false },
        options: { namespace: "find", codemode: true },
        execute: async () => {
          const out = await runSkile(["--status", "--json"])
          return { content: out }
        },
      })

      editor.add({
        name: "list",
        description: "Lista wszystkich zindeksowanych komponentów (JSON).",
        input: { type: "object", properties: {}, additionalProperties: false },
        options: { namespace: "find", codemode: true },
        execute: async () => {
          const out = await runSkile(["--json"])
          return { content: out }
        },
      })
    })

    return () => console.log("[find] Plugin unloaded")
  },
})