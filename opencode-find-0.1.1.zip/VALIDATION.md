# Validation

## Tests run
- `python3 -m pytest tests/` (find_core) — 4 passed
- `skile.py --status` → 483 components (450 skills, 10 plugins, 7 commands, 16 mcp)
- `skile.py -q "budowa serwera mcp"` → returns relevant skills + mcp
- `skile.py --json` → valid JSON, no duplicates
- Plugin loaded in OpenCode: `find (3 tools: search, status, list)` visible in catalog
- `tools.find.search/status/list` all returned OK

## Known limitations
- Indeksowanie tylko skilli (SKILL.md); pluginy/MCP/komendy skanowane z opencode.json i katalogu plugins, ale bez głębokiej introspekcji
- Real-time: indeks budowany w pamięci przy każdym wywołaniu (brak cache na dysku dla skile.py)
- Matching oparty na tokenach (brak embeddingów/semantyki)
