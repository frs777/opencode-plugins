# OpenCode conversion report

Target: OpenCode V2

## Changes (0.1.0 -> 0.2.0)
- Upgraded from skill-only to full plugin with tools (search, status, list)
- Added real-time discovery (temporary in-memory index, no disk)
- Added multi-source scanning: skills (3 roots) + plugins + commands + MCP
- Added deduplication by ID (name)
- Improved matching: stop-words (pl/en), stemming (5-char prefix), name boost
- Added invalid_files reporting in rescan
- Added /find command for OpenCode

Plugin type: full
Plugin entry point: index.mjs
Source: /home/frs/Projekty/opencode-find
